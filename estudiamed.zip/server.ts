import express, { Request, Response } from 'express';
import path from 'path';
import fs from 'fs';
import { createServer as createViteServer } from 'vite';
import dotenv from 'dotenv';
import { processExamPdf, getImportProgress, getImportQuestions, reviewQuestion, bulkActionQuestions, createSampleRevalidaImport } from './server/importPipeline';
import { validatePromoCode, getAllPromoCodes, createPromoCode, togglePromoCode, deletePromoCode, PLAN_PRICES, PLAN_QUESTION_LIMITS } from './server/promoService';
import { createCheckoutSession } from './server/stripeService';
import { PlanId } from './src/types';

dotenv.config();

const app = express();
const PORT = 3000;

// Set request body size limit to 50MB for PDF payloads
app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ extended: true, limit: '50mb' }));

// Ensure private storage directories exist
const PRIVATE_STORAGE_ROOT = path.join(process.cwd(), 'private_storage', 'exam-pdfs');
if (!fs.existsSync(PRIVATE_STORAGE_ROOT)) {
  fs.mkdirSync(PRIVATE_STORAGE_ROOT, { recursive: true });
}

// -----------------------------------------------------------------------------
// API ROUTES
// -----------------------------------------------------------------------------

// Health check
app.get('/api/health', (req: Request, res: Response) => {
  res.json({
    status: 'ok',
    service: 'estudiamed-api',
    geminiConfigured: Boolean(process.env.GEMINI_API_KEY),
    timestamp: new Date().toISOString(),
  });
});

// Upload PDF to private storage
app.post('/api/imports/upload', async (req: Request, res: Response) => {
  try {
    const { examId, year, fileName, fileBase64, fileSize, userId } = req.body;

    if (!examId || !year || !fileName || !fileBase64) {
      return res.status(400).json({ error: 'Missing required parameters: examId, year, fileName, fileBase64' });
    }

    const cleanExamId = String(examId).replace(/[^a-zA-Z0-9_-]/g, '');
    const cleanYear = Number(year);
    const cleanFileName = path.basename(String(fileName));

    // Save to private directory structure: /exam-pdfs/{examId}/{year}/{fileName}
    const targetDir = path.join(PRIVATE_STORAGE_ROOT, cleanExamId, String(cleanYear));
    if (!fs.existsSync(targetDir)) {
      fs.mkdirSync(targetDir, { recursive: true });
    }

    const targetFilePath = path.join(targetDir, cleanFileName);
    const storageRelativePath = `exam-pdfs/${cleanExamId}/${cleanYear}/${cleanFileName}`;

    // Decode and save file
    const buffer = Buffer.from(fileBase64, 'base64');
    fs.writeFileSync(targetFilePath, buffer);

    const importId = `import-${cleanExamId}-${cleanYear}-${Date.now()}`;

    const importRecord = {
      id: importId,
      fileName: cleanFileName,
      fileSize: fileSize || buffer.length,
      storagePath: storageRelativePath,
      examId: cleanExamId,
      year: cleanYear,
      status: 'uploaded',
      totalQuestions: 0,
      processedQuestions: 0,
      approvedQuestions: 0,
      rejectedQuestions: 0,
      pendingReviewQuestions: 0,
      possibleDuplicatesCount: 0,
      errors: [],
      stage: 'Aguardando Início',
      progressPercent: 0,
      stageDescription: 'Arquivo armazenado no bucket privado e pronto para extração.',
      createdBy: userId || 'admin-user',
      createdAt: new Date().toISOString(),
    };

    res.json({
      success: true,
      importRecord,
    });
  } catch (error: any) {
    console.error('Error uploading exam PDF:', error);
    res.status(500).json({ error: error.message || 'Failed to upload exam PDF' });
  }
});

// Process PDF with Gemini AI Pipeline
app.post('/api/imports/process', async (req: Request, res: Response) => {
  try {
    const { importId, examId, year, fileName, forceReprocess } = req.body;

    if (!importId) {
      return res.status(400).json({ error: 'Missing importId parameter' });
    }

    // Trigger processing
    const result = await processExamPdf({
      importId,
      examId,
      year: Number(year),
      fileName,
      forceReprocess: Boolean(forceReprocess),
    });

    res.json(result);
  } catch (error: any) {
    console.error('Error in processExamPdf API:', error);
    res.status(error.status || 500).json({ error: error.message || 'Failed to process PDF' });
  }
});

// Get import real-time status and logs
app.get('/api/imports/:importId/status', (req: Request, res: Response) => {
  const { importId } = req.params;
  const statusData = getImportProgress(importId);
  if (!statusData) {
    return res.status(404).json({ error: 'Import progress not found' });
  }
  res.json(statusData);
});

// Get questions extracted for an import
app.get('/api/imports/:importId/questions', (req: Request, res: Response) => {
  const { importId } = req.params;
  const { status, filter } = req.query;
  const questions = getImportQuestions(importId, {
    status: status as string,
    filter: filter as string,
  });
  res.json({ questions, total: questions.length });
});

// Review / Update Question
app.post('/api/questions/:questionId/review', (req: Request, res: Response) => {
  try {
    const { questionId } = req.params;
    const updates = req.body;
    const updated = reviewQuestion(questionId, updates);
    res.json({ success: true, question: updated });
  } catch (error: any) {
    res.status(400).json({ error: error.message });
  }
});

// Bulk Action on Questions of an Import (e.g. approve all valid)
app.post('/api/imports/:importId/bulk-action', (req: Request, res: Response) => {
  try {
    const { importId } = req.params;
    const { action } = req.body; // 'approve_valid' | 'reject_all' | 'approve_all'
    const result = bulkActionQuestions(importId, action);
    res.json(result);
  } catch (error: any) {
    res.status(400).json({ error: error.message });
  }
});

// Create and process Sample REVALIDA PDF for test runs
app.post('/api/imports/sample-revalida', async (req: Request, res: Response) => {
  try {
    const sampleRecord = await createSampleRevalidaImport();
    res.json(sampleRecord);
  } catch (error: any) {
    console.error('Error creating sample revalida import:', error);
    res.status(500).json({ error: error.message });
  }
});

// -----------------------------------------------------------------------------
// PROMO CODES & SUBSCRIPTION API ROUTES (SERVER-SIDE ENFORCED)
// -----------------------------------------------------------------------------

// Server-side promo code validation (Frontend never exposes secret keys or logic)
app.post('/api/promo/validate', (req: Request, res: Response) => {
  try {
    const { code, planId } = req.body;
    if (!code) {
      return res.status(400).json({ valid: false, message: 'Promo code is required.' });
    }
    const result = validatePromoCode(code, (planId || 'pro') as PlanId);
    res.json(result);
  } catch (error: any) {
    res.status(500).json({ valid: false, message: error.message });
  }
});

// Admin: List all promo codes
app.get('/api/admin/promos', (req: Request, res: Response) => {
  try {
    const promos = getAllPromoCodes();
    res.json({ promos });
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});

// Admin: Create promo code
app.post('/api/admin/promos', (req: Request, res: Response) => {
  try {
    const promo = createPromoCode(req.body);
    res.json({ success: true, promo });
  } catch (error: any) {
    res.status(400).json({ error: error.message });
  }
});

// Admin: Toggle promo code active
app.post('/api/admin/promos/:id/toggle', (req: Request, res: Response) => {
  try {
    const promo = togglePromoCode(req.params.id);
    res.json({ success: true, promo });
  } catch (error: any) {
    res.status(400).json({ error: error.message });
  }
});

// Admin: Delete promo code
app.delete('/api/admin/promos/:id', (req: Request, res: Response) => {
  try {
    const success = deletePromoCode(req.params.id);
    res.json({ success });
  } catch (error: any) {
    res.status(400).json({ error: error.message });
  }
});

// Stripe Checkout Session Creation
app.post('/api/stripe/create-checkout-session', async (req: Request, res: Response) => {
  try {
    const { planId, email, userId, promoCode, successUrl, cancelUrl } = req.body;
    if (!planId) {
      return res.status(400).json({ error: 'planId is required.' });
    }

    const session = await createCheckoutSession({
      planId: planId as PlanId,
      email,
      userId,
      promoCode,
      successUrl,
      cancelUrl,
    });

    res.json(session);
  } catch (error: any) {
    console.error('Checkout error:', error);
    res.status(500).json({ error: error.message });
  }
});

// Subscription Entitlements (Question limits per plan)
app.get('/api/subscription/entitlements', (req: Request, res: Response) => {
  res.json({
    prices: PLAN_PRICES,
    limits: PLAN_QUESTION_LIMITS,
    activePlans: ['starter', 'pro', 'premium'],
  });
});

// -----------------------------------------------------------------------------
// VITE INTEGRATION & SERVER STARTUP
// -----------------------------------------------------------------------------

async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req: Request, res: Response) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`[ESTUDIAMED Server] Running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
