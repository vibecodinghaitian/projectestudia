/**
 * ESTUDIAMED - Server-Side Promo Code Service & Architecture
 * Secure server-side validation and management.
 */

import { PromoCode, PromoRedemption, PromoValidationResult, PlanId } from '../src/types';

// In-memory persistent collection with seed promo codes
let promoCodesStore: PromoCode[] = [
  {
    id: 'promo-revalida-2026',
    code: 'REVALIDA2026',
    discount_type: 'percentage',
    discount_value: 100, // 100% off
    duration: 'repeating',
    duration_in_months: 1, // First month free
    applicable_plan: 'all',
    max_redemptions: 5000,
    redemption_count: 142,
    starts_at: '2026-01-01T00:00:00.000Z',
    expires_at: '2026-12-31T23:59:59.000Z',
    active: true,
    created_by: 'admin-system',
    created_at: '2026-01-01T00:00:00.000Z',
  },
  {
    id: 'promo-med-launch',
    code: 'MEDLAUNCH',
    discount_type: 'percentage',
    discount_value: 50,
    duration: 'repeating',
    duration_in_months: 3,
    applicable_plan: 'all',
    max_redemptions: 1000,
    redemption_count: 58,
    starts_at: '2026-02-01T00:00:00.000Z',
    expires_at: '2026-12-31T23:59:59.000Z',
    active: true,
    created_by: 'admin-system',
    created_at: '2026-02-01T00:00:00.000Z',
  },
];

let redemptionsStore: PromoRedemption[] = [];

// Base Plan Prices (USD monthly)
export const PLAN_PRICES: Record<PlanId, number> = {
  starter: 1.99,
  pro: 2.99,
  premium: 3.99,
};

// Plan Question Limits (Entitlements)
export const PLAN_QUESTION_LIMITS: Record<PlanId, number | 'unlimited'> = {
  starter: 1000,
  pro: 3000,
  premium: 'unlimited',
};

/**
 * Validates a promo code strictly server-side.
 */
export function validatePromoCode(rawCode: string, planId: PlanId): PromoValidationResult {
  if (!rawCode || typeof rawCode !== 'string') {
    return { valid: false, message: 'Invalid or missing promo code.' };
  }

  const normalized = rawCode.trim().toUpperCase();
  const promo = promoCodesStore.find(p => p.code.toUpperCase() === normalized);

  if (!promo) {
    return { valid: false, message: 'Promo code not found or expired.' };
  }

  if (!promo.active) {
    return { valid: false, message: 'This promo code is currently inactive.' };
  }

  // Check start date
  const now = new Date();
  if (promo.starts_at && new Date(promo.starts_at) > now) {
    return { valid: false, message: 'This promo code is not active yet.' };
  }

  // Check expiration date
  if (promo.expires_at && new Date(promo.expires_at) < now) {
    return { valid: false, message: 'This promo code has expired.' };
  }

  // Check max redemptions
  if (promo.max_redemptions && promo.redemption_count >= promo.max_redemptions) {
    return { valid: false, message: 'This promo code has reached its maximum redemption limit.' };
  }

  // Check plan applicability
  if (promo.applicable_plan && promo.applicable_plan !== 'all' && promo.applicable_plan !== planId) {
    return { valid: false, message: `This promo code is only valid for the ${promo.applicable_plan.toUpperCase()} plan.` };
  }

  const basePrice = PLAN_PRICES[planId] || 2.99;
  let finalFirstMonth = basePrice;
  const isFirstMonthFree = promo.discount_type === 'percentage' && promo.discount_value === 100;

  if (promo.discount_type === 'percentage') {
    const discountAmount = (basePrice * promo.discount_value) / 100;
    finalFirstMonth = Math.max(0, Number((basePrice - discountAmount).toFixed(2)));
  } else if (promo.discount_type === 'fixed_amount') {
    finalFirstMonth = Math.max(0, Number((basePrice - promo.discount_value).toFixed(2)));
  }

  const durationMonths = promo.duration_in_months || 1;
  const displayPromoText = isFirstMonthFree
    ? `1st month FREE, then $${basePrice.toFixed(2)}/mo`
    : `${promo.discount_value}% OFF for ${durationMonths} mo, then $${basePrice.toFixed(2)}/mo`;

  return {
    valid: true,
    promoCode: promo,
    discountSummary: {
      discountType: promo.discount_type,
      discountValue: promo.discount_value,
      durationInMonths: durationMonths,
      firstMonthFree: isFirstMonthFree,
      displayPromoText,
      originalPrice: basePrice,
      finalPriceFirstMonth: finalFirstMonth,
      recurringPriceAfter: basePrice,
    },
  };
}

/**
 * Record a successful promo redemption.
 */
export function recordPromoRedemption(promoId: string, userId: string, subscriptionId: string, planId: PlanId) {
  const promo = promoCodesStore.find(p => p.id === promoId || p.code.toUpperCase() === promoId.toUpperCase());
  if (promo) {
    promo.redemption_count += 1;
    const redemption: PromoRedemption = {
      id: `redemption-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
      promo_code_id: promo.id,
      user_id: userId,
      subscription_id: subscriptionId,
      plan_id: planId,
      discount_applied: `${promo.discount_value}%`,
      redeemed_at: new Date().toISOString(),
    };
    redemptionsStore.push(redemption);
    return redemption;
  }
  return null;
}

/**
 * Admin: List all promo codes.
 */
export function getAllPromoCodes(): PromoCode[] {
  return [...promoCodesStore];
}

/**
 * Admin: Create a new promo code.
 */
export function createPromoCode(data: Partial<PromoCode> & { code: string; discount_value: number }): PromoCode {
  const cleanCode = data.code.trim().toUpperCase();
  const existing = promoCodesStore.find(p => p.code.toUpperCase() === cleanCode);
  if (existing) {
    throw new Error(`Promo code ${cleanCode} already exists.`);
  }

  const newPromo: PromoCode = {
    id: `promo-${Date.now()}`,
    code: cleanCode,
    discount_type: data.discount_type || 'percentage',
    discount_value: Number(data.discount_value),
    duration: data.duration || 'repeating',
    duration_in_months: Number(data.duration_in_months || 1),
    applicable_plan: data.applicable_plan || 'all',
    max_redemptions: data.max_redemptions ? Number(data.max_redemptions) : undefined,
    redemption_count: 0,
    starts_at: data.starts_at || new Date().toISOString(),
    expires_at: data.expires_at || undefined,
    active: data.active !== undefined ? data.active : true,
    created_by: data.created_by || 'admin',
    created_at: new Date().toISOString(),
  };

  promoCodesStore.unshift(newPromo);
  return newPromo;
}

/**
 * Admin: Toggle promo code active status.
 */
export function togglePromoCode(id: string): PromoCode {
  const promo = promoCodesStore.find(p => p.id === id);
  if (!promo) {
    throw new Error('Promo code not found.');
  }
  promo.active = !promo.active;
  return promo;
}

/**
 * Admin: Delete promo code.
 */
export function deletePromoCode(id: string): boolean {
  const initialLength = promoCodesStore.length;
  promoCodesStore = promoCodesStore.filter(p => p.id !== id);
  return promoCodesStore.length < initialLength;
}
