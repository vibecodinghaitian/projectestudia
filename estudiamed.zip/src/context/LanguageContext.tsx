import React, { createContext, useContext, useState, useEffect } from 'react';
import { SupportedLanguage } from '../types';

export interface Translations {
  nav: {
    home: string;
    exams: string;
    features: string;
    pricing: string;
    faq: string;
    login: string;
    getStarted: string;
    studyMode: string;
    dashboard: string;
    admin: string;
  };
  hero: {
    headline: string;
    supportingText: string;
    ctaPrimary: string;
    ctaSecondary: string;
    badgeAvailable: string;
    badgeComingSoon: string;
    badgeAiPowered: string;
    sampleExam: string;
  };
  studyVisual: {
    examTitle: string;
    specialty: string;
    questionNumber: string;
    timeRemaining: string;
    stem: string;
    optA: string;
    optB: string;
    optC: string;
    optD: string;
    explanationHeader: string;
    explanationText: string;
    correctBadge: string;
    accuracyRate: string;
    radarLabel: string;
  };
  valueProps: {
    sectionTitle: string;
    sectionSubtitle: string;
    feat1Title: string;
    feat1Desc: string;
    feat2Title: string;
    feat2Desc: string;
    feat3Title: string;
    feat3Desc: string;
    feat4Title: string;
    feat4Desc: string;
  };
  exams: {
    sectionTitle: string;
    sectionSubtitle: string;
    availableNow: string;
    comingSoon: string;
    revalidaTitle: string;
    revalidaCountry: string;
    revalidaDesc: string;
    revalidaCta: string;
    mirTitle: string;
    mirCountry: string;
    mirDesc: string;
    enarmTitle: string;
    enarmCountry: string;
    enarmDesc: string;
    usmleTitle: string;
    usmleCountry: string;
    usmleDesc: string;
    plabTitle: string;
    plabCountry: string;
    plabDesc: string;
  };
  howItWorks: {
    sectionTitle: string;
    sectionSubtitle: string;
    step1Title: string;
    step1Desc: string;
    step2Title: string;
    step2Desc: string;
    step3Title: string;
    step3Desc: string;
  };
  trust: {
    sectionTitle: string;
    sectionSubtitle: string;
    pillar1Title: string;
    pillar1Desc: string;
    pillar2Title: string;
    pillar2Desc: string;
    pillar3Title: string;
    pillar3Desc: string;
    pillar4Title: string;
    pillar4Desc: string;
  };
  pricing: {
    sectionTitle: string;
    sectionSubtitle: string;
    perMonth: string;
    mostPopular: string;
    promoPrompt: string;
    promoPlaceholder: string;
    applyPromo: string;
    promoApplied: string;
    firstMonthFreeBadge: string;
    starterName: string;
    starterLimit: string;
    proName: string;
    proLimit: string;
    premiumName: string;
    premiumLimit: string;
    starterCta: string;
    proCta: string;
    premiumCta: string;
    checkoutModalTitle: string;
    checkoutModalDesc: string;
    planSummary: string;
    promoCodeLabel: string;
    proceedToStripe: string;
    freeTrialCta: string;
    secureNotice: string;
    cancelNotice: string;
  };
  faq: {
    sectionTitle: string;
    sectionSubtitle: string;
    items: {
      q: string;
      a: string;
    }[];
  };
  finalCta: {
    headline: string;
    supporting: string;
    primaryBtn: string;
    secondaryBtn: string;
  };
  footer: {
    tagline: string;
    examsGroup: string;
    productGroup: string;
    legalGroup: string;
    terms: string;
    privacy: string;
    refunds: string;
    language: string;
    copyright: string;
  };
}

const translations: Record<SupportedLanguage, Translations> = {
  en: {
    nav: {
      home: 'Home',
      exams: 'Exams',
      features: 'Features',
      pricing: 'Pricing',
      faq: 'FAQ',
      login: 'Log in',
      getStarted: 'Get Started',
      studyMode: 'Study Mode',
      dashboard: 'Dashboard',
      admin: 'Admin Portal',
    },
    hero: {
      headline: 'Prepare Smarter. Pass Your Medical Exam.',
      supportingText:
        'Practice with structured question banks, realistic simulations, detailed explanations, and performance tracking designed for medical exam preparation.',
      ctaPrimary: 'Start Preparing',
      ctaSecondary: 'Explore Exams',
      badgeAvailable: 'Available Now',
      badgeComingSoon: 'Coming Soon',
      badgeAiPowered: 'AI-Structured Bank',
      sampleExam: 'REVALIDA 🇧🇷',
    },
    studyVisual: {
      examTitle: 'INEP REVALIDA 2024 — Clinical Simulation',
      specialty: 'Clinical Medicine • Cardiology',
      questionNumber: 'Question 24 of 100',
      timeRemaining: '02:45 remaining',
      stem:
        'A 58-year-old male presents to the Emergency Department with sudden-onset crushing retrosternal chest pain radiating to the left shoulder and jaw for 45 minutes, accompanied by diaphoresis and dyspnea. Vital signs: BP 145/90 mmHg, HR 98 bpm, SpO2 96%. ECG demonstrates 2.5 mm ST-segment elevation in leads V1–V4 with reciprocal depressions in leads II, III, and aVF. Which of the following is the most immediate priority in definitive management?',
      optA: 'Administer oral Aspirin 300 mg and Clopidogrel 300 mg immediately, and transfer for Primary Percutaneous Coronary Intervention (PCI).',
      optB: 'Perform immediate electrical cardioversion and administer sublingual nitroglycerin.',
      optC: 'Request serial cardiac troponin levels and repeat ECG in 6 hours prior to intervention.',
      optD: 'Initiate high-dose intravenous heparin alone and observe in intermediate care.',
      explanationHeader: 'Medical Rationale & Clinical Guideline:',
      explanationText:
        'Option A is correct. Acute anterior STEMI requires prompt dual antiplatelet loading and emergency reperfusion therapy via Primary PCI within 120 minutes of first medical contact.',
      correctBadge: 'Correct Answer: A',
      accuracyRate: 'Target Accuracy: 82%',
      radarLabel: 'Cardiology Mastery',
    },
    valueProps: {
      sectionTitle: 'Everything You Need to Prepare With Confidence',
      sectionSubtitle:
        'Engineered specifically for medical licensing and specialty board examinations.',
      feat1Title: 'Question Bank',
      feat1Desc: 'Practice thousands of carefully organized medical questions categorized by high-yield specialties.',
      feat2Title: 'Realistic Simulations',
      feat2Desc: 'Train under timed, exam-like conditions that simulate actual official testing environments.',
      feat3Title: 'Detailed Corrections',
      feat3Desc: 'Understand why each answer is correct or incorrect with comprehensive clinical commentary.',
      feat4Title: 'Track Your Progress',
      feat4Desc: 'Identify weak specialties, monitor accuracy trends, and optimize your study schedule.',
    },
    exams: {
      sectionTitle: 'Prepare for Your Medical Exam',
      sectionSubtitle:
        'Estudiamed is built to support official medical licensing and residency exams globally.',
      availableNow: 'Available Now',
      comingSoon: 'Coming Soon',
      revalidaTitle: 'REVALIDA',
      revalidaCountry: 'Brazil 🇧🇷',
      revalidaDesc: 'Prepare with structured questions and realistic simulations for the INEP National Revalida examination.',
      revalidaCta: 'Start Revalida Preparation',
      mirTitle: 'MIR',
      mirCountry: 'Spain 🇪🇸',
      mirDesc: 'Comprehensive preparation for the Spanish Médico Interno Residente specialized residency examination.',
      enarmTitle: 'ENARM',
      enarmCountry: 'Mexico 🇲🇽',
      enarmDesc: 'Targeted question practice for the Examen Nacional para Aspirantes a Residencias Médicas.',
      usmleTitle: 'USMLE',
      usmleCountry: 'United States 🇺🇸',
      usmleDesc: 'High-yield clinical vignettes and USMLE Step 1 & Step 2 CK question banks.',
      plabTitle: 'PLAB / UKMLA',
      plabCountry: 'United Kingdom 🇬🇧',
      plabDesc: 'Professional and Linguistic Assessments Board preparation for GMC registration.',
    },
    howItWorks: {
      sectionTitle: 'How Estudiamed Works',
      sectionSubtitle: 'A methodical 3-step workflow built to maximize recall and exam-day performance.',
      step1Title: '1. Choose Your Exam',
      step1Desc: 'Select your target examination and access curated, verified question banks aligned with official blueprints.',
      step2Title: '2. Practice and Simulate',
      step2Desc: 'Solve clinical cases by specialty or take timed official simulations with instant medical rationale.',
      step3Title: '3. Track Your Progress',
      step3Desc: 'Diagnose weak areas with specialty breakdown analytics and review incorrect answers actively.',
    },
    trust: {
      sectionTitle: 'Built for Serious Medical Exam Preparation',
      sectionSubtitle: 'A disciplined academic environment free from distractions, gimmicks, or low-quality content.',
      pillar1Title: 'Curated Medical Content',
      pillar1Desc: 'Questions extracted from official test publications and verified by clinical guidelines.',
      pillar2Title: 'Official Exam Layouts',
      pillar2Desc: 'Simulations replicate the question format, pacing, and cognitive stamina required on exam day.',
      pillar3Title: 'Explanatory Clarity',
      pillar3Desc: 'Evidence-based explanations that clarify the physiological and diagnostic rationale.',
      pillar4Title: 'Dedicated Study Focus',
      pillar4Desc: 'Designed to support consistent daily practice with distraction-free dark and light study modes.',
    },
    pricing: {
      sectionTitle: 'Simple Pricing. Serious Preparation.',
      sectionSubtitle: 'Transparent monthly plans. Upgrade, downgrade, or cancel anytime with no commitments.',
      perMonth: '/ month',
      mostPopular: 'MOST POPULAR',
      promoPrompt: 'Have a promo code?',
      promoPlaceholder: 'Enter promo code (e.g. REVALIDA2026)',
      applyPromo: 'Apply',
      promoApplied: 'Promo code applied successfully!',
      firstMonthFreeBadge: '100% OFF — First Month Free',
      starterName: 'Starter',
      starterLimit: 'Up to 1,000 questions',
      proName: 'Pro',
      proLimit: 'Up to 3,000 questions',
      premiumName: 'Premium',
      premiumLimit: 'Unlimited questions',
      starterCta: 'Start with Starter',
      proCta: 'Choose Pro',
      premiumCta: 'Choose Premium',
      checkoutModalTitle: 'Complete Your Subscription',
      checkoutModalDesc: 'Unlock your medical question bank and simulation tools.',
      planSummary: 'Plan Summary',
      promoCodeLabel: 'Promotional Code',
      proceedToStripe: 'Proceed to Secure Checkout',
      freeTrialCta: 'Start Free Month (REVALIDA2026)',
      secureNotice: 'Encrypted 256-bit checkout powered by Stripe. Billed in USD.',
      cancelNotice: 'Cancel anytime directly from your dashboard settings.',
    },
    faq: {
      sectionTitle: 'Frequently Asked Questions',
      sectionSubtitle: 'Clear answers about platform access, subscription billing, and exam coverage.',
      items: [
        {
          q: 'What is Estudiamed?',
          a: 'Estudiamed is a specialized medical exam preparation platform offering structured question banks, realistic exam simulations, detailed corrections, and performance analytics for medical licensing and residency exams.',
        },
        {
          q: 'Which exams are currently available?',
          a: 'REVALIDA (Brazil) is currently active and available. Upcoming examinations including MIR (Spain), ENARM (Mexico), USMLE (USA), and PLAB (UK) are in development and will be released sequentially.',
        },
        {
          q: 'What is included in each plan?',
          a: 'The Starter plan includes up to 1,000 questions with practice filters. The Pro plan includes up to 3,000 questions, full exam simulations with timers, and detailed specialty metrics. The Premium plan includes unlimited access to all questions, historical editions, and priority updates.',
        },
        {
          q: 'Can I cancel my subscription?',
          a: 'Yes, you can cancel your subscription at any time with a single click in your account settings. You will continue to have full access until the end of your current billing period.',
        },
        {
          q: 'How does the promo code work?',
          a: 'You can enter a valid promotional code during checkout. Codes like REVALIDA2026 apply a 100% discount for the first month. After the free promotional month ends, the standard monthly price will automatically apply unless cancelled.',
        },
        {
          q: 'Is the first month free with REVALIDA2026?',
          a: 'Yes! Using the official promotional code REVALIDA2026 grants 100% off for the first month of study on any plan.',
        },
        {
          q: 'Can I use Estudiamed on mobile devices?',
          a: 'Yes, Estudiamed is fully responsive and optimized for smartphones, tablets, and desktop computers. You can solve clinical cases and review simulations seamlessly on any modern web browser.',
        },
        {
          q: 'Will more medical exams be added in the future?',
          a: 'Yes, Estudiamed is built from the ground up with a multi-exam database architecture. We regularly ingest official past exams and will launch specialized tracks for MIR, ENARM, USMLE, and PLAB.',
        },
      ],
    },
    finalCta: {
      headline: 'Prepare Today. Perform Better Tomorrow.',
      supporting:
        'Join physicians and medical graduates training daily with structured questions, realistic simulations, and detailed corrections.',
      primaryBtn: 'Start Preparing',
      secondaryBtn: 'View Pricing',
    },
    footer: {
      tagline: 'Medical Exam Preparation Platform for serious licensing candidates worldwide.',
      examsGroup: 'Examinations',
      productGroup: 'Platform',
      legalGroup: 'Legal & Policies',
      terms: 'Terms of Service',
      privacy: 'Privacy Policy',
      refunds: 'Refund Policy',
      language: 'Language',
      copyright: '© 2026 ESTUDIAMED. All rights reserved.',
    },
  },
  es: {
    nav: {
      home: 'Inicio',
      exams: 'Exámenes',
      features: 'Funciones',
      pricing: 'Precios',
      faq: 'Preguntas',
      login: 'Iniciar Sesión',
      getStarted: 'Comenzar',
      studyMode: 'Modo Estudio',
      dashboard: 'Panel de Estudio',
      admin: 'Portal Admin',
    },
    hero: {
      headline: 'Prepárate Mejor. Aprueba tu Examen Médico.',
      supportingText:
        'Practica con bancos de preguntas estructurados, simulacros realistas, explicaciones detalladas y seguimiento de rendimiento diseñado para exámenes médicos.',
      ctaPrimary: 'Comenzar Preparación',
      ctaSecondary: 'Explorar Exámenes',
      badgeAvailable: 'Disponible Ahora',
      badgeComingSoon: 'Próximamente',
      badgeAiPowered: 'Banco Estructurado con IA',
      sampleExam: 'REVALIDA 🇧🇷',
    },
    studyVisual: {
      examTitle: 'INEP REVALIDA 2024 — Simulación Clínica',
      specialty: 'Medicina Interna • Cardiología',
      questionNumber: 'Pregunta 24 de 100',
      timeRemaining: '02:45 restantes',
      stem:
        'Paciente masculino de 58 años acude al Servicio de Urgencias por dolor torácico retroesternal opresivo de 45 minutos de evolución, irradiado al hombro y mandíbula izquierdos, acompañado de diaforesis y disnea. Signos vitales: PA 145/90 mmHg, FC 98 lpm, SatO2 96%. El ECG muestra elevación del segmento ST de 2.5 mm en derivaciones V1–V4 con depresión recíproca en II, III y aVF. ¿Cuál es la prioridad inmediata en el manejo definitivo?',
      optA: 'Administrar Ácido Acetilsalicílico 300 mg y Clopidogrel 300 mg VO de inmediato, y trasladar a Intervención Coronaria Percutánea (ICP) primaria.',
      optB: 'Realizar cardioversión eléctrica inmediata y administrar nitroglicerina sublingual.',
      optC: 'Solicitar troponinas cardíacas seriadas y repetir ECG en 6 horas antes de cualquier intervención.',
      optD: 'Iniciar heparina intravenosa en monoterapia y mantener en observación intermedia.',
      explanationHeader: 'Fundamentación Médica y Guías Clínicas:',
      explanationText:
        'La opción A es la correcta. El SCACEST anterior requiere carga inmediata de doble antiagregación plaquetaria y terapia de reperfusión urgente mediante ICP primaria antes de 120 minutos del primer contacto médico.',
      correctBadge: 'Respuesta Correcta: A',
      accuracyRate: 'Tasa Objetivo: 82%',
      radarLabel: 'Dominio en Cardiología',
    },
    valueProps: {
      sectionTitle: 'Todo lo que Necesitas para Prepararte con Confianza',
      sectionSubtitle:
        'Diseñado rigurosamente para exámenes de reválida, residencia y habilitación médica.',
      feat1Title: 'Banco de Preguntas',
      feat1Desc: 'Practica miles de preguntas médicas cuidadosamente organizadas por especialidades clave.',
      feat2Title: 'Simulacros Realistas',
      feat2Desc: 'Entrena bajo condiciones cronometradas idénticas a los exámenes oficiales.',
      feat3Title: 'Correcciones Detalladas',
      feat3Desc: 'Comprende con exactitud por qué cada respuesta es correcta o incorrecta con explicaciones clínicas.',
      feat4Title: 'Monitorea tu Progreso',
      feat4Desc: 'Identifica especialidades débiles y sigue la evolución de tu precisión a lo largo del tiempo.',
    },
    exams: {
      sectionTitle: 'Prepárate para tu Examen Médico',
      sectionSubtitle:
        'Estudiamed está concebido para respaldar las principales pruebas médicas internacionales.',
      availableNow: 'Disponible Ahora',
      comingSoon: 'Próximamente',
      revalidaTitle: 'REVALIDA',
      revalidaCountry: 'Brasil 🇧🇷',
      revalidaDesc: 'Prepárate con preguntas estructuradas y simulacros realistas para el examen nacional REVALIDA de Brasil.',
      revalidaCta: 'Comenzar Preparación Revalida',
      mirTitle: 'MIR',
      mirCountry: 'España 🇪🇸',
      mirDesc: 'Preparación integral para el examen de Médico Interno Residente en España.',
      enarmTitle: 'ENARM',
      enarmCountry: 'México 🇲🇽',
      enarmDesc: 'Práctica focalizada para el Examen Nacional para Aspirantes a Residencias Médicas.',
      usmleTitle: 'USMLE',
      usmleCountry: 'Estados Unidos 🇺🇸',
      usmleDesc: 'Casos clínicos de alto rendimiento para USMLE Step 1 y Step 2 CK.',
      plabTitle: 'PLAB / UKMLA',
      plabCountry: 'Reino Unido 🇬🇧',
      plabDesc: 'Preparación para el registro profesional ante el General Medical Council.',
    },
    howItWorks: {
      sectionTitle: 'Cómo Funciona Estudiamed',
      sectionSubtitle: 'Un flujo de 3 pasos diseñado para optimizar tu retención y rendimiento en el examen.',
      step1Title: '1. Elige tu Examen',
      step1Desc: 'Selecciona tu prueba objetivo y accede a bancos de preguntas alineados al temario oficial.',
      step2Title: '2. Practica y Simula',
      step2Desc: 'Resuelve casos clínicos por área o realiza simulacros completos con temporizador.',
      step3Title: '3. Evalúa tu Rendimiento',
      step3Desc: 'Detecta tus puntos débiles mediante estadísticas por especialidad y revisa tus errores.',
    },
    trust: {
      sectionTitle: 'Creado para una Preparación Médica Seria',
      sectionSubtitle: 'Un entorno académico disciplinado, sin distracciones ni contenido superficial.',
      pillar1Title: 'Contenido Médico Verificado',
      pillar1Desc: 'Preguntas extraídas de cuadernos oficiales y contrastadas con guías clínicas actualizadas.',
      pillar2Title: 'Entorno de Examen Real',
      pillar2Desc: 'Los simulacros reproducen el formato, tiempo y nivel de exigencia de la prueba oficial.',
      pillar3Title: 'Claridad Explicativa',
      pillar3Desc: 'Justificaciones clínicas que profundizan en el razonamiento diagnóstico y terapéutico.',
      pillar4Title: 'Foco de Estudio Total',
      pillar4Desc: 'Diseñado para mantener la constancia diaria con un entorno visual académico y relajante.',
    },
    pricing: {
      sectionTitle: 'Precios Simples. Preparación Seria.',
      sectionSubtitle: 'Planes mensuales transparentes. Cancela o cambia de plan en cualquier momento.',
      perMonth: '/ mes',
      mostPopular: 'MÁS POPULAR',
      promoPrompt: '¿Tienes un código promocional?',
      promoPlaceholder: 'Ingresa tu código (ej. REVALIDA2026)',
      applyPromo: 'Aplicar',
      promoApplied: '¡Código promocional aplicado con éxito!',
      firstMonthFreeBadge: '100% DESCUENTO — Primer Mes Gratis',
      starterName: 'Starter',
      starterLimit: 'Hasta 1.000 preguntas',
      proName: 'Pro',
      proLimit: 'Hasta 3.000 preguntas',
      premiumName: 'Premium',
      premiumLimit: 'Preguntas ilimitadas',
      starterCta: 'Comenzar con Starter',
      proCta: 'Elegir Pro',
      premiumCta: 'Elegir Premium',
      checkoutModalTitle: 'Completa tu Suscripción',
      checkoutModalDesc: 'Accede de inmediato al banco de preguntas y simulacros.',
      planSummary: 'Resumen del Plan',
      promoCodeLabel: 'Código Promocional',
      proceedToStripe: 'Continuar al Pago Seguro',
      freeTrialCta: 'Comenzar Mes Gratis (REVALIDA2026)',
      secureNotice: 'Pago seguro y encriptado con Stripe. Facturado en USD.',
      cancelNotice: 'Puedes cancelar en cualquier momento desde tu panel de usuario.',
    },
    faq: {
      sectionTitle: 'Preguntas Frecuentes',
      sectionSubtitle: 'Respuestas claras sobre la plataforma, pagos y disponibilidad de exámenes.',
      items: [
        {
          q: '¿Qué es Estudiamed?',
          a: 'Estudiamed es una plataforma médica de preparación para exámenes de habilitación y residencias que ofrece bancos de preguntas clasificados, simulacros cronometrados, correcciones justificadas y analítica de desempeño.',
        },
        {
          q: '¿Qué exámenes están disponibles actualmente?',
          a: 'El examen REVALIDA (Brasil) se encuentra activo y disponible. Pruebas como MIR (España), ENARM (México), USMLE (EE.UU.) y PLAB (Reino Unido) están en desarrollo activo y se habilitarán progresivamente.',
        },
        {
          q: '¿Qué incluye cada plan?',
          a: 'El plan Starter incluye hasta 1.000 preguntas con filtros de práctica. El plan Pro incluye hasta 3.000 preguntas, simulacros oficiales con cronómetro y analítica por especialidad. El plan Premium brinda acceso ilimitado a todas las preguntas y ediciones históricas.',
        },
        {
          q: '¿Puedo cancelar mi suscripción?',
          a: 'Sí, puedes cancelar tu suscripción en cualquier momento desde la configuración de tu cuenta. Mantendrás el acceso completo hasta el final del periodo pagado.',
        },
        {
          q: '¿Cómo funciona el código promocional?',
          a: 'Puedes ingresar un código válido al momento del pago. Códigos como REVALIDA2026 otorgan un 100% de descuento durante el primer mes de suscripción. Posteriormente, se cobrará la tarifa mensual regular salvo que decidas cancelar.',
        },
        {
          q: '¿El primer mes es gratis con REVALIDA2026?',
          a: '¡Sí! Al utilizar el código REVALIDA2026 obtienes un 100% de descuento durante el primer mes en cualquiera de nuestros planes.',
        },
        {
          q: '¿Puedo usar Estudiamed en dispositivos móviles?',
          a: 'Sí, la plataforma está completamente optimizada para smartphones, tablets y ordenadores. Puedes responder preguntas y revisar simulacros desde cualquier navegador web moderno.',
        },
        {
          q: '¿Se añadirán más exámenes en el futuro?',
          a: 'Sí, la arquitectura de Estudiamed está construida para soportar múltiples exámenes médicos. Regularmente procesamos nuevos cuadernos de prueba para ampliar la cobertura internacional.',
        },
      ],
    },
    finalCta: {
      headline: 'Prepárate Hoy. Rinde Mejor Mañana.',
      supporting:
        'Únete a los médicos que entrenan a diario con preguntas estructuradas, simulacros y correcciones fundamentadas.',
      primaryBtn: 'Comenzar Preparación',
      secondaryBtn: 'Ver Planes y Precios',
    },
    footer: {
      tagline: 'Plataforma de preparación médica para aspirantes a licencias y residencias.',
      examsGroup: 'Exámenes',
      productGroup: 'Plataforma',
      legalGroup: 'Legal y Políticas',
      terms: 'Términos de Servicio',
      privacy: 'Política de Privacidad',
      refunds: 'Política de Reembolso',
      language: 'Idioma',
      copyright: '© 2026 ESTUDIAMED. Todos los derechos reservados.',
    },
  },
  pt: {
    nav: {
      home: 'Início',
      exams: 'Exames',
      features: 'Recursos',
      pricing: 'Preços',
      faq: 'Dúvidas',
      login: 'Entrar',
      getStarted: 'Começar Agora',
      studyMode: 'Modo Estudo',
      dashboard: 'Área do Aluno',
      admin: 'Painel Admin',
    },
    hero: {
      headline: 'Prepare-se com Inteligência. Conquiste sua Aprovação.',
      supportingText:
        'Treine com banco de questões estruturado, simulados realistas, resoluções comentadas e acompanhamento de desempenho criado para provas médicas.',
      ctaPrimary: 'Começar Preparação',
      ctaSecondary: 'Explorar Exames',
      badgeAvailable: 'Disponível Agora',
      badgeComingSoon: 'Em Breve',
      badgeAiPowered: 'Banco Estruturado com IA',
      sampleExam: 'REVALIDA 🇧🇷',
    },
    studyVisual: {
      examTitle: 'INEP REVALIDA 2024 — Simulado Clínico Oficial',
      specialty: 'Clínica Médica • Cardiologia',
      questionNumber: 'Questão 24 de 100',
      timeRemaining: '02:45 restantes',
      stem:
        'Homem de 58 anos dá entrada no Pronto-Socorro com dor precordial opressiva de início súbito há 45 minutos, com irradiação para ombro e mandíbula esquerdos, acompanhada de sudorese fria e dispneia. Sinais vitais: PA 145/90 mmHg, FC 98 bpm, SpO2 96%. ECG revela elevação do segmento ST de 2.5 mm de V1 a V4 com infra recíproco em DII, DIII e aVF. Qual a conduta imediata prioritária para o manejo definitivo?',
      optA: 'Administrar Ácido Acetilsalicílico 300 mg e Clopidogrel 300 mg VO imediatamente e encaminhar para Angioplastia Coronária Primária (ICP).',
      optB: 'Realizar cardioversão elétrica imediata e administrar nitroglicerina sublingual.',
      optC: 'Solicitar troponina seriada e repetir ECG em 6 horas antes de qualquer intervenção.',
      optD: 'Iniciar heparinização plena isolada e manter em observação na semi-intensiva.',
      explanationHeader: 'Comentário Médico e Diretriz Clínica:',
      explanationText:
        'A alternativa A está correta. No IAM com supra de ST anterior, a terapia de reperfusão de escolha é a Angioplastia Primária imediata (tempo porta-balão < 90-120 min), precedida por dupla antiagregação plaquetária.',
      correctBadge: 'Gabarito Oficial: A',
      accuracyRate: 'Taxa de Acerto: 82%',
      radarLabel: 'Domínio em Cardiologia',
    },
    valueProps: {
      sectionTitle: 'Tudo o que Você Precisa para Treinar com Confiança',
      sectionSubtitle:
        'Desenvolvido sob medida para candidatos ao Revalida e provas de residência médica.',
      feat1Title: 'Banco de Questões',
      feat1Desc: 'Pratique milhares de questões médicas organizadas e categorizadas por grandes áreas.',
      feat2Title: 'Simulados Realistas',
      feat2Desc: 'Treine sob condições reais de tempo e formato idênticos aos cadernos oficiais.',
      feat3Title: 'Comentários Detalhados',
      feat3Desc: 'Entenda a justificativa médica de cada alternativa com gabarito fundamentado.',
      feat4Title: 'Acompanhe seu Progresso',
      feat4Desc: 'Identifique suas fraquezas por especialidade e monitore sua evolução de precisão.',
    },
    exams: {
      sectionTitle: 'Prepare-se para o seu Exame Médico',
      sectionSubtitle:
        'A Estudiamed foi estruturada para suportar as principais provas de habilitação médica do mundo.',
      availableNow: 'Disponível Agora',
      comingSoon: 'Em Breve',
      revalidaTitle: 'REVALIDA',
      revalidaCountry: 'Brasil 🇧🇷',
      revalidaDesc: 'Treine com questões estruturadas e simulados cronometrados para o Exame Nacional Revalida (INEP).',
      revalidaCta: 'Iniciar Preparação Revalida',
      mirTitle: 'MIR',
      mirCountry: 'Espanha 🇪🇸',
      mirDesc: 'Preparação focada para o exame de Médico Interno Residente na Espanha.',
      enarmTitle: 'ENARM',
      enarmCountry: 'México 🇲🇽',
      enarmDesc: 'Banco de questões e simulados para o Examen Nacional de Residencias Médicas.',
      usmleTitle: 'USMLE',
      usmleCountry: 'Estados Unidos 🇺🇸',
      usmleDesc: 'Casos clínicos de alta relevância para as etapas Step 1 e Step 2 CK.',
      plabTitle: 'PLAB / UKMLA',
      plabCountry: 'Reino Unido 🇬🇧',
      plabDesc: 'Preparação para o registro profissional médico no General Medical Council.',
    },
    howItWorks: {
      sectionTitle: 'Como Funciona a Estudiamed',
      sectionSubtitle: 'Um fluxo em 3 etapas para consolidar seu aprendizado e maximizar sua nota.',
      step1Title: '1. Escolha seu Exame',
      step1Desc: 'Selecione a prova desejada e acesse os cadernos de questões organizados.',
      step2Title: '2. Treine e Simule',
      step2Desc: 'Resolva casos clínicos por especialidade ou realize simulados com temporizador.',
      step3Title: '3. Acompanhe a Evolução',
      step3Desc: 'Descubra suas áreas de menor acerto e faça revisões ativas com o caderno de erros.',
    },
    trust: {
      sectionTitle: 'Construído para um Estudo Médico Sério',
      sectionSubtitle: 'Ambiente acadêmico focado, sem distrações, promessas vazias ou atalhos.',
      pillar1Title: 'Conteúdo Médico Homologado',
      pillar1Desc: 'Questões extraídas de cadernos de prova oficiais com revisão de gabarito e diretrizes.',
      pillar2Title: 'Simulação Fiel à Prova',
      pillar2Desc: 'Temporizador e contagem de tempo projetados para treinar sua velocidade no dia do teste.',
      pillar3Title: 'Justificativas Claras',
      pillar3Desc: 'Explicações clínicas que reforçam o raciocínio fisiopatológico e terapêutico.',
      pillar4Title: 'Foco Total no Aprendizado',
      pillar4Desc: 'Interface limpa pensada para sessões de estudo longas com modo escuro suave.',
    },
    pricing: {
      sectionTitle: 'Preços Simples. Preparação Séria.',
      sectionSubtitle: 'Assinatura mensal sem fidelidade. Cancele ou altere seu plano quando quiser.',
      perMonth: '/ mês',
      mostPopular: 'MAIS POPULAR',
      promoPrompt: 'Possui um cupom de desconto?',
      promoPlaceholder: 'Digite o cupom (ex: REVALIDA2026)',
      applyPromo: 'Aplicar',
      promoApplied: 'Cupom de desconto aplicado com sucesso!',
      firstMonthFreeBadge: '100% OFF — 1º Mês Grátis',
      starterName: 'Starter',
      starterLimit: 'Até 1.000 questões',
      proName: 'Pro',
      proLimit: 'Até 3.000 questões',
      premiumName: 'Premium',
      premiumLimit: 'Questões ilimitadas',
      starterCta: 'Começar com Starter',
      proCta: 'Escolher Pro',
      premiumCta: 'Escolher Premium',
      checkoutModalTitle: 'Finalize sua Assinatura',
      checkoutModalDesc: 'Tenha acesso imediato ao banco de questões e simulados.',
      planSummary: 'Resumo do Plano',
      promoCodeLabel: 'Cupom Promocional',
      proceedToStripe: 'Ir para Checkout Seguro',
      freeTrialCta: 'Começar 1º Mês Grátis (REVALIDA2026)',
      secureNotice: 'Pagamento processado com segurança via Stripe. Cobrado em USD.',
      cancelNotice: 'Você pode cancelar quando quiser diretamente nas configurações.',
    },
    faq: {
      sectionTitle: 'Perguntas Frequentes',
      sectionSubtitle: 'Tire suas dúvidas sobre a plataforma, assinaturas e cobertura dos exames.',
      items: [
        {
          q: 'O que é a Estudiamed?',
          a: 'A Estudiamed é uma plataforma especializada de preparação para exames médicos que oferece bancos de questões categorizados, simulados cronometrados, correções detalhadas e acompanhamento analítico de desempenho.',
        },
        {
          q: 'Quais exames estão disponíveis?',
          a: 'O REVALIDA (Brasil) já está totalmente disponível para estudo. Provas como MIR (Espanha), ENARM (México), USMLE (EUA) e PLAB (Reino Unido) estão em fase final de preparação e serão lançadas em breve.',
        },
        {
          q: 'O que está incluído em cada plano?',
          a: 'O plano Starter dá acesso a até 1.000 questões com filtros de treino. O plano Pro dá acesso a até 3.000 questões, simulados com cronômetro e estatísticas por grande área. O plano Premium inclui acesso ilimitado a todas as questões e edições passadas.',
        },
        {
          q: 'Posso cancelar minha assinatura?',
          a: 'Sim, você pode cancelar a qualquer momento nas configurações do seu perfil com um único clique. Seu acesso continuará ativo até o fim do período vigente.',
        },
        {
          q: 'Como funciona o cupom de desconto?',
          a: 'Basta digitar um cupom válido no checkout. O cupom REVALIDA2026 concede 100% de desconto no primeiro mês. Após o mês promocional gratuito, a assinatura renova no valor mensal padrão, a menos que cancelada.',
        },
        {
          q: 'O primeiro mês é gratuito com o cupom REVALIDA2026?',
          a: 'Sim! Ao aplicar o cupom oficial REVALIDA2026, você estuda o primeiro mês com 100% de desconto em qualquer plano escolhido.',
        },
        {
          q: 'Posso usar a Estudiamed no celular?',
          a: 'Sim, a Estudiamed é totalmente responsiva e funciona em qualquer smartphone, tablet ou computador através do navegador, sem necessidade de instalar aplicativos pesados.',
        },
        {
          q: 'Serão adicionados outros exames no futuro?',
          a: 'Sim! Nossa arquitetura multi-exame recebe atualizações constantes com extração automática via inteligência artificial de novas provas oficiais do Brasil e do exterior.',
        },
      ],
    },
    finalCta: {
      headline: 'Prepare-se Hoje. Conquiste sua Vaga Amanhã.',
      supporting:
        'Junte-se aos médicos e formandos que treinam diariamente com simulados realistas e resoluções completas.',
      primaryBtn: 'Começar Preparação',
      secondaryBtn: 'Ver Planos e Preços',
    },
    footer: {
      tagline: 'Plataforma de preparação para exames de habilitação e residência médica.',
      examsGroup: 'Exames',
      productGroup: 'Plataforma',
      legalGroup: 'Legal e Políticas',
      terms: 'Termos de Uso',
      privacy: 'Política de Privacidade',
      refunds: 'Política de Reembolso',
      language: 'Idioma',
      copyright: '© 2026 ESTUDIAMED. Todos os direitos reservados.',
    },
  },
};

interface LanguageContextType {
  language: SupportedLanguage;
  setLanguage: (lang: SupportedLanguage) => void;
  t: Translations;
}

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

const LANGUAGE_STORAGE_KEY = 'estudiamed_language_preference';

export const LanguageProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [language, setLanguageState] = useState<SupportedLanguage>(() => {
    try {
      const saved = localStorage.getItem(LANGUAGE_STORAGE_KEY) as SupportedLanguage;
      if (saved && ['en', 'es', 'pt'].includes(saved)) {
        return saved;
      }
    } catch (e) {
      // Local storage unavailable
    }
    return 'en'; // Default language is English as required
  });

  const setLanguage = (lang: SupportedLanguage) => {
    setLanguageState(lang);
    try {
      localStorage.setItem(LANGUAGE_STORAGE_KEY, lang);
    } catch (e) {
      // Ignore local storage error
    }

    // Update document HTML lang attribute and title/meta
    if (typeof document !== 'undefined') {
      document.documentElement.lang = lang;
      if (lang === 'en') {
        document.title = 'ESTUDIAMED — Medical Exam Preparation Platform';
      } else if (lang === 'es') {
        document.title = 'ESTUDIAMED — Plataforma de Preparación para Exámenes Médicos';
      } else {
        document.title = 'ESTUDIAMED — Preparação para Exames Médicos';
      }
    }
  };

  useEffect(() => {
    if (typeof document !== 'undefined') {
      document.documentElement.lang = language;
    }
  }, [language]);

  const value = {
    language,
    setLanguage,
    t: translations[language] || translations.en,
  };

  return <LanguageContext.Provider value={value}>{children}</LanguageContext.Provider>;
};

export function useLanguage(): LanguageContextType {
  const context = useContext(LanguageContext);
  if (!context) {
    throw new Error('useLanguage must be used within a LanguageProvider');
  }
  return context;
}
