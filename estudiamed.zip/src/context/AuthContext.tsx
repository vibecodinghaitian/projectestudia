import { 
  createContext, 
  useContext, 
  useState, 
  useEffect, 
  ReactNode 
} from 'react';
import { onAuthStateChanged, User as FirebaseUser } from 'firebase/auth';
import { auth } from '../lib/firebase';
import { UserProfile, UserRole } from '../types';
import { authService } from '../services/authService';
import { seedInitialDatabaseIfEmpty } from '../services/seedService';

interface AuthContextType {
  user: FirebaseUser | null;
  profile: UserProfile | null;
  role: UserRole;
  isAdmin: boolean;
  loading: boolean;
  loginWithEmail: (email: string, pass: string) => Promise<UserProfile>;
  registerWithEmail: (email: string, pass: string, name: string) => Promise<UserProfile>;
  loginWithGoogle: () => Promise<UserProfile>;
  resetPassword: (email: string) => Promise<void>;
  logout: () => Promise<void>;
  simulateRole: (role: UserRole) => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<FirebaseUser | null>(null);
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [role, setRole] = useState<UserRole>('student');
  const [loading, setLoading] = useState(true);

  // Initialize DB seeds on first boot if needed
  useEffect(() => {
    seedInitialDatabaseIfEmpty().catch(console.error);
  }, []);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (fbUser) => {
      setLoading(true);
      if (fbUser) {
        setUser(fbUser);
        try {
          const userProf = await authService.getUserProfile(fbUser.uid);
          if (userProf) {
            setProfile(userProf);
            setRole(userProf.role);
          } else {
            const newProf = await authService.syncUserProfile(fbUser);
            setProfile(newProf);
            setRole(newProf.role);
          }
        } catch (error) {
          console.warn('Auth profile resolution error:', error);
          const fallbackProfile: UserProfile = {
            uid: fbUser.uid,
            name: fbUser.displayName || fbUser.email?.split('@')[0] || 'Médico Estudante',
            email: fbUser.email || '',
            role: fbUser.email === 'wanky7713@gmail.com' ? 'admin' : 'student',
            createdAt: new Date().toISOString(),
          };
          setProfile(fallbackProfile);
          setRole(fallbackProfile.role);
        }
      } else {
        setUser(null);
        // Default simulated student profile for immediate preview access
        const guestStudentProfile: UserProfile = {
          uid: 'guest-student-demo',
          name: 'Dra. Camila Ribeiro (Demonstração)',
          email: 'camila.med@estudiamed.com',
          role: 'student',
          targetExamId: 'revalida-br',
          createdAt: new Date().toISOString(),
        };
        setProfile(guestStudentProfile);
        setRole('student');
      }
      setLoading(false);
    });

    return () => unsubscribe();
  }, []);

  const loginWithEmail = async (email: string, pass: string) => {
    setLoading(true);
    try {
      const prof = await authService.loginWithEmail(email, pass);
      setProfile(prof);
      setRole(prof.role);
      return prof;
    } finally {
      setLoading(false);
    }
  };

  const registerWithEmail = async (email: string, pass: string, name: string) => {
    setLoading(true);
    try {
      const prof = await authService.registerWithEmail(email, pass, name);
      setProfile(prof);
      setRole(prof.role);
      return prof;
    } finally {
      setLoading(false);
    }
  };

  const loginWithGoogle = async () => {
    setLoading(true);
    try {
      const prof = await authService.loginWithGoogle();
      setProfile(prof);
      setRole(prof.role);
      return prof;
    } finally {
      setLoading(false);
    }
  };

  const resetPassword = async (email: string) => {
    await authService.resetPassword(email);
  };

  const logout = async () => {
    await authService.logout();
    setUser(null);
    const guestStudentProfile: UserProfile = {
      uid: 'guest-student-demo',
      name: 'Dra. Camila Ribeiro (Demonstração)',
      email: 'camila.med@estudiamed.com',
      role: 'student',
      targetExamId: 'revalida-br',
      createdAt: new Date().toISOString(),
    };
    setProfile(guestStudentProfile);
    setRole('student');
  };

  const simulateRole = (newRole: UserRole) => {
    setRole(newRole);
    if (profile) {
      setProfile({ ...profile, role: newRole });
    }
  };

  const isAdmin = role === 'admin';

  return (
    <AuthContext.Provider
      value={{
        user,
        profile,
        role,
        isAdmin,
        loading,
        loginWithEmail,
        registerWithEmail,
        loginWithGoogle,
        resetPassword,
        logout,
        simulateRole,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}
