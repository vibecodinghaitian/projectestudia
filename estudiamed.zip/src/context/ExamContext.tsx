import { 
  createContext, 
  useContext, 
  useState, 
  useEffect, 
  ReactNode 
} from 'react';
import { Exam, Specialty } from '../types';
import { examService } from '../services/examService';

interface ExamContextType {
  exams: Exam[];
  selectedExam: Exam | null;
  specialties: Specialty[];
  loading: boolean;
  setSelectedExamId: (examId: string) => void;
  refreshExams: () => Promise<void>;
}

const ExamContext = createContext<ExamContextType | undefined>(undefined);

export function ExamProvider({ children }: { children: ReactNode }) {
  const [exams, setExams] = useState<Exam[]>([]);
  const [selectedExam, setSelectedExam] = useState<Exam | null>(null);
  const [specialties, setSpecialties] = useState<Specialty[]>([]);
  const [loading, setLoading] = useState(true);

  const loadData = async () => {
    setLoading(true);
    try {
      const allExams = await examService.getAllExams();
      setExams(allExams);
      
      // Default to active REVALIDA if available
      const defaultExam = allExams.find(e => e.id === 'revalida-br') || allExams[0] || null;
      setSelectedExam(prev => prev ? (allExams.find(e => e.id === prev.id) || defaultExam) : defaultExam);

      if (defaultExam) {
        const specs = await examService.getSpecialties(defaultExam.id);
        setSpecialties(specs);
      }
    } catch (err) {
      console.error('Failed loading exams:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  const setSelectedExamId = async (examId: string) => {
    const found = exams.find(e => e.id === examId) || null;
    setSelectedExam(found);
    if (found) {
      const specs = await examService.getSpecialties(found.id);
      setSpecialties(specs);
    }
  };

  return (
    <ExamContext.Provider
      value={{
        exams,
        selectedExam,
        specialties,
        loading,
        setSelectedExamId,
        refreshExams: loadData,
      }}
    >
      {children}
    </ExamContext.Provider>
  );
}

export function useExam() {
  const context = useContext(ExamContext);
  if (!context) {
    throw new Error('useExam must be used within an ExamProvider');
  }
  return context;
}
