/**
 * ESTUDIAMED - Core TypeScript Definitions
 * Multi-Exam Medical Preparation Platform
 */

export type UserRole = 'admin' | 'student';

export interface UserProfile {
  uid: string;
  name: string;
  email: string;
  role: UserRole;
  targetExamId?: string;
  avatarUrl?: string;
  bio?: string;
  subscriptionPlan?: PlanId;
  subscriptionStatus?: SubscriptionStatus;
  createdAt: string;
  updatedAt?: string;
}

export interface AdminRecord {
  uid: string;
  email: string;
  createdAt: string;
}

export interface Specialty {
  id: string;
  examId: string;
  name: string;
  code: string;
  description?: string;
  questionCount?: number;
  createdAt: string;
  updatedAt?: string;
}

export interface Exam {
  id: string;
  name: string;
  code: string; // e.g. 'REVALIDA', 'MIR', 'ENARM', 'USMLE', 'PLAB'
  country: string; // e.g. 'Brazil', 'Spain', 'Mexico', 'USA', 'UK'
  countryCode: string; // e.g. 'BR', 'ES', 'MX', 'US', 'GB'
  flagEmoji?: string;
  description: string;
  active: boolean;
  specialties: string[]; // List of specialty IDs or names
  availableYears: number[]; // e.g. [2024, 2023, 2022, 2021, 2020]
  totalQuestions: number;
  iconName?: string;
  color?: string;
  createdAt: string;
  updatedAt?: string;
}

export type QuestionStatus = 'draft' | 'pending_review' | 'approved' | 'rejected';
export type QuestionDifficulty = 'easy' | 'medium' | 'hard';

export interface QuestionOption {
  id: string; // 'A', 'B', 'C', 'D', 'E', etc.
  text: string;
}

export interface Question {
  id: string;
  examId: string;
  specialtyId: string;
  specialtyName?: string;
  year?: number;
  questionNumber?: number;
  statement: string; // Clinical case stem or clinical vignette
  options: QuestionOption[];
  correctAnswer: string; // 'A', 'B', 'C', etc.
  explanation?: string;
  source?: string; // e.g. "INEP REVALIDA 2023.2", "Ministerio de Sanidad MIR 2024"
  sourcePage?: number;
  difficulty?: QuestionDifficulty;
  status: QuestionStatus;
  tags?: string[];
  importId?: string;
  isPossibleDuplicate?: boolean;
  duplicateReason?: string;
  validationErrors?: string[];
  createdBy?: string;
  createdAt: string;
  updatedAt?: string;
}

export type ImportStatus = 
  | 'uploaded'
  | 'processing'
  | 'completed'
  | 'partially_completed'
  | 'failed'
  | 'reviewed';

export interface QuestionImport {
  id: string;
  fileName: string;
  fileSize?: number;
  storagePath: string; // e.g. /exam-pdfs/{examId}/{year}/{fileName}
  examId: string;
  year?: number;
  status: ImportStatus;
  totalQuestions: number;
  processedQuestions: number;
  approvedQuestions: number;
  rejectedQuestions: number;
  pendingReviewQuestions?: number;
  possibleDuplicatesCount?: number;
  stage?: string;
  progressPercent?: number;
  stageDescription?: string;
  errors?: string[];
  logs?: string[];
  notes?: string;
  createdBy: string;
  createdAt: string;
  completedAt?: string;
}

export type SimulationMode = 'exam' | 'practice' | 'custom';
export type SimulationStatus = 'in_progress' | 'completed' | 'abandoned';

export interface Simulation {
  id: string;
  userId: string;
  examId: string;
  title: string;
  year?: number;
  mode: SimulationMode;
  questionIds: string[];
  status: SimulationStatus;
  totalQuestions: number;
  timeLimitMinutes?: number;
  startedAt: string;
  completedAt?: string;
  createdAt: string;
}

export interface SimulationAnswerItem {
  questionId: string;
  selectedOption: string;
  isCorrect: boolean;
  timeSpentSeconds: number;
}

export interface SimulationResult {
  id: string;
  simulationId: string;
  userId: string;
  examId: string;
  score: number; // 0 - 100
  totalQuestions: number;
  correctAnswers: number;
  incorrectAnswers: number;
  unanswered: number;
  timeSpentSeconds: number;
  answers: Record<string, SimulationAnswerItem>;
  specialtyBreakdown: Record<string, { total: number; correct: number }>;
  completedAt: string;
  createdAt: string;
}

export interface StudentProgress {
  id: string;
  userId: string;
  examId: string;
  totalQuestionsAnswered: number;
  totalCorrect: number;
  accuracyPercentage: number;
  weakSpecialties: string[];
  strongSpecialties: string[];
  recentScoreAverage?: number;
  updatedAt: string;
}

export interface PlatformStatistics {
  totalQuestions: number;
  approvedQuestions: number;
  pendingQuestions: number;
  totalExams: number;
  activeExams: number;
  totalImports: number;
  totalStudents: number;
  totalSimulationsTaken: number;
}

export interface RouteConfig {
  path: string;
  label: string;
  icon?: string;
  roles?: UserRole[];
}

// -----------------------------------------------------------------------------
// MULTILINGUAL & I18N TYPES
// -----------------------------------------------------------------------------
export type SupportedLanguage = 'en' | 'es' | 'pt';

// -----------------------------------------------------------------------------
// SUBSCRIPTIONS, PLANS & PRICING
// -----------------------------------------------------------------------------
export type PlanId = 'starter' | 'pro' | 'premium';

export type SubscriptionStatus = 
  | 'active'
  | 'trialing'
  | 'past_due'
  | 'canceled'
  | 'incomplete'
  | 'unpaid';

export interface PricingPlan {
  id: PlanId;
  name: string;
  priceMonthlyUSD: number;
  questionLimit: number | 'unlimited';
  isPopular?: boolean;
  features: string[];
  ctaKey: string;
}

export interface UserSubscription {
  id: string;
  userId: string;
  planId: PlanId;
  status: SubscriptionStatus;
  stripeCustomerId?: string;
  stripeSubscriptionId?: string;
  currentPeriodStart: string;
  currentPeriodEnd: string;
  cancelAtPeriodEnd: boolean;
  promoCodeApplied?: string;
  discountPercentage?: number;
  createdAt: string;
  updatedAt?: string;
}

// -----------------------------------------------------------------------------
// PROMO CODES & REDEMPTIONS
// -----------------------------------------------------------------------------
export type PromoDiscountType = 'percentage' | 'fixed_amount';
export type PromoDuration = 'once' | 'repeating' | 'forever';

export interface PromoCode {
  id: string;
  code: string;
  discount_type: PromoDiscountType;
  discount_value: number; // e.g. 100 for 100% off
  duration: PromoDuration;
  duration_in_months?: number; // e.g. 1
  applicable_plan?: PlanId | 'all';
  max_redemptions?: number;
  redemption_count: number;
  starts_at: string;
  expires_at?: string;
  active: boolean;
  created_by: string;
  created_at: string;
}

export interface PromoRedemption {
  id: string;
  promo_code_id: string;
  user_id: string;
  subscription_id?: string;
  plan_id?: PlanId;
  discount_applied: string;
  redeemed_at: string;
}

export interface PromoValidationResult {
  valid: boolean;
  message?: string;
  promoCode?: PromoCode;
  discountSummary?: {
    discountType: PromoDiscountType;
    discountValue: number;
    durationInMonths: number;
    firstMonthFree: boolean;
    displayPromoText: string;
    originalPrice: number;
    finalPriceFirstMonth: number;
    recurringPriceAfter: number;
  };
}
