import React from 'react';
import { useExam } from '../../context/ExamContext';
import { Badge } from '../../components/common/Badge';
import { Button } from '../../components/common/Button';
import { EXAM_FLAGS } from '../../lib/utils';
import { Award, Check, Sparkles, ArrowRight, Globe } from 'lucide-react';

interface ExamCatalogProps {
  onNavigate: (path: string) => void;
}

export function ExamCatalog({ onNavigate }: ExamCatalogProps) {
  const { exams, selectedExam, setSelectedExamId } = useExam();

  return (
    <div className="space-y-10">
      {/* Editorial Header */}
      <header className="border-b border-slate-200 pb-8">
        <div className="flex flex-wrap justify-between items-center gap-3 mb-4">
          <div className="inline-flex items-center gap-2 px-3 py-1 bg-blue-100 text-blue-700 text-xs font-bold rounded-full tracking-wide font-mono">
            <Globe className="w-3.5 h-3.5" />
            <span>SISTEMA MULTI-EXAME GLOBAL</span>
          </div>
          <div className="text-slate-400 text-xs font-mono uppercase tracking-widest">
            ESTUDIAMED INTERNATIONAL
          </div>
        </div>

        <h1 className="font-editorial text-4xl sm:text-5xl lg:text-6xl font-extrabold tracking-tight text-slate-900 mb-3 leading-none">
          Catálogo de Exames Médicos
        </h1>
        <p className="text-base sm:text-lg text-slate-600 max-w-3xl leading-relaxed">
          Estruturado para suportar simultaneamente o REVALIDA (Brasil), MIR (Espanha), ENARM (México), USMLE (EUA) e PLAB (Reino Unido). Selecione a banca desejada para direcionar seu banco de questões e estatísticas.
        </p>
      </header>

      {/* Grid of Exams with Editorial styling */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        {exams.map((exam) => {
          const isSelected = selectedExam?.id === exam.id;
          return (
            <div
              key={exam.id}
              className={`bg-white rounded-3xl border transition-all p-6 sm:p-8 flex flex-col justify-between shadow-sm relative hover:shadow-md ${
                isSelected
                  ? 'border-blue-500 ring-2 ring-blue-500/20'
                  : 'border-slate-200 hover:border-slate-300'
              }`}
            >
              {isSelected && (
                <div className="absolute top-6 right-6">
                  <Badge variant="editorial" size="sm" dot>
                    Exame Selecionado
                  </Badge>
                </div>
              )}

              <div>
                <div className="flex items-center gap-3.5 mb-4">
                  <span className="text-3xl p-3 bg-slate-50 rounded-2xl border border-slate-100 shrink-0">
                    {EXAM_FLAGS[exam.countryCode] || '🩺'}
                  </span>
                  <div>
                    <h3 className="text-lg font-bold text-slate-900 leading-tight">{exam.name}</h3>
                    <p className="text-xs font-mono text-blue-600 mt-0.5">/code: {exam.code}</p>
                  </div>
                </div>

                <p className="text-xs sm:text-sm text-slate-600 leading-relaxed mb-6 min-h-[50px]">
                  {exam.description}
                </p>

                <div className="space-y-2.5 py-4 border-y border-slate-100 text-xs">
                  <div className="flex justify-between text-slate-500">
                    <span>Disponibilidade:</span>
                    <span className="font-mono font-bold text-slate-800">
                      {exam.active ? 'Ativo na Plataforma' : 'Em Estruturação'}
                    </span>
                  </div>
                  <div className="flex justify-between text-slate-500">
                    <span>Edições Catalogadas:</span>
                    <span className="font-mono font-bold text-slate-800">
                      {exam.availableYears?.join(', ') || '2024'}
                    </span>
                  </div>
                  <div className="flex justify-between text-slate-500">
                    <span>Grandes Áreas:</span>
                    <span className="font-mono font-bold text-slate-800">
                      {exam.specialties?.length || 5} especialidades
                    </span>
                  </div>
                </div>
              </div>

              <div className="mt-6 flex items-center gap-2">
                <Button
                  id={`select-exam-${exam.id}`}
                  className="flex-1"
                  variant={isSelected ? 'secondary' : 'primary'}
                  size="sm"
                  onClick={() => {
                    setSelectedExamId(exam.id);
                    onNavigate(`/exams/${exam.id}`);
                  }}
                >
                  {isSelected ? 'Acessar Questões' : 'Selecionar Exame'}
                </Button>
                <Button
                  size="sm"
                  variant="outline"
                  onClick={() => {
                    setSelectedExamId(exam.id);
                    onNavigate(`/exams/${exam.id}`);
                  }}
                >
                  <ArrowRight className="w-4 h-4" />
                </Button>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
