import React, { useState, useEffect } from 'react';
import { useExam } from '../../context/ExamContext';
import { Badge } from '../../components/common/Badge';
import { Button } from '../../components/common/Button';
import { EXAM_FLAGS } from '../../lib/utils';
import { 
  ArrowLeft, 
  Play, 
  CheckCircle2, 
  Check, 
  X,
  BookOpen
} from 'lucide-react';
import { questionService } from '../../services/questionService';
import { Question } from '../../types';

interface ExamDetailProps {
  examId: string;
  onNavigate: (path: string) => void;
}

export function ExamDetail({ examId, onNavigate }: ExamDetailProps) {
  const { exams, specialties } = useExam();
  const exam = exams.find(e => e.id === examId) || exams[0];
  const [questions, setQuestions] = useState<Question[]>([]);
  const [selectedAnswers, setSelectedAnswers] = useState<Record<string, string>>({});
  const [revealedExplanations, setRevealedExplanations] = useState<Record<string, boolean>>({});
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function loadQuestions() {
      if (!exam) return;
      setLoading(true);
      try {
        const list = await questionService.getQuestions({ examId: exam.id, status: 'approved' });
        setQuestions(list);
      } catch (err) {
        console.error('Error loading questions for exam:', err);
      } finally {
        setLoading(false);
      }
    }
    loadQuestions();
  }, [exam]);

  if (!exam) {
    return (
      <div className="text-center py-12">
        <p className="text-slate-500">Exame não encontrado.</p>
        <Button onClick={() => onNavigate('/exams')} className="mt-4">
          Voltar para Catálogo
        </Button>
      </div>
    );
  }

  const handleSelectOption = (questionId: string, optionId: string) => {
    setSelectedAnswers(prev => ({ ...prev, [questionId]: optionId }));
    setRevealedExplanations(prev => ({ ...prev, [questionId]: true }));
  };

  return (
    <div className="space-y-8">
      {/* Back button */}
      <button
        onClick={() => onNavigate('/exams')}
        className="inline-flex items-center gap-1.5 text-xs font-mono font-bold text-slate-500 hover:text-slate-900 transition-colors cursor-pointer"
      >
        <ArrowLeft className="w-4 h-4" /> VOLTAR AO CATÁLOGO DE EXAMES
      </button>

      {/* Exam Header Overview Card */}
      <div className="bg-white border border-slate-200 rounded-3xl p-6 sm:p-8 shadow-sm">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-6 pb-6 border-b border-slate-100">
          <div className="flex items-start gap-4">
            <span className="text-4xl p-3 bg-slate-50 rounded-2xl border border-slate-100 shrink-0">
              {EXAM_FLAGS[exam.countryCode] || '🩺'}
            </span>
            <div>
              <div className="flex items-center gap-3">
                <h1 className="font-editorial text-3xl sm:text-4xl font-extrabold text-slate-900">{exam.name}</h1>
                <Badge variant="editorial" size="sm">{exam.code}</Badge>
              </div>
              <p className="text-xs font-mono text-slate-400 mt-1">{exam.country} • BANCA OFICIAL</p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <Button
              id="start-full-sim-btn"
              onClick={() => {}}
              icon={<Play className="w-4 h-4 fill-white" />}
            >
              Iniciar Simulado Cronometrado
            </Button>
          </div>
        </div>

        <p className="text-sm sm:text-base text-slate-600 mt-6 leading-relaxed">
          {exam.description}
        </p>

        {/* Metadata Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mt-6 pt-4 border-t border-slate-100 text-xs">
          <div>
            <span className="text-slate-400 block mb-0.5 font-mono text-3xs uppercase">Edições Anuais</span>
            <span className="font-mono font-bold text-slate-800">{exam.availableYears?.join(', ') || '2024'}</span>
          </div>
          <div>
            <span className="text-slate-400 block mb-0.5 font-mono text-3xs uppercase">Especialidades</span>
            <span className="font-mono font-bold text-slate-800">{specialties.length || 5} Grandes Áreas</span>
          </div>
          <div>
            <span className="text-slate-400 block mb-0.5 font-mono text-3xs uppercase">Questões Validadas</span>
            <span className="font-mono font-bold text-slate-800">{questions.length} Cadastradas</span>
          </div>
          <div>
            <span className="text-slate-400 block mb-0.5 font-mono text-3xs uppercase">Padrão da Prova</span>
            <span className="font-mono font-bold text-slate-800">Múltipla Escolha (A-E)</span>
          </div>
        </div>
      </div>

      {/* Question Bank */}
      <div className="space-y-6">
        <div className="flex items-center justify-between border-b border-slate-200 pb-3">
          <div>
            <h3 className="text-xs font-bold uppercase tracking-widest text-slate-400">
              Banco Oficial de Casos Clínicos
            </h3>
            <h2 className="font-editorial text-2xl font-bold text-slate-900 mt-0.5">
              Questões Comentadas — {exam.name}
            </h2>
          </div>
          <Badge variant="editorial" size="sm">{questions.length} Questões</Badge>
        </div>

        {questions.length === 0 ? (
          <div className="bg-white rounded-3xl border border-slate-200 p-8 text-center text-slate-500 text-sm">
            Nenhuma questão aprovada ainda para este exame. Importe via painel de administração.
          </div>
        ) : (
          <div className="space-y-6">
            {questions.map((q, idx) => {
              const selected = selectedAnswers[q.id];
              const isRevealed = revealedExplanations[q.id];

              return (
                <div
                  key={q.id}
                  className="bg-white border border-slate-200 rounded-3xl p-6 sm:p-8 shadow-sm space-y-5"
                >
                  {/* Question Header */}
                  <div className="flex items-start justify-between gap-4 pb-3 border-b border-slate-100">
                    <div className="flex flex-wrap items-center gap-2.5">
                      <span className="font-mono text-xs font-bold text-blue-600">/item-#{idx + 1}</span>
                      <span className="text-xs font-bold text-slate-900">{q.source || `${exam.code} ${q.year}`}</span>
                      <Badge variant="outline" size="sm">{q.specialtyName || 'Geral'}</Badge>
                      <Badge variant={q.difficulty === 'hard' ? 'danger' : q.difficulty === 'medium' ? 'warning' : 'success'} size="sm">
                        {q.difficulty === 'hard' ? 'Difícil' : q.difficulty === 'medium' ? 'Média' : 'Fácil'}
                      </Badge>
                    </div>
                    {q.sourcePage && (
                      <span className="text-3xs font-mono text-slate-400">Pág. {q.sourcePage}</span>
                    )}
                  </div>

                  {/* Statement */}
                  <div className="text-sm sm:text-base text-slate-900 leading-relaxed font-normal">
                    {q.statement}
                  </div>

                  {/* Options */}
                  <div className="space-y-2.5 pt-2">
                    {q.options.map((opt) => {
                      const isOptionSelected = selected === opt.id;
                      const isCorrect = opt.id === q.correctAnswer;
                      let optionClass = 'border-slate-200 hover:border-slate-300 hover:bg-slate-50/50';

                      if (isRevealed) {
                        if (isCorrect) {
                          optionClass = 'border-emerald-500 bg-emerald-50/80 text-emerald-950 font-medium';
                        } else if (isOptionSelected && !isCorrect) {
                          optionClass = 'border-rose-500 bg-rose-50/80 text-rose-950';
                        }
                      } else if (isOptionSelected) {
                        optionClass = 'border-blue-500 bg-blue-50 text-blue-950';
                      }

                      return (
                        <button
                          key={opt.id}
                          onClick={() => handleSelectOption(q.id, opt.id)}
                          className={`w-full text-left p-4 rounded-2xl border transition-all flex items-start gap-3.5 cursor-pointer text-xs sm:text-sm ${optionClass}`}
                        >
                          <span className={`w-6 h-6 rounded-lg flex items-center justify-center font-bold text-xs shrink-0 font-mono ${
                            isRevealed && isCorrect
                              ? 'bg-emerald-600 text-white'
                              : isRevealed && isOptionSelected && !isCorrect
                              ? 'bg-rose-600 text-white'
                              : 'bg-slate-100 text-slate-700'
                          }`}>
                            {opt.id}
                          </span>
                          <span className="flex-1 mt-0.5 leading-relaxed">{opt.text}</span>
                          {isRevealed && isCorrect && (
                            <Check className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                          )}
                          {isRevealed && isOptionSelected && !isCorrect && (
                            <X className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
                          )}
                        </button>
                      );
                    })}
                  </div>

                  {/* Explanation Block */}
                  {isRevealed && q.explanation && (
                    <div className="mt-5 p-5 rounded-2xl bg-slate-50 border border-slate-200 text-xs sm:text-sm text-slate-700 space-y-2 animate-in fade-in">
                      <div className="flex items-center gap-2 font-bold text-slate-900">
                        <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                        Gabarito Oficial: Letra {q.correctAnswer} — Justificativa Clínica
                      </div>
                      <p className="leading-relaxed text-slate-600">{q.explanation}</p>
                      {q.tags && q.tags.length > 0 && (
                        <div className="flex flex-wrap gap-1.5 mt-3 pt-3 border-t border-slate-200/60 font-mono text-3xs">
                          {q.tags.map(t => (
                            <span key={t} className="px-2 py-0.5 bg-white rounded border border-slate-200 text-slate-600">
                              #{t}
                            </span>
                          ))}
                        </div>
                      )}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}
