import React, { useState, useEffect } from 'react';
import { useAuth } from '../../context/AuthContext';
import { useExam } from '../../context/ExamContext';
import { StatCard } from '../../components/common/StatCard';
import { Badge } from '../../components/common/Badge';
import { Button } from '../../components/common/Button';
import { EXAM_FLAGS, formatPercent } from '../../lib/utils';
import { 
  Award, 
  BookOpen, 
  Target, 
  TrendingUp, 
  AlertCircle, 
  CheckCircle2, 
  Play, 
  Clock, 
  FileText, 
  ArrowRight,
  ChevronRight,
  Sparkles,
  Layers,
  Bot
} from 'lucide-react';
import { questionService } from '../../services/questionService';
import { progressService } from '../../services/progressService';
import { Question, StudentProgress } from '../../types';

interface StudentDashboardProps {
  onNavigate: (path: string) => void;
}

export function StudentDashboard({ onNavigate }: StudentDashboardProps) {
  const { user, profile } = useAuth();
  const { selectedExam, exams, setSelectedExamId } = useExam();
  const [questions, setQuestions] = useState<Question[]>([]);
  const [progress, setProgress] = useState<StudentProgress | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function loadData() {
      if (!selectedExam) return;
      setLoading(true);
      try {
        const [qList, prog] = await Promise.all([
          questionService.getQuestions({ examId: selectedExam.id, status: 'approved' }),
          user ? progressService.getStudentProgress(user.uid, selectedExam.id) : null,
        ]);
        setQuestions(qList);
        setProgress(prog);
      } catch (err) {
        console.error('Failed to load student dashboard data:', err);
      } finally {
        setLoading(false);
      }
    }
    loadData();
  }, [selectedExam, user]);

  if (!selectedExam) return null;

  return (
    <div className="space-y-10">
      {/* Editorial Header Section */}
      <header className="border-b border-slate-200 pb-8">
        <div className="flex flex-wrap justify-between items-center gap-3 mb-4">
          <div className="inline-flex items-center gap-2 px-3 py-1 bg-blue-100 text-blue-700 text-xs font-bold rounded-full tracking-wide font-mono">
            <span>{EXAM_FLAGS[selectedExam.countryCode] || '🩺'}</span>
            <span>EXAME ATIVO: {selectedExam.name.toUpperCase()}</span>
          </div>
          <div className="text-slate-400 text-xs font-mono uppercase tracking-widest">
            ESTUDIAMED • AMBIENTE OFICIAL DE PREPARAÇÃO
          </div>
        </div>

        <h1 className="font-editorial text-4xl sm:text-5xl lg:text-6xl font-extrabold tracking-tight text-slate-900 mb-3 leading-none">
          Painel de Estudos Clínicos
        </h1>
        <p className="text-base sm:text-lg text-slate-600 max-w-3xl leading-relaxed">
          Bem-vindo(a), <span className="font-semibold text-slate-900">{profile?.name || 'Doutor(a)'}</span>. Acompanhe seu desempenho diagnóstico, resolva questões de provas anteriores e domine o conteúdo exigido pelo {selectedExam.code}.
        </p>

        <div className="mt-6 flex flex-wrap gap-3">
          <Button
            id="start-study-btn"
            onClick={() => onNavigate(`/exams/${selectedExam.id}`)}
            className="bg-blue-600 hover:bg-blue-700 text-white font-medium"
            icon={<Play className="w-4 h-4 fill-white" />}
          >
            Continuar Estudos do {selectedExam.code}
          </Button>
          <Button
            id="explore-exams-btn"
            variant="outline"
            onClick={() => onNavigate('/exams')}
            icon={<BookOpen className="w-4 h-4" />}
          >
            Catálogo Internacional de Exames
          </Button>
        </div>
      </header>

      {/* Metrics Row */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        <StatCard
          id="stat-accuracy"
          title="Taxa de Precisão"
          value={progress ? formatPercent(progress.accuracyPercentage) : '76.4%'}
          subtitle="Nota de corte histórica: 60.0%"
          icon={<Target className="w-5 h-5" />}
          colorClass="text-emerald-600 bg-emerald-50"
          trend={{ value: '+4.2% esta semana', isPositive: true }}
        />
        <StatCard
          id="stat-questions-done"
          title="Questões Resolvidas"
          value={progress?.totalQuestionsAnswered || '142'}
          subtitle={`${questions.length} questões disponíveis no banco`}
          icon={<CheckCircle2 className="w-5 h-5" />}
          colorClass="text-blue-600 bg-blue-50"
        />
        <StatCard
          id="stat-simulations-done"
          title="Simulados Realizados"
          value="4"
          subtitle="Média ponderada: 72/100"
          icon={<FileText className="w-5 h-5" />}
          colorClass="text-purple-600 bg-purple-50"
        />
        <StatCard
          id="stat-study-time"
          title="Tempo Acumulado"
          value="18h 45m"
          subtitle="Últimos 30 dias de preparação"
          icon={<Clock className="w-5 h-5" />}
          colorClass="text-amber-600 bg-amber-50"
        />
      </div>

      {/* Main Grid: Editorial Layout with 12 Columns */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Left Section: 8 Cols */}
        <section className="lg:col-span-8 space-y-8">
          {/* Active Study Track Card */}
          <div className="bg-white p-6 sm:p-8 rounded-3xl border border-slate-200 shadow-sm space-y-6">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-xs font-bold uppercase tracking-widest text-slate-400">
                  Trilha em Andamento
                </h3>
                <h2 className="font-editorial text-2xl font-bold text-slate-900 mt-1">
                  Clínica Médica & Síndromes Coronarianas
                </h2>
              </div>
              <Badge variant="editorial" size="sm">Módulo 1 de 5</Badge>
            </div>

            <div className="p-5 bg-slate-50 rounded-2xl border border-slate-100 space-y-4">
              <div className="flex items-center justify-between gap-4">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-blue-600 text-white flex items-center justify-center font-bold text-sm">
                    CM
                  </div>
                  <div>
                    <h4 className="text-sm font-bold text-slate-900">Eletrocardiograma & IAM com Supra de ST</h4>
                    <p className="text-xs text-slate-500">20 questões oficiais comentadas item a item</p>
                  </div>
                </div>
                <Button
                  size="sm"
                  onClick={() => onNavigate(`/exams/${selectedExam.id}`)}
                  icon={<Play className="w-3.5 h-3.5" />}
                >
                  Praticar
                </Button>
              </div>

              {/* Progress bar */}
              <div className="w-full bg-slate-200 rounded-full h-2 overflow-hidden">
                <div className="bg-blue-600 h-2 rounded-full" style={{ width: '65%' }} />
              </div>
              <div className="flex justify-between text-2xs font-mono text-slate-500">
                <span>13 / 20 questões finalizadas</span>
                <span>65% de conclusão</span>
              </div>
            </div>

            {/* Questions List for Current Exam */}
            <div>
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-xs font-bold uppercase tracking-widest text-slate-400">
                  Questões Aprovadas Recentes ({selectedExam.code})
                </h3>
                <button
                  onClick={() => onNavigate(`/exams/${selectedExam.id}`)}
                  className="text-xs font-bold text-blue-600 hover:text-blue-700 flex items-center gap-1 cursor-pointer"
                >
                  Ver todas <ChevronRight className="w-3.5 h-3.5" />
                </button>
              </div>

              <div className="space-y-3">
                {questions.slice(0, 3).map((q) => (
                  <div
                    key={q.id}
                    className="p-4 rounded-2xl border border-slate-100 bg-slate-50/50 hover:bg-white hover:border-slate-300 transition-all flex items-start justify-between gap-4"
                  >
                    <div className="space-y-1.5 flex-1">
                      <div className="flex items-center gap-2">
                        <span className="font-mono text-xs font-bold text-blue-600">
                          /q#{q.questionNumber || 1}
                        </span>
                        <span className="text-xs font-bold text-slate-800">• {q.year || 'Oficial'}</span>
                        <Badge variant="outline" size="sm">{q.specialtyName || 'Geral'}</Badge>
                        <Badge variant={q.difficulty === 'hard' ? 'danger' : q.difficulty === 'medium' ? 'warning' : 'success'} size="sm">
                          {q.difficulty === 'hard' ? 'Difícil' : q.difficulty === 'medium' ? 'Média' : 'Fácil'}
                        </Badge>
                      </div>
                      <p className="text-xs text-slate-600 line-clamp-2 leading-relaxed">
                        {q.statement}
                      </p>
                    </div>
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => onNavigate(`/exams/${selectedExam.id}`)}
                      className="shrink-0"
                    >
                      Resolver
                    </Button>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Editorial Double Card Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
            <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-sm">
              <h4 className="font-bold mb-4 flex items-center gap-2 text-slate-900 text-sm">
                <span className="w-2.5 h-2.5 bg-emerald-500 rounded-full"></span>
                Garantias da Plataforma
              </h4>
              <ul className="space-y-3 text-xs text-slate-600">
                <li className="flex justify-between border-b border-slate-100 pb-2">
                  <span>Arquitetura</span>
                  <span className="font-mono font-bold text-emerald-600 uppercase">Multi-Exame</span>
                </li>
                <li className="flex justify-between border-b border-slate-100 pb-2">
                  <span>Segurança RBAC</span>
                  <span className="font-mono font-bold text-emerald-600 uppercase">Estrita</span>
                </li>
                <li className="flex justify-between">
                  <span>Banco de Questões</span>
                  <span className="font-mono font-bold text-emerald-600 uppercase">Comentado</span>
                </li>
              </ul>
            </div>

            <div className="bg-blue-600 p-6 rounded-3xl text-white shadow-xl flex flex-col justify-between">
              <div>
                <p className="text-xs font-mono font-bold uppercase tracking-widest opacity-80 mb-2">
                  Extração Inteligente
                </p>
                <p className="text-base font-medium leading-snug">
                  Pipeline Gemini pronto para extração automática de cadernos de prova oficiais em PDF.
                </p>
              </div>
              <div className="h-1.5 w-full bg-blue-500 rounded-full mt-4 overflow-hidden">
                <div className="h-1.5 w-2/3 bg-white rounded-full"></div>
              </div>
            </div>
          </div>
        </section>

        {/* Right Section: 4 Cols Editorial Dark Card */}
        <section className="lg:col-span-4 bg-slate-900 p-6 sm:p-8 rounded-3xl text-slate-100 flex flex-col justify-between space-y-8">
          <div>
            <h3 className="text-xs font-mono font-bold uppercase tracking-widest text-slate-500 mb-6">
              DIAGNÓSTICO POR ESPECIALIDADE
            </h3>

            <div className="space-y-6">
              <div>
                <div className="flex items-center justify-between text-xs mb-1.5">
                  <span className="font-bold text-slate-200">Ginecologia & Obstetrícia</span>
                  <span className="font-mono text-amber-400 font-bold">48%</span>
                </div>
                <div className="w-full bg-slate-800 rounded-full h-1.5">
                  <div className="bg-amber-400 h-1.5 rounded-full" style={{ width: '48%' }}></div>
                </div>
                <p className="text-3xs text-slate-400 mt-1">Pré-Eclâmpsia, Hemorragias e Parto</p>
              </div>

              <div>
                <div className="flex items-center justify-between text-xs mb-1.5">
                  <span className="font-bold text-slate-200">Medicina Preventiva & SUS</span>
                  <span className="font-mono text-amber-400 font-bold">55%</span>
                </div>
                <div className="w-full bg-slate-800 rounded-full h-1.5">
                  <div className="bg-amber-400 h-1.5 rounded-full" style={{ width: '55%' }}></div>
                </div>
                <p className="text-3xs text-slate-400 mt-1">Epidemiologia, Atenção Primária e Bioética</p>
              </div>

              <div>
                <div className="flex items-center justify-between text-xs mb-1.5">
                  <span className="font-bold text-slate-200">Pediatria & Neonatologia</span>
                  <span className="font-mono text-emerald-400 font-bold">82%</span>
                </div>
                <div className="w-full bg-slate-800 rounded-full h-1.5">
                  <div className="bg-emerald-400 h-1.5 rounded-full" style={{ width: '82%' }}></div>
                </div>
                <p className="text-3xs text-slate-400 mt-1">Puericultura e Calendário Vacinal</p>
              </div>
            </div>
          </div>

          <div className="pt-6 border-t border-slate-800 space-y-3">
            <h4 className="text-xs font-mono font-bold uppercase tracking-widest text-slate-500">
              Alternar Exame de Foco
            </h4>
            <div className="space-y-2">
              {exams.slice(0, 3).map((exam) => (
                <button
                  key={exam.id}
                  onClick={() => setSelectedExamId(exam.id)}
                  className={`w-full text-left p-2.5 rounded-xl border transition-all flex items-center justify-between cursor-pointer ${
                    exam.id === selectedExam.id
                      ? 'bg-slate-800 border-blue-500 text-white'
                      : 'bg-slate-900/50 border-slate-800 text-slate-400 hover:text-white hover:bg-slate-800'
                  }`}
                >
                  <div className="flex items-center gap-2">
                    <span>{EXAM_FLAGS[exam.countryCode] || '🩺'}</span>
                    <span className="text-xs font-bold">{exam.code}</span>
                  </div>
                  {exam.id === selectedExam.id ? (
                    <span className="text-2xs font-mono text-blue-400 font-bold">ATIVO</span>
                  ) : (
                    <ArrowRight className="w-3.5 h-3.5" />
                  )}
                </button>
              ))}
            </div>
          </div>
        </section>
      </div>
    </div>
  );
}
