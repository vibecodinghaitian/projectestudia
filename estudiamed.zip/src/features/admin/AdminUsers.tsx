import React, { useState } from 'react';
import { useAuth } from '../../context/AuthContext';
import { Badge } from '../../components/common/Badge';
import { Button } from '../../components/common/Button';
import { ShieldCheck, UserCheck, Shield, Key } from 'lucide-react';
import { UserRole } from '../../types';

export function AdminUsers() {
  const { user, profile, role } = useAuth();

  const mockUsers = [
    {
      uid: user?.uid || 'admin-01',
      name: profile?.name || 'Administrador Principal',
      email: profile?.email || user?.email || 'wanky7713@gmail.com',
      role: 'admin' as UserRole,
      createdAt: '2026-01-10',
      lastLogin: 'Hoje, 12:45',
      status: 'Ativo',
    },
    {
      uid: 'student-02',
      name: 'Dra. Beatriz Santos',
      email: 'beatriz.med@hospital.com',
      role: 'student' as UserRole,
      createdAt: '2026-02-01',
      lastLogin: 'Ontem, 19:20',
      status: 'Ativo',
    },
    {
      uid: 'student-03',
      name: 'Dr. Carlos Mendoza',
      email: 'carlos.mendoza@med.mx',
      role: 'student' as UserRole,
      createdAt: '2026-02-14',
      lastLogin: '18/02/2026',
      status: 'Ativo',
    },
  ];

  return (
    <div className="space-y-8">
      {/* Editorial Header */}
      <header className="border-b border-slate-200 pb-6 flex flex-col sm:flex-row sm:items-end justify-between gap-4">
        <div>
          <div className="inline-flex items-center gap-2 px-3 py-1 bg-blue-100 text-blue-700 text-xs font-bold rounded-full tracking-wide font-mono mb-3">
            <Shield className="w-3.5 h-3.5" />
            <span>SEGURANÇA & RBAC</span>
          </div>
          <h1 className="font-editorial text-4xl font-extrabold tracking-tight text-slate-900 leading-none">
            Usuários & Matriz de Permissões
          </h1>
          <p className="text-sm text-slate-500 mt-2">
            Controle estrito de acesso baseado em papéis (ADMIN e STUDENT) protegido pelas regras de segurança do Firestore.
          </p>
        </div>
      </header>

      {/* RBAC Matrix Card */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-slate-900 text-white rounded-3xl p-6 sm:p-8 border border-slate-800 space-y-4 shadow-sm">
          <div className="flex items-center gap-2.5">
            <div className="w-3 h-3 rounded-full bg-rose-500 shrink-0"></div>
            <h3 className="font-bold text-sm uppercase tracking-widest font-mono text-slate-200">
              PAPEL ADMIN (GERÊNCIA)
            </h3>
          </div>
          <ul className="text-xs space-y-2 text-slate-300 border-l border-slate-800 ml-1.5 pl-4">
            <li>• Gerenciamento completo do catálogo de exames multi-banca</li>
            <li>• Upload de cadernos PDF no bucket de storage</li>
            <li>• Homologação, aprovação e edição de questões extraídas por IA</li>
            <li>• Visualização global de telemetria e métricas da plataforma</li>
          </ul>
        </div>

        <div className="bg-white text-slate-900 rounded-3xl p-6 sm:p-8 border border-slate-200 space-y-4 shadow-sm">
          <div className="flex items-center gap-2.5">
            <div className="w-3 h-3 rounded-full bg-blue-500 shrink-0"></div>
            <h3 className="font-bold text-sm uppercase tracking-widest font-mono text-slate-700">
              PAPEL ALUNO (ESTUDANTE)
            </h3>
          </div>
          <ul className="text-xs space-y-2 text-slate-600 border-l border-slate-200 ml-1.5 pl-4">
            <li>• Acesso restrito a questões com status <code>approved</code></li>
            <li>• Realização de simulados e resolução comentada de itens</li>
            <li>• Registro exclusivo do seu próprio histórico de estudo</li>
            <li>• Isolamento estrito de dados por ID de usuário (Firestore Rules)</li>
          </ul>
        </div>
      </div>

      {/* Users Table */}
      <div className="bg-white border border-slate-200 rounded-3xl overflow-hidden shadow-sm">
        <div className="px-6 py-4 border-b border-slate-200 bg-slate-50/80 flex items-center justify-between">
          <span className="text-xs font-bold uppercase tracking-widest text-slate-400">
            Diretório de Acessos Registrados
          </span>
          <Badge variant="editorial" size="sm">Controle Ativo</Badge>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50/80 border-b border-slate-200 text-slate-400 font-mono font-bold uppercase tracking-wider">
              <tr>
                <th className="px-6 py-4">Usuário</th>
                <th className="px-6 py-4">E-mail</th>
                <th className="px-6 py-4">Papel (RBAC)</th>
                <th className="px-6 py-4">Último Acesso</th>
                <th className="px-6 py-4 text-right">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-slate-700">
              {mockUsers.map((u) => (
                <tr key={u.uid} className="hover:bg-slate-50/70 transition-colors">
                  <td className="px-6 py-4">
                    <p className="font-bold text-slate-900">{u.name}</p>
                    <p className="text-3xs font-mono text-slate-400 mt-0.5">UID: {u.uid}</p>
                  </td>
                  <td className="px-6 py-4 font-mono text-slate-600">
                    {u.email}
                  </td>
                  <td className="px-6 py-4">
                    <Badge variant={u.role === 'admin' ? 'dark' : 'info'} dot>
                      {u.role.toUpperCase()}
                    </Badge>
                  </td>
                  <td className="px-6 py-4 font-mono text-slate-500">
                    {u.lastLogin}
                  </td>
                  <td className="px-6 py-4 text-right">
                    <Badge variant="success">
                      {u.status}
                    </Badge>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
