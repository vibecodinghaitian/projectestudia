import React, { useState, useEffect } from 'react';
import { StatCard } from '../../components/common/StatCard';
import { Badge } from '../../components/common/Badge';
import { Button } from '../../components/common/Button';
import { 
  FileText, 
  HelpCircle, 
  Layers, 
  UploadCloud, 
  ShieldCheck, 
  CheckCircle2, 
  Clock, 
  Bot
} from 'lucide-react';
import { questionService } from '../../services/questionService';
import { examService } from '../../services/examService';
import { importService } from '../../services/importService';
import { Question, Exam, QuestionImport } from '../../types';
import { formatDate } from '../../lib/utils';

interface AdminOverviewProps {
  onNavigate: (path: string) => void;
}

export function AdminOverview({ onNavigate }: AdminOverviewProps) {
  const [questions, setQuestions] = useState<Question[]>([]);
  const [exams, setExams] = useState<Exam[]>([]);
  const [imports, setImports] = useState<QuestionImport[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function loadStats() {
      setLoading(true);
      try {
        const [qList, eList, iList] = await Promise.all([
          questionService.getQuestions(),
          examService.getAllExams(),
          importService.getImports(),
        ]);
        setQuestions(qList);
        setExams(eList);
        setImports(iList);
      } catch (err) {
        console.error('Failed to load admin stats:', err);
      } finally {
        setLoading(false);
      }
    }
    loadStats();
  }, []);

  const pendingQuestionsCount = questions.filter(q => q.status === 'pending_review').length;
  const approvedQuestionsCount = questions.filter(q => q.status === 'approved').length;
  const activeExamsCount = exams.filter(e => e.active).length;

  return (
    <div className="space-y-10">
      {/* Editorial Header */}
      <header className="border-b border-slate-200 pb-8">
        <div className="flex flex-wrap justify-between items-center gap-3 mb-4">
          <div className="inline-flex items-center gap-2 px-3 py-1 bg-slate-900 text-white text-xs font-bold rounded-full tracking-wide font-mono">
            <ShieldCheck className="w-3.5 h-3.5 text-blue-400" />
            <span>PAINEL DE ADMINISTRAÇÃO & RBAC</span>
          </div>
          <div className="text-slate-400 text-xs font-mono uppercase tracking-widest">
            ESTUDIAMED CORE CONTROL
          </div>
        </div>

        <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-6">
          <div>
            <h1 className="font-editorial text-4xl sm:text-5xl lg:text-6xl font-extrabold tracking-tight text-slate-900 mb-3 leading-none">
              Arquitetura & Gestão Geral
            </h1>
            <p className="text-base sm:text-lg text-slate-600 max-w-3xl leading-relaxed">
              Supervisão centralizada de bancas de exames médicos, fila de aprovação de questões extraídas por IA e controle de acesso baseado em papéis.
            </p>
          </div>

          <div className="flex flex-wrap gap-2.5 shrink-0">
            <Button
              id="admin-new-import-btn"
              onClick={() => onNavigate('/admin/imports')}
              className="bg-blue-600 hover:bg-blue-700 text-white font-medium"
              icon={<UploadCloud className="w-4 h-4" />}
            >
              Importar PDF Oficial
            </Button>
            <Button
              id="admin-manage-questions-btn"
              variant="outline"
              onClick={() => onNavigate('/admin/questions')}
              icon={<HelpCircle className="w-4 h-4" />}
            >
              Fila de Revisão ({pendingQuestionsCount})
            </Button>
          </div>
        </div>
      </header>

      {/* Metrics Row */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        <StatCard
          id="admin-stat-total-questions"
          title="Total de Questões"
          value={questions.length}
          subtitle={`${approvedQuestionsCount} validadas no banco ativo`}
          icon={<HelpCircle className="w-5 h-5" />}
          colorClass="text-blue-600 bg-blue-50"
        />
        <StatCard
          id="admin-stat-pending-review"
          title="Aguardando Revisão"
          value={pendingQuestionsCount}
          subtitle="Extraídas por IA pendentes de validação"
          icon={<Clock className="w-5 h-5" />}
          colorClass="text-amber-600 bg-amber-50"
          trend={{ value: `${pendingQuestionsCount} pendentes`, isPositive: false }}
        />
        <StatCard
          id="admin-stat-exams"
          title="Exames Suportados"
          value={exams.length}
          subtitle={`${activeExamsCount} disponíveis para alunos`}
          icon={<Layers className="w-5 h-5" />}
          colorClass="text-emerald-600 bg-emerald-50"
        />
        <StatCard
          id="admin-stat-imports"
          title="Processamentos PDF"
          value={imports.length}
          subtitle="Lotes gerenciados"
          icon={<FileText className="w-5 h-5" />}
          colorClass="text-purple-600 bg-purple-50"
        />
      </div>

      {/* Editorial Grid Sections */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Left Section: 7 Cols */}
        <section className="lg:col-span-7 space-y-8">
          {/* Pending Questions Card */}
          <div className="bg-white border border-slate-200 rounded-3xl p-6 sm:p-8 shadow-sm space-y-6">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-xs font-bold uppercase tracking-widest text-slate-400">
                  Fila de Homologação
                </h3>
                <h2 className="font-editorial text-2xl font-bold text-slate-900 mt-1">
                  Questões Pendentes de Revisão
                </h2>
              </div>
              <Button size="sm" variant="outline" onClick={() => onNavigate('/admin/questions')}>
                Ver Fila Completa
              </Button>
            </div>

            <div className="space-y-3">
              {questions.filter(q => q.status === 'pending_review').length === 0 ? (
                <div className="p-6 text-center text-xs text-slate-500 bg-slate-50 rounded-2xl border border-slate-100">
                  <CheckCircle2 className="w-8 h-8 text-emerald-500 mx-auto mb-2" />
                  Nenhuma questão pendente no momento. Todas as extrações foram revisadas.
                </div>
              ) : (
                questions.filter(q => q.status === 'pending_review').slice(0, 3).map((q) => (
                  <div key={q.id} className="p-4 rounded-2xl border border-slate-200 bg-slate-50/50 space-y-2">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <Badge variant="warning" size="sm">Pendente</Badge>
                        <span className="font-mono text-xs font-bold text-slate-900">/q#{q.questionNumber || 1} • {q.year}</span>
                        <span className="text-xs text-slate-500">{q.specialtyName || 'Especialidade'}</span>
                      </div>
                      <span className="text-3xs font-mono text-slate-400">{q.source}</span>
                    </div>
                    <p className="text-xs text-slate-600 line-clamp-2 leading-relaxed">{q.statement}</p>
                    <div className="flex justify-end gap-2 pt-2 border-t border-slate-200/60">
                      <Button size="sm" variant="outline" onClick={() => onNavigate('/admin/questions')}>
                        Revisar & Aprovar
                      </Button>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>

          {/* Double Grid Features */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
            <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-sm">
              <h4 className="font-bold mb-4 flex items-center gap-2 text-slate-900 text-sm">
                <span className="w-2.5 h-2.5 bg-emerald-500 rounded-full"></span>
                Status das Coleções Firestore
              </h4>
              <div className="space-y-2 font-mono text-xs text-slate-600">
                <div className="flex justify-between border-b border-slate-100 pb-1.5">
                  <span className="text-blue-600 font-semibold">/exams</span>
                  <span className="text-emerald-700 font-bold">ONLINE</span>
                </div>
                <div className="flex justify-between border-b border-slate-100 pb-1.5">
                  <span className="text-blue-600 font-semibold">/questions</span>
                  <span className="text-emerald-700 font-bold">ONLINE</span>
                </div>
                <div className="flex justify-between border-b border-slate-100 pb-1.5">
                  <span className="text-blue-600 font-semibold">/questionImports</span>
                  <span className="text-emerald-700 font-bold">ONLINE</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-blue-600 font-semibold">/studentProgress</span>
                  <span className="text-emerald-700 font-bold">ONLINE</span>
                </div>
              </div>
            </div>

            <div className="bg-blue-600 p-6 rounded-3xl text-white shadow-xl flex flex-col justify-between">
              <div>
                <p className="text-xs font-mono font-bold uppercase tracking-widest opacity-80 mb-2">
                  IA & OCR Pipeline
                </p>
                <p className="text-base font-medium leading-snug">
                  Estrutura de storage `/exam-pdfs/[examId]/[year]/` configurada para ingestão direta com Gemini.
                </p>
              </div>
              <div className="h-1.5 w-full bg-blue-500 rounded-full mt-4 overflow-hidden">
                <div className="h-1.5 w-full bg-white rounded-full"></div>
              </div>
            </div>
          </div>
        </section>

        {/* Right Section: 5 Cols Editorial Dark Card */}
        <section className="lg:col-span-5 bg-slate-900 p-6 sm:p-8 rounded-3xl text-slate-100 flex flex-col justify-between space-y-6">
          <div>
            <h3 className="text-xs font-mono font-bold uppercase tracking-widest text-slate-500 mb-6">
              HISTÓRICO DE IMPORTAÇÃO (GEMINI PIPELINE)
            </h3>

            <div className="space-y-4">
              {imports.map((imp) => (
                <div key={imp.id} className="p-4 rounded-2xl bg-slate-800/80 border border-slate-700/80 space-y-2">
                  <div className="flex items-start justify-between gap-2">
                    <div className="flex items-start gap-2.5">
                      <div className="p-2 bg-blue-500/20 text-blue-400 rounded-lg shrink-0 mt-0.5">
                        <FileText className="w-4 h-4" />
                      </div>
                      <div>
                        <p className="text-xs font-bold text-slate-100 truncate max-w-[180px]">
                          {imp.fileName}
                        </p>
                        <p className="text-3xs font-mono text-slate-400 mt-0.5">
                          {imp.examId} • {imp.year}
                        </p>
                      </div>
                    </div>
                    <Badge variant={imp.status === 'completed' ? 'success' : 'info'} size="sm">
                      {imp.status}
                    </Badge>
                  </div>

                  <div className="flex items-center justify-between text-3xs font-mono text-slate-400 pt-2 border-t border-slate-700/60">
                    <span>{imp.processedQuestions} / {imp.totalQuestions} processadas</span>
                    <span className="text-emerald-400 font-bold">{imp.approvedQuestions} aprovadas</span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="pt-6 border-t border-slate-800">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs font-bold text-white">Pipeline de Extração</p>
                <p className="text-3xs font-mono text-slate-500 mt-0.5">Pronto para a próxima etapa</p>
              </div>
              <Button size="sm" variant="dark" onClick={() => onNavigate('/admin/imports')}>
                Ver Lotes
              </Button>
            </div>
          </div>
        </section>
      </div>
    </div>
  );
}
