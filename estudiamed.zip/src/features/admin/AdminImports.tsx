import React, { useState, useEffect } from 'react';
import { useExam } from '../../context/ExamContext';
import { Badge } from '../../components/common/Badge';
import { Button } from '../../components/common/Button';
import { Modal } from '../../components/common/Modal';
import { 
  UploadCloud, 
  FileText, 
  CheckCircle2, 
  Clock, 
  Sparkles, 
  Bot,
  AlertTriangle,
  Play,
  RefreshCw,
  ExternalLink,
  Layers,
  ArrowRight,
  Database,
  Trash2
} from 'lucide-react';
import { importService } from '../../services/importService';
import { QuestionImport } from '../../types';
import { formatDate } from '../../lib/utils';

interface AdminImportsProps {
  onNavigate?: (path: string) => void;
}

export function AdminImports({ onNavigate }: AdminImportsProps) {
  const { exams, selectedExam } = useExam();
  const [imports, setImports] = useState<QuestionImport[]>([]);
  const [loading, setLoading] = useState(true);

  // New import modal
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [targetExamId, setTargetExamId] = useState('revalida-br');
  const [targetYear, setTargetYear] = useState(2024);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [uploading, setUploading] = useState(false);
  const [sampleLoading, setSampleLoading] = useState(false);

  const loadImports = async () => {
    setLoading(true);
    try {
      const list = await importService.getImports();
      setImports(list);
    } catch (err) {
      console.error('Failed to load imports:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadImports();
  }, []);

  // Poll active processing jobs
  useEffect(() => {
    const hasActiveProcessing = imports.some(i => i.status === 'processing');
    if (!hasActiveProcessing) return;

    const interval = setInterval(async () => {
      const updatedList = await importService.getImports();
      setImports(updatedList);
    }, 2500);

    return () => clearInterval(interval);
  }, [imports]);

  const handleCreateAndProcessImport = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedFile) return;

    setUploading(true);
    try {
      // 1. Upload to private storage
      const uploadedRecord = await importService.uploadExamPdf({
        file: selectedFile,
        examId: targetExamId,
        year: Number(targetYear),
        userId: 'admin-user',
      });

      setIsModalOpen(false);
      setSelectedFile(null);
      await loadImports();

      // 2. Trigger Gemini server-side processing
      await importService.processExamPdf({
        importId: uploadedRecord.id,
        examId: targetExamId,
        year: Number(targetYear),
        fileName: uploadedRecord.fileName,
      });

      await loadImports();

      // Navigate to detail page if navigator provided
      if (onNavigate) {
        onNavigate(`/admin/imports/${uploadedRecord.id}`);
      }
    } catch (err: any) {
      console.error('Failed to upload and process import:', err);
      alert(`Erro no upload: ${err.message}`);
    } finally {
      setUploading(false);
    }
  };

  const handleTriggerGemini = async (imp: QuestionImport) => {
    try {
      await importService.processExamPdf({
        importId: imp.id,
        examId: imp.examId,
        year: imp.year,
        fileName: imp.fileName,
        forceReprocess: true,
      });
      await loadImports();
    } catch (err: any) {
      console.error('Error triggering gemini process:', err);
      alert(`Falha ao executar pipeline: ${err.message}`);
    }
  };

  const handleCreateSampleRevalida = async () => {
    setSampleLoading(true);
    try {
      const sample = await importService.createSampleRevalidaImport();
      await loadImports();
      if (onNavigate) {
        onNavigate(`/admin/imports/${sample.id}`);
      }
    } catch (err: any) {
      console.error('Error creating sample revalida:', err);
      alert(`Erro: ${err.message}`);
    } finally {
      setSampleLoading(false);
    }
  };

  const handleDeleteImport = async (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    if (!window.confirm('Deseja realmente remover este registro de importação?')) return;
    try {
      await importService.deleteImport(id);
      await loadImports();
    } catch (err: any) {
      alert(`Erro ao excluir: ${err.message}`);
    }
  };

  return (
    <div className="space-y-8 animate-in fade-in duration-300">
      
      {/* Editorial Header */}
      <header className="border-b border-slate-200 pb-6 flex flex-col sm:flex-row sm:items-end justify-between gap-4">
        <div>
          <div className="inline-flex items-center gap-2 px-3 py-1 bg-blue-100 text-blue-700 text-xs font-bold rounded-full tracking-wide font-mono mb-3">
            <Bot className="w-3.5 h-3.5" />
            <span>PIPELINE GEMINI MULTIMODAL OCR</span>
          </div>
          <h1 className="font-editorial text-4xl font-extrabold tracking-tight text-slate-900 leading-none">
            Ingestão de Cadernos & PDFs
          </h1>
          <p className="text-sm text-slate-500 mt-2">
            Upload de cadernos de prova oficiais em PDF para extração estruturada de questões com IA, validação estrutural e homologação administrativa.
          </p>
        </div>

        <div className="flex items-center gap-2.5">
          <button
            type="button"
            disabled={sampleLoading}
            onClick={handleCreateSampleRevalida}
            className="px-4 py-2.5 rounded-2xl text-xs font-bold bg-slate-900 text-white hover:bg-slate-800 transition-all flex items-center gap-2 shadow-sm disabled:opacity-50"
          >
            <Sparkles className={`w-4 h-4 text-amber-400 ${sampleLoading ? 'animate-spin' : ''}`} />
            {sampleLoading ? 'Processando INEP...' : 'Testar Caderno REVALIDA'}
          </button>

          <Button
            id="admin-upload-pdf-btn"
            onClick={() => {
              setTargetExamId(selectedExam?.id || 'revalida-br');
              setIsModalOpen(true);
            }}
            icon={<UploadCloud className="w-4 h-4" />}
          >
            Carregar Novo Caderno PDF
          </Button>
        </div>
      </header>

      {/* 4-Step Architecture Banner */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-3 bg-slate-900 text-white p-6 rounded-3xl border border-slate-800 shadow-sm">
        <div className="space-y-1">
          <div className="flex items-center gap-2 text-blue-400 text-3xs font-mono font-bold uppercase tracking-wider">
            <span>Passo 1</span>
          </div>
          <h4 className="text-xs font-bold text-slate-100">Upload Privado</h4>
          <p className="text-3xs text-slate-400 leading-relaxed font-mono">
            Armazenamento seguro em <code>exam-pdfs/[exame]/[ano]/</code>
          </p>
        </div>

        <div className="space-y-1">
          <div className="flex items-center gap-2 text-purple-400 text-3xs font-mono font-bold uppercase tracking-wider">
            <span>Passo 2</span>
          </div>
          <h4 className="text-xs font-bold text-slate-100">Gemini 3.7 Flash</h4>
          <p className="text-3xs text-slate-400 leading-relaxed font-mono">
            Extração de enunciados, opções A-E, páginas e justificativas.
          </p>
        </div>

        <div className="space-y-1">
          <div className="flex items-center gap-2 text-amber-400 text-3xs font-mono font-bold uppercase tracking-wider">
            <span>Passo 3</span>
          </div>
          <h4 className="text-xs font-bold text-slate-100">Validação & Duplicatas</h4>
          <p className="text-3xs text-slate-400 leading-relaxed font-mono">
            Verificação estrutural e detecção de duplicidades com o banco.
          </p>
        </div>

        <div className="space-y-1">
          <div className="flex items-center gap-2 text-emerald-400 text-3xs font-mono font-bold uppercase tracking-wider">
            <span>Passo 4</span>
          </div>
          <h4 className="text-xs font-bold text-slate-100">Homologação Admin</h4>
          <p className="text-3xs text-slate-400 leading-relaxed font-mono">
            Todas iniciam como <code>pending_review</code> antes de ir aos alunos.
          </p>
        </div>
      </div>

      {/* List of Imports */}
      <div className="bg-white border border-slate-200 rounded-3xl overflow-hidden shadow-sm">
        <div className="px-6 py-4 border-b border-slate-200 bg-slate-50/80 flex items-center justify-between">
          <span className="text-xs font-bold uppercase tracking-widest text-slate-500 font-mono">
            Lotes de Importação Registrados ({imports.length})
          </span>
          <Badge variant="editorial" size="sm">Pipeline Integrado</Badge>
        </div>

        <div className="divide-y divide-slate-100">
          {loading ? (
            <div className="p-12 text-center text-slate-400 text-xs font-mono">
              <RefreshCw className="w-6 h-6 animate-spin mx-auto mb-2 text-blue-600" />
              Carregando lotes de importação...
            </div>
          ) : imports.length === 0 ? (
            <div className="p-12 text-center text-slate-400 text-xs">
              <FileText className="w-8 h-8 mx-auto mb-2 text-slate-300" />
              <p>Nenhum lote de importação registrado ainda.</p>
              <p className="text-3xs text-slate-400 mt-1 font-mono">Faça o upload de um PDF ou clique em "Testar Caderno REVALIDA".</p>
            </div>
          ) : (
            imports.map((imp) => {
              const isProcessing = imp.status === 'processing';
              const isCompleted = imp.status === 'completed';
              const isReviewed = imp.status === 'reviewed';

              return (
                <div 
                  key={imp.id} 
                  onClick={() => onNavigate && onNavigate(`/admin/imports/${imp.id}`)}
                  className="p-6 flex flex-col sm:flex-row sm:items-center justify-between gap-4 hover:bg-slate-50/70 transition-colors cursor-pointer"
                >
                  <div className="flex items-start gap-4 flex-1">
                    <div className="p-3 bg-blue-50 text-blue-600 rounded-2xl shrink-0 mt-1 border border-blue-100">
                      <FileText className="w-6 h-6" />
                    </div>

                    <div className="space-y-1.5 flex-1">
                      <div className="flex items-center gap-2.5 flex-wrap">
                        <h4 className="font-bold text-slate-900 text-sm font-sans">{imp.fileName}</h4>
                        <span className={`px-2.5 py-0.5 rounded-full text-3xs font-mono font-semibold uppercase tracking-wider ${
                          isCompleted
                            ? 'bg-emerald-100 text-emerald-800'
                            : isReviewed
                            ? 'bg-blue-100 text-blue-800'
                            : isProcessing
                            ? 'bg-amber-100 text-amber-800 animate-pulse'
                            : imp.status === 'partially_completed'
                            ? 'bg-amber-100 text-amber-900'
                            : imp.status === 'failed'
                            ? 'bg-rose-100 text-rose-800'
                            : 'bg-slate-100 text-slate-700'
                        }`}>
                          {imp.status === 'completed'
                            ? 'Extração Concluída'
                            : imp.status === 'reviewed'
                            ? '100% Homologado'
                            : imp.status === 'processing'
                            ? 'Processando com Gemini...'
                            : imp.status === 'partially_completed'
                            ? 'Extração com Alertas'
                            : imp.status === 'failed'
                            ? 'Falha'
                            : 'Aguardando Processamento'}
                        </span>
                      </div>

                      {/* Progress bar if processing */}
                      {isProcessing && (
                        <div className="w-full max-w-md space-y-1">
                          <div className="w-full h-1.5 rounded-full bg-amber-100 overflow-hidden">
                            <div 
                              className="h-full bg-amber-500 rounded-full transition-all duration-300"
                              style={{ width: `${imp.progressPercent || 30}%` }}
                            />
                          </div>
                          <p className="text-3xs text-amber-700 font-mono">
                            {imp.stage || 'Extraindo com Gemini...'}
                          </p>
                        </div>
                      )}

                      <div className="flex flex-wrap items-center gap-2 text-3xs font-mono text-slate-500">
                        <span>Exame: <strong className="text-slate-800 uppercase">{imp.examId}</strong></span>
                        <span>•</span>
                        <span>Ano: <strong>{imp.year || '—'}</strong></span>
                        <span>•</span>
                        <span>Storage: <code className="bg-slate-100 px-1 py-0.5 rounded text-slate-700">{imp.storagePath}</code></span>
                      </div>

                      <div className="flex flex-wrap items-center gap-3 text-xs text-slate-600 pt-1">
                        <span>Total: <strong>{imp.totalQuestions || 0} questões</strong></span>
                        <span>•</span>
                        <span className="text-amber-700 font-medium">{imp.pendingReviewQuestions ?? (imp.totalQuestions - imp.approvedQuestions)} aguardando revisão</span>
                        <span>•</span>
                        <span className="text-emerald-700 font-bold">{imp.approvedQuestions || 0} aprovadas</span>
                      </div>
                    </div>
                  </div>

                  {/* Actions column */}
                  <div className="flex items-center gap-2 self-end sm:self-center shrink-0">
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        handleTriggerGemini(imp);
                      }}
                      className="px-3 py-1.5 rounded-xl text-xs font-semibold text-slate-700 bg-white border border-slate-300 hover:bg-slate-100 transition-colors flex items-center gap-1.5 shadow-sm"
                      title="Executar ou reprocessar com Gemini AI"
                    >
                      <RefreshCw className="w-3.5 h-3.5" />
                      {isCompleted || isReviewed ? 'Reprocessar' : 'Processar IA'}
                    </button>

                    <button
                      type="button"
                      onClick={() => onNavigate && onNavigate(`/admin/imports/${imp.id}`)}
                      className="px-3.5 py-1.5 rounded-xl text-xs font-bold text-white bg-blue-600 hover:bg-blue-700 transition-colors flex items-center gap-1.5 shadow-sm"
                    >
                      <span>Homologar</span>
                      <ArrowRight className="w-3.5 h-3.5" />
                    </button>

                    <button
                      type="button"
                      onClick={(e) => handleDeleteImport(imp.id, e)}
                      className="p-1.5 rounded-lg text-slate-400 hover:text-rose-600 hover:bg-rose-50 transition-colors"
                      title="Excluir Lote"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              );
            })
          )}
        </div>
      </div>

      {/* Modal Upload */}
      <Modal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        title="Enviar Caderno de Prova (PDF)"
        description="O arquivo será armazenado na estrutura privada /exam-pdfs/[examId]/[year]/ e enviado ao Gemini 3.7 Flash para extração multimodal estruturada."
      >
        <form onSubmit={handleCreateAndProcessImport} className="space-y-4">
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Exame Alvo</label>
              <select
                value={targetExamId}
                onChange={e => setTargetExamId(e.target.value)}
                className="w-full px-3 py-2 text-xs border border-slate-300 rounded-xl focus:outline-none focus:border-blue-600"
              >
                {exams.map(e => (
                  <option key={e.id} value={e.id}>{e.name} ({e.code})</option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Ano da Edição</label>
              <input
                type="number"
                value={targetYear}
                onChange={e => setTargetYear(Number(e.target.value))}
                className="w-full px-3 py-2 text-xs border border-slate-300 rounded-xl focus:outline-none focus:border-blue-600 font-mono"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">Arquivo PDF Oficial</label>
            <div className="border-2 border-dashed border-slate-300 rounded-2xl p-6 text-center hover:border-blue-500 transition-colors bg-slate-50/50">
              <UploadCloud className="w-8 h-8 text-slate-400 mx-auto mb-2" />
              <input
                type="file"
                accept=".pdf,application/pdf"
                id="pdf-file-input"
                className="hidden"
                onChange={e => {
                  if (e.target.files && e.target.files[0]) {
                    setSelectedFile(e.target.files[0]);
                  }
                }}
              />
              <label
                htmlFor="pdf-file-input"
                className="text-xs font-bold text-blue-600 hover:text-blue-700 cursor-pointer block"
              >
                {selectedFile ? selectedFile.name : 'Selecione um arquivo PDF ou arraste aqui'}
              </label>
              <p className="text-3xs text-slate-400 mt-1 font-mono">Suporte a PDFs de provas até 50MB</p>
            </div>
          </div>

          <div className="p-3 rounded-xl bg-blue-50 border border-blue-100 text-3xs text-blue-800 space-y-1 font-mono">
            <p className="font-bold">Caminho de Destino no Storage Privado:</p>
            <p className="truncate">exam-pdfs/{targetExamId}/{targetYear}/{selectedFile ? selectedFile.name : '[nome_do_arquivo.pdf]'}</p>
          </div>

          <div className="flex justify-end gap-2 pt-4 border-t border-slate-100">
            <Button
              type="button"
              variant="outline"
              size="sm"
              onClick={() => setIsModalOpen(false)}
            >
              Cancelar
            </Button>
            <Button
              type="submit"
              size="sm"
              loading={uploading}
              disabled={!selectedFile}
              icon={<Sparkles className="w-3.5 h-3.5" />}
            >
              Iniciar Upload & Extração Gemini
            </Button>
          </div>
        </form>
      </Modal>
    </div>
  );
}
