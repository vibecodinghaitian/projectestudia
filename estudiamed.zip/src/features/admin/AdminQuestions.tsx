import React, { useState, useEffect } from 'react';
import { useExam } from '../../context/ExamContext';
import { Badge } from '../../components/common/Badge';
import { Button } from '../../components/common/Button';
import { Modal } from '../../components/common/Modal';
import { Tabs } from '../../components/common/Tabs';
import { 
  Plus, 
  Check, 
  X, 
  Trash2, 
  Edit, 
  HelpCircle,
  Search,
  AlertTriangle,
  Eye,
  Filter,
  Layers,
  Sparkles
} from 'lucide-react';
import { questionService } from '../../services/questionService';
import { Question, QuestionStatus, QuestionOption } from '../../types';
import { QuestionReviewModal } from '../../components/admin/QuestionReviewModal';

export function AdminQuestions() {
  const { exams, selectedExam, specialties } = useExam();
  const [questions, setQuestions] = useState<Question[]>([]);
  const [activeStatus, setActiveStatus] = useState<QuestionStatus | 'all'>('all');
  const [selectedExamFilter, setSelectedExamFilter] = useState<string>('all');
  const [selectedSpecialtyFilter, setSelectedSpecialtyFilter] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [loading, setLoading] = useState(true);

  // Review Modal state
  const [reviewingQuestion, setReviewingQuestion] = useState<Question | null>(null);
  const [isReviewModalOpen, setIsReviewModalOpen] = useState(false);

  // Manual Add Modal state
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingQuestion, setEditingQuestion] = useState<Question | null>(null);
  const [statement, setStatement] = useState('');
  const [examId, setExamId] = useState('revalida-br');
  const [specialtyId, setSpecialtyId] = useState('clinica-medica');
  const [year, setYear] = useState(2024);
  const [questionNumber, setQuestionNumber] = useState(1);
  const [correctAnswer, setCorrectAnswer] = useState('A');
  const [explanation, setExplanation] = useState('');
  const [status, setStatus] = useState<QuestionStatus>('approved');
  const [difficulty, setDifficulty] = useState<'easy' | 'medium' | 'hard'>('medium');
  const [source, setSource] = useState('INEP REVALIDA 2024');
  const [options, setOptions] = useState<QuestionOption[]>([
    { id: 'A', text: '' },
    { id: 'B', text: '' },
    { id: 'C', text: '' },
    { id: 'D', text: '' },
    { id: 'E', text: '' },
  ]);

  const loadQuestions = async () => {
    setLoading(true);
    try {
      const list = await questionService.getQuestions({
        examId: selectedExamFilter !== 'all' ? selectedExamFilter : undefined,
        status: activeStatus !== 'all' ? activeStatus : undefined,
        specialtyId: selectedSpecialtyFilter !== 'all' ? selectedSpecialtyFilter : undefined,
        search: searchQuery,
      });
      setQuestions(list);
    } catch (err) {
      console.error('Error loading questions:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadQuestions();
  }, [activeStatus, selectedExamFilter, selectedSpecialtyFilter, searchQuery]);

  const handleOpenCreate = () => {
    setEditingQuestion(null);
    setStatement('');
    setExamId(selectedExam?.id || 'revalida-br');
    setSpecialtyId('clinica-medica');
    setYear(2024);
    setQuestionNumber(questions.length + 1);
    setCorrectAnswer('A');
    setExplanation('');
    setStatus('approved');
    setDifficulty('medium');
    setSource('Caderno Oficial');
    setOptions([
      { id: 'A', text: '' },
      { id: 'B', text: '' },
      { id: 'C', text: '' },
      { id: 'D', text: '' },
      { id: 'E', text: '' },
    ]);
    setIsModalOpen(true);
  };

  const handleOpenReview = (q: Question) => {
    setReviewingQuestion(q);
    setIsReviewModalOpen(true);
  };

  const handleSaveModal = async (updated: Question) => {
    await questionService.updateQuestion(updated.id, updated);
    await loadQuestions();
  };

  const handleApproveModal = async (qId: string) => {
    await questionService.updateStatus(qId, 'approved');
    await loadQuestions();
  };

  const handleRejectModal = async (qId: string) => {
    await questionService.updateStatus(qId, 'rejected');
    await loadQuestions();
  };

  const handleSaveManual = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!statement || !correctAnswer) return;

    try {
      const spec = specialties.find(s => s.id === specialtyId);
      if (editingQuestion) {
        await questionService.updateQuestion(editingQuestion.id, {
          statement,
          examId,
          specialtyId,
          specialtyName: spec?.name || 'Clínica Médica',
          year: Number(year),
          questionNumber: Number(questionNumber),
          options,
          correctAnswer,
          explanation,
          status,
          difficulty,
          source,
        });
      } else {
        await questionService.createQuestion({
          statement,
          examId,
          specialtyId,
          specialtyName: spec?.name || 'Clínica Médica',
          year: Number(year),
          questionNumber: Number(questionNumber),
          options,
          correctAnswer,
          explanation,
          status,
          difficulty,
          source,
        });
      }
      setIsModalOpen(false);
      await loadQuestions();
    } catch (err) {
      console.error('Failed to save question:', err);
    }
  };

  const handleStatusChange = async (qId: string, newStatus: QuestionStatus) => {
    try {
      await questionService.updateStatus(qId, newStatus);
      await loadQuestions();
    } catch (err) {
      console.error('Failed to update status:', err);
    }
  };

  const handleDelete = async (qId: string) => {
    if (confirm('Tem certeza que deseja excluir esta questão?')) {
      try {
        await questionService.deleteQuestion(qId);
        await loadQuestions();
      } catch (err) {
        console.error('Failed to delete question:', err);
      }
    }
  };

  const pendingCount = questions.filter(q => q.status === 'pending_review').length;
  const approvedCount = questions.filter(q => q.status === 'approved').length;

  return (
    <div className="space-y-8 animate-in fade-in duration-300">
      
      {/* Editorial Header */}
      <header className="border-b border-slate-200 pb-6 flex flex-col sm:flex-row sm:items-end justify-between gap-4">
        <div>
          <div className="inline-flex items-center gap-2 px-3 py-1 bg-blue-100 text-blue-700 text-xs font-bold rounded-full tracking-wide font-mono mb-3">
            <HelpCircle className="w-3.5 h-3.5" />
            <span>BANCO UNIVERSAL DE ITENS</span>
          </div>
          <h1 className="font-editorial text-4xl font-extrabold tracking-tight text-slate-900 leading-none">
            Banco Geral de Questões
          </h1>
          <p className="text-sm text-slate-500 mt-2">
            Validação de questões extraídas por IA, edição de casos clínicos, resolução de duplicidades e homologação para alunos.
          </p>
        </div>

        <Button
          id="admin-add-question-btn"
          onClick={handleOpenCreate}
          icon={<Plus className="w-4 h-4" />}
        >
          Nova Questão Manual
        </Button>
      </header>

      {/* Filters & Status Tabs */}
      <div className="bg-white border border-slate-200 rounded-3xl p-6 shadow-sm space-y-5">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <Tabs
            tabs={[
              { id: 'all', label: 'Todas as Questões' },
              { id: 'pending_review', label: 'Aguardando Revisão', count: pendingCount },
              { id: 'approved', label: 'Aprovadas' },
              { id: 'draft', label: 'Rascunhos' },
              { id: 'rejected', label: 'Rejeitadas' },
            ]}
            activeTab={activeStatus}
            onChange={(tab) => setActiveStatus(tab as any)}
          />

          <div className="flex flex-wrap items-center gap-2.5">
            {/* Search */}
            <div className="relative w-full sm:w-64">
              <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={searchQuery}
                onChange={e => setSearchQuery(e.target.value)}
                placeholder="Buscar caso clínico..."
                className="w-full pl-9 pr-3 py-1.5 text-xs rounded-xl border border-slate-200 bg-slate-50 focus:outline-none focus:bg-white focus:border-blue-600 font-sans"
              />
            </div>

            {/* Exam selector */}
            <select
              value={selectedExamFilter}
              onChange={e => setSelectedExamFilter(e.target.value)}
              className="px-3 py-1.5 text-xs font-mono border border-slate-200 rounded-xl bg-slate-50 focus:outline-none"
            >
              <option value="all">TODOS OS EXAMES</option>
              {exams.map(e => (
                <option key={e.id} value={e.id}>{e.name}</option>
              ))}
            </select>

            {/* Specialty selector */}
            <select
              value={selectedSpecialtyFilter}
              onChange={e => setSelectedSpecialtyFilter(e.target.value)}
              className="px-3 py-1.5 text-xs font-mono border border-slate-200 rounded-xl bg-slate-50 focus:outline-none"
            >
              <option value="all">TODAS ESPECIALIDADES</option>
              {specialties.map(s => (
                <option key={s.id} value={s.id}>{s.name}</option>
              ))}
            </select>
          </div>
        </div>

        {/* Questions Table */}
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50/80 border-b border-slate-200 text-slate-400 font-mono font-bold uppercase tracking-wider">
              <tr>
                <th className="px-4 py-3.5">Nº / Exame</th>
                <th className="px-4 py-3.5">Enunciado & Caso Clínico</th>
                <th className="px-4 py-3.5">Especialidade</th>
                <th className="px-4 py-3.5">Gabarito</th>
                <th className="px-4 py-3.5">Status</th>
                <th className="px-4 py-3.5 text-right">Ações</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-slate-700">
              {loading ? (
                <tr>
                  <td colSpan={6} className="px-4 py-8 text-center text-slate-400 font-mono">
                    Carregando questões...
                  </td>
                </tr>
              ) : questions.length === 0 ? (
                <tr>
                  <td colSpan={6} className="px-4 py-8 text-center text-slate-400">
                    Nenhuma questão encontrada com os filtros selecionados.
                  </td>
                </tr>
              ) : (
                questions.map((q) => (
                  <tr key={q.id} className="hover:bg-slate-50/70 transition-colors">
                    <td className="px-4 py-4 whitespace-nowrap">
                      <div className="font-mono font-bold text-blue-600">/q#{q.questionNumber || 1}</div>
                      <div className="text-3xs font-mono text-slate-400">{q.examId} • {q.year}</div>
                      {q.isPossibleDuplicate && (
                        <span className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded bg-amber-100 text-amber-800 text-3xs font-mono font-bold mt-1">
                          <AlertTriangle className="w-3 h-3 text-amber-600" />
                          Duplicata
                        </span>
                      )}
                    </td>
                    <td className="px-4 py-4 max-w-md">
                      <p className="line-clamp-2 leading-relaxed text-slate-800 font-normal">
                        {q.statement}
                      </p>
                      <span className="text-3xs font-mono text-slate-400 mt-1 block">{q.source}</span>
                    </td>
                    <td className="px-4 py-4 whitespace-nowrap">
                      <Badge variant="outline">{q.specialtyName || 'Geral'}</Badge>
                    </td>
                    <td className="px-4 py-4 whitespace-nowrap font-mono font-bold text-blue-700">
                      Letra {q.correctAnswer}
                    </td>
                    <td className="px-4 py-4 whitespace-nowrap">
                      <Badge
                        variant={
                          q.status === 'approved'
                            ? 'success'
                            : q.status === 'pending_review'
                            ? 'warning'
                            : q.status === 'rejected'
                            ? 'danger'
                            : 'default'
                        }
                        dot
                      >
                        {q.status === 'approved'
                          ? 'Aprovada'
                          : q.status === 'pending_review'
                          ? 'Pendente'
                          : q.status === 'rejected'
                          ? 'Rejeitada'
                          : 'Rascunho'}
                      </Badge>
                    </td>
                    <td className="px-4 py-4 text-right whitespace-nowrap">
                      <div className="flex items-center justify-end gap-1.5">
                        {/* Quick Review / Edit */}
                        <button
                          title="Revisar no Editor Oficial"
                          onClick={() => handleOpenReview(q)}
                          className="p-1.5 text-blue-600 hover:bg-blue-50 rounded-lg transition-colors cursor-pointer"
                        >
                          <Eye className="w-4 h-4" />
                        </button>

                        {q.status === 'pending_review' && (
                          <>
                            <button
                              title="Aprovar Questão"
                              onClick={() => handleStatusChange(q.id, 'approved')}
                              className="p-1.5 text-emerald-600 hover:bg-emerald-50 rounded-lg transition-colors cursor-pointer"
                            >
                              <Check className="w-4 h-4" />
                            </button>
                            <button
                              title="Rejeitar Questão"
                              onClick={() => handleStatusChange(q.id, 'rejected')}
                              className="p-1.5 text-rose-600 hover:bg-rose-50 rounded-lg transition-colors cursor-pointer"
                            >
                              <X className="w-4 h-4" />
                            </button>
                          </>
                        )}
                        <button
                          title="Excluir"
                          onClick={() => handleDelete(q.id)}
                          className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors cursor-pointer"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Review Modal */}
      {reviewingQuestion && (
        <QuestionReviewModal
          question={reviewingQuestion}
          isOpen={isReviewModalOpen}
          onClose={() => {
            setIsReviewModalOpen(false);
            setReviewingQuestion(null);
          }}
          onSave={handleSaveModal}
          onApprove={handleApproveModal}
          onReject={handleRejectModal}
        />
      )}

      {/* Modal Add Manual Question */}
      <Modal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        title={editingQuestion ? 'Editar Questão Médica' : 'Cadastrar Questão'}
        description="Preencha o caso clínico, opções de resposta e gabarito comentado."
        maxWidth="2xl"
      >
        <form onSubmit={handleSaveManual} className="space-y-4">
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Exame</label>
              <select
                value={examId}
                onChange={e => setExamId(e.target.value)}
                className="w-full px-2.5 py-1.5 text-xs border border-slate-300 rounded-xl focus:outline-none"
              >
                {exams.map(e => (
                  <option key={e.id} value={e.id}>{e.code}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Especialidade</label>
              <select
                value={specialtyId}
                onChange={e => setSpecialtyId(e.target.value)}
                className="w-full px-2.5 py-1.5 text-xs border border-slate-300 rounded-xl focus:outline-none"
              >
                {specialties.map(s => (
                  <option key={s.id} value={s.id}>{s.name}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Ano da Prova</label>
              <input
                type="number"
                value={year}
                onChange={e => setYear(Number(e.target.value))}
                className="w-full px-2.5 py-1.5 text-xs border border-slate-300 rounded-xl focus:outline-none"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Nº Questão</label>
              <input
                type="number"
                value={questionNumber}
                onChange={e => setQuestionNumber(Number(e.target.value))}
                className="w-full px-2.5 py-1.5 text-xs border border-slate-300 rounded-xl focus:outline-none"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">Enunciado (Caso Clínico)</label>
            <textarea
              rows={4}
              required
              value={statement}
              onChange={e => setStatement(e.target.value)}
              placeholder="Digite o caso clínico, história da doença atual, exame físico e exames complementares..."
              className="w-full px-3 py-2 text-xs border border-slate-300 rounded-xl focus:outline-none leading-relaxed"
            />
          </div>

          {/* Options */}
          <div className="space-y-2">
            <label className="block text-xs font-semibold text-slate-700">Alternativas</label>
            {options.map((opt, idx) => (
              <div key={opt.id} className="flex items-center gap-2">
                <span className="w-6 h-6 rounded-md bg-slate-100 font-bold text-xs flex items-center justify-center text-slate-700 shrink-0 font-mono">
                  {opt.id}
                </span>
                <input
                  type="text"
                  value={opt.text}
                  onChange={(e) => {
                    const next = [...options];
                    next[idx].text = e.target.value;
                    setOptions(next);
                  }}
                  placeholder={`Texto da alternativa ${opt.id}...`}
                  className="flex-1 px-3 py-1.5 text-xs border border-slate-300 rounded-xl focus:outline-none"
                />
              </div>
            ))}
          </div>

          <div className="grid grid-cols-3 gap-3 pt-2">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Gabarito Correto</label>
              <select
                value={correctAnswer}
                onChange={e => setCorrectAnswer(e.target.value)}
                className="w-full px-2.5 py-1.5 text-xs border border-slate-300 rounded-xl focus:outline-none font-bold text-blue-700"
              >
                {options.map(o => (
                  <option key={o.id} value={o.id}>Alternativa {o.id}</option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Dificuldade</label>
              <select
                value={difficulty}
                onChange={e => setDifficulty(e.target.value as any)}
                className="w-full px-2.5 py-1.5 text-xs border border-slate-300 rounded-xl focus:outline-none"
              >
                <option value="easy">Fácil</option>
                <option value="medium">Média</option>
                <option value="hard">Difícil</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Status</label>
              <select
                value={status}
                onChange={e => setStatus(e.target.value as any)}
                className="w-full px-2.5 py-1.5 text-xs border border-slate-300 rounded-xl focus:outline-none font-semibold"
              >
                <option value="approved">Aprovada (Visível)</option>
                <option value="pending_review">Pendente de Revisão</option>
                <option value="draft">Rascunho</option>
                <option value="rejected">Rejeitada</option>
              </select>
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">Comentário e Justificativa Médica</label>
            <textarea
              rows={3}
              value={explanation}
              onChange={e => setExplanation(e.target.value)}
              placeholder="Explicação detalhada de por que a resposta correta é a indicada e justificativa das incorretas..."
              className="w-full px-3 py-2 text-xs border border-slate-300 rounded-xl focus:outline-none leading-relaxed"
            />
          </div>

          <div className="flex justify-end gap-2 pt-4 border-t border-slate-100">
            <Button
              type="button"
              variant="outline"
              size="sm"
              onClick={() => setIsModalOpen(false)}
            >
              Cancelar
            </Button>
            <Button
              type="submit"
              size="sm"
            >
              Salvar Questão
            </Button>
          </div>
        </form>
      </Modal>
    </div>
  );
}
