import React, { useState, useEffect, useCallback } from 'react';
import { 
  ArrowLeft, 
  FileText, 
  CheckCircle2, 
  XCircle, 
  Clock, 
  AlertTriangle, 
  RefreshCw, 
  Sparkles, 
  ShieldCheck, 
  Layers, 
  Filter, 
  Eye, 
  Check, 
  X, 
  ChevronRight,
  Database,
  Search,
  ExternalLink,
  BookOpen
} from 'lucide-react';
import { importService } from '../../services/importService';
import { QuestionImport, Question, QuestionStatus } from '../../types';
import { QuestionReviewModal } from '../../components/admin/QuestionReviewModal';

interface AdminImportDetailProps {
  importId: string;
  onNavigate: (path: string) => void;
}

export const AdminImportDetail: React.FC<AdminImportDetailProps> = ({ importId, onNavigate }) => {
  const [importJob, setImportJob] = useState<QuestionImport | null>(null);
  const [questions, setQuestions] = useState<Question[]>([]);
  const [loading, setLoading] = useState(true);
  const [processing, setProcessing] = useState(false);
  const [filterTab, setFilterTab] = useState<'all' | 'pending_review' | 'approved' | 'rejected' | 'duplicates'>('all');
  const [searchQuery, setSearchQuery] = useState('');
  
  // Selected question for modal review
  const [selectedQuestion, setSelectedQuestion] = useState<Question | null>(null);
  const [isReviewOpen, setIsReviewOpen] = useState(false);

  const loadData = useCallback(async () => {
    try {
      const [jobData, qList] = await Promise.all([
        importService.getImportById(importId),
        importService.getImportQuestions(importId),
      ]);
      setImportJob(jobData);
      setQuestions(qList);
    } catch (e) {
      console.error('Error loading import detail:', e);
    } finally {
      setLoading(false);
    }
  }, [importId]);

  useEffect(() => {
    loadData();
  }, [loadData]);

  // Polling for processing status if job is currently processing
  useEffect(() => {
    if (!importJob || importJob.status !== 'processing') return;

    const interval = setInterval(async () => {
      const updated = await importService.getImportProgress(importId);
      if (updated) {
        setImportJob(updated);
        if (updated.status !== 'processing') {
          // Finished processing, reload questions
          const qList = await importService.getImportQuestions(importId);
          setQuestions(qList);
        }
      }
    }, 2000);

    return () => clearInterval(interval);
  }, [importId, importJob?.status]);

  const handleReprocess = async () => {
    if (!importJob) return;
    setProcessing(true);
    try {
      const updated = await importService.processExamPdf({
        importId: importJob.id,
        examId: importJob.examId,
        year: importJob.year,
        fileName: importJob.fileName,
        forceReprocess: true,
      });
      setImportJob(updated);
      const qList = await importService.getImportQuestions(importId);
      setQuestions(qList);
    } catch (error: any) {
      alert(`Falha ao reprocessar: ${error.message}`);
    } finally {
      setProcessing(false);
    }
  };

  const handleQuickStatus = async (questionId: string, newStatus: QuestionStatus) => {
    try {
      const updated = await importService.reviewQuestion(questionId, { status: newStatus });
      setQuestions(prev => prev.map(q => q.id === questionId ? updated : q));
      // Refresh job stats
      const refreshedJob = await importService.getImportById(importId);
      if (refreshedJob) setImportJob(refreshedJob);
    } catch (e: any) {
      alert(`Erro: ${e.message}`);
    }
  };

  const handleBulkAction = async (action: 'approve_valid' | 'reject_all' | 'approve_all') => {
    const confirmMsg = action === 'approve_valid'
      ? 'Deseja aprovar todas as questões válidas deste lote para que fiquem disponíveis para os alunos?'
      : action === 'reject_all'
      ? 'Deseja rejeitar todas as questões pendentes deste lote?'
      : 'Deseja aprovar todas as questões pendentes deste lote?';

    if (!window.confirm(confirmMsg)) return;

    setLoading(true);
    try {
      const res = await importService.bulkAction(importId, action);
      if (res.importRecord) setImportJob(res.importRecord);
      const qList = await importService.getImportQuestions(importId);
      setQuestions(qList);
    } catch (e: any) {
      alert(`Erro na ação em massa: ${e.message}`);
    } finally {
      setLoading(false);
    }
  };

  const handleSaveModal = async (updatedQ: Question) => {
    const saved = await importService.reviewQuestion(updatedQ.id, updatedQ);
    setQuestions(prev => prev.map(q => q.id === saved.id ? saved : q));
    const refreshedJob = await importService.getImportById(importId);
    if (refreshedJob) setImportJob(refreshedJob);
  };

  const handleApproveModal = async (questionId: string) => {
    await handleQuickStatus(questionId, 'approved');
  };

  const handleRejectModal = async (questionId: string) => {
    await handleQuickStatus(questionId, 'rejected');
  };

  // Filtered list
  const filteredQuestions = questions.filter(q => {
    // Tab filter
    if (filterTab === 'pending_review' && q.status !== 'pending_review') return false;
    if (filterTab === 'approved' && q.status !== 'approved') return false;
    if (filterTab === 'rejected' && q.status !== 'rejected') return false;
    if (filterTab === 'duplicates' && !q.isPossibleDuplicate) return false;

    // Search query
    if (searchQuery.trim()) {
      const query = searchQuery.toLowerCase().trim();
      const matchStmt = q.statement.toLowerCase().includes(query);
      const matchSpec = (q.specialtyName || '').toLowerCase().includes(query);
      const matchNum = String(q.questionNumber || '').includes(query);
      return matchStmt || matchSpec || matchNum;
    }

    return true;
  });

  const pendingCount = questions.filter(q => q.status === 'pending_review').length;
  const approvedCount = questions.filter(q => q.status === 'approved').length;
  const rejectedCount = questions.filter(q => q.status === 'rejected').length;
  const duplicateCount = questions.filter(q => q.isPossibleDuplicate).length;

  if (loading && !importJob) {
    return (
      <div className="py-20 text-center">
        <RefreshCw className="w-8 h-8 text-blue-600 animate-spin mx-auto mb-3" />
        <p className="text-sm font-mono text-slate-500">Carregando lote de importação...</p>
      </div>
    );
  }

  if (!importJob) {
    return (
      <div className="py-16 text-center bg-white rounded-2xl border border-slate-200 p-8">
        <AlertTriangle className="w-10 h-10 text-amber-500 mx-auto mb-3" />
        <h2 className="text-base font-bold text-slate-900 font-sans">Lote de Importação Não Encontrado</h2>
        <p className="text-xs text-slate-500 mt-1 mb-6">O identificador informado não corresponde a nenhum registro.</p>
        <button
          onClick={() => onNavigate('/admin/imports')}
          className="px-4 py-2 bg-blue-600 text-white text-xs font-semibold rounded-xl"
        >
          Voltar para Importações
        </button>
      </div>
    );
  }

  return (
    <div className="space-y-8 animate-in fade-in duration-300">
      
      {/* Top Header & Breadcrumb */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <button
            onClick={() => onNavigate('/admin/imports')}
            className="inline-flex items-center gap-1.5 text-xs font-mono font-semibold text-slate-500 hover:text-blue-600 mb-2 transition-colors"
          >
            <ArrowLeft className="w-3.5 h-3.5" />
            Voltar para Lotes de Importação
          </button>
          <div className="flex items-center gap-3">
            <h1 className="text-2xl font-black tracking-tight text-slate-900 font-sans">
              {importJob.fileName}
            </h1>
            <span className={`px-2.5 py-1 rounded-full text-3xs font-mono font-semibold uppercase tracking-wider ${
              importJob.status === 'completed'
                ? 'bg-emerald-100 text-emerald-800'
                : importJob.status === 'reviewed'
                ? 'bg-blue-100 text-blue-800'
                : importJob.status === 'processing'
                ? 'bg-amber-100 text-amber-800 animate-pulse'
                : importJob.status === 'partially_completed'
                ? 'bg-amber-100 text-amber-900'
                : importJob.status === 'failed'
                ? 'bg-rose-100 text-rose-800'
                : 'bg-slate-100 text-slate-700'
            }`}>
              {importJob.status === 'completed'
                ? 'Extração Concluída'
                : importJob.status === 'reviewed'
                ? '100% Homologado'
                : importJob.status === 'processing'
                ? 'Processando com Gemini...'
                : importJob.status === 'partially_completed'
                ? 'Extração com Alertas'
                : importJob.status === 'failed'
                ? 'Falha na Extração'
                : 'Arquivo Carregado'}
            </span>
          </div>
          <p className="text-xs text-slate-500 font-mono mt-1 flex items-center gap-2">
            <span>Bucket Privado: <code className="bg-slate-100 px-1.5 py-0.5 rounded text-slate-700">{importJob.storagePath}</code></span>
            <span>•</span>
            <span>Exame: <strong className="text-slate-800 uppercase">{importJob.examId}</strong></span>
            <span>•</span>
            <span>Ano: <strong>{importJob.year || '—'}</strong></span>
          </p>
        </div>

        {/* Reprocess & Actions */}
        <div className="flex items-center gap-2 shrink-0">
          <button
            onClick={handleReprocess}
            disabled={processing || importJob.status === 'processing'}
            className="px-3.5 py-2 rounded-xl text-xs font-semibold bg-white border border-slate-300 text-slate-700 hover:bg-slate-50 transition shadow-sm flex items-center gap-1.5 disabled:opacity-50"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${processing || importJob.status === 'processing' ? 'animate-spin text-blue-600' : ''}`} />
            Reprocessar com Gemini AI
          </button>

          {pendingCount > 0 && (
            <button
              onClick={() => handleBulkAction('approve_valid')}
              className="px-4 py-2 rounded-xl text-xs font-bold bg-blue-600 text-white hover:bg-blue-700 transition shadow-sm flex items-center gap-1.5"
            >
              <CheckCircle2 className="w-3.5 h-3.5" />
              Aprovar Válidas ({pendingCount})
            </button>
          )}
        </div>
      </div>

      {/* Real-time Pipeline Progress Card */}
      {importJob.status === 'processing' && (
        <div className="p-5 rounded-2xl bg-amber-500/10 border border-amber-500/30 space-y-3 animate-in fade-in">
          <div className="flex items-center justify-between text-xs font-mono">
            <span className="font-bold text-amber-900 flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-amber-600 animate-spin" />
              {importJob.stage || 'Pipeline Gemini em Execução...'}
            </span>
            <span className="font-bold text-amber-900">{importJob.progressPercent || 20}%</span>
          </div>
          <div className="w-full h-2 rounded-full bg-amber-200 overflow-hidden">
            <div
              className="h-full bg-amber-500 rounded-full transition-all duration-500"
              style={{ width: `${importJob.progressPercent || 20}%` }}
            />
          </div>
          <p className="text-xs text-amber-800 font-sans">
            {importJob.stageDescription || 'Extraindo casos clínicos, alternativas e gabarito oficial com preservação estrita.'}
          </p>
        </div>
      )}

      {/* Metrics Summary Grid */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
        <div className="p-4 rounded-xl bg-white border border-slate-200">
          <span className="text-3xs font-mono uppercase tracking-wider text-slate-500">Total Extraído</span>
          <div className="text-2xl font-black text-slate-900 font-sans mt-1">
            {questions.length || importJob.totalQuestions || 0}
          </div>
          <span className="text-3xs text-slate-400 font-mono">Caderno PDF</span>
        </div>

        <div className="p-4 rounded-xl bg-white border border-amber-200 bg-amber-50/30">
          <span className="text-3xs font-mono uppercase tracking-wider text-amber-800">Aguardando Revisão</span>
          <div className="text-2xl font-black text-amber-700 font-sans mt-1">
            {pendingCount}
          </div>
          <span className="text-3xs text-amber-600 font-mono">Iniciais (Padrão Seguro)</span>
        </div>

        <div className="p-4 rounded-xl bg-white border border-emerald-200 bg-emerald-50/30">
          <span className="text-3xs font-mono uppercase tracking-wider text-emerald-800">Aprovadas</span>
          <div className="text-2xl font-black text-emerald-700 font-sans mt-1">
            {approvedCount}
          </div>
          <span className="text-3xs text-emerald-600 font-mono">Visíveis para Alunos</span>
        </div>

        <div className="p-4 rounded-xl bg-white border border-rose-200 bg-rose-50/30">
          <span className="text-3xs font-mono uppercase tracking-wider text-rose-800">Rejeitadas</span>
          <div className="text-2xl font-black text-rose-700 font-sans mt-1">
            {rejectedCount}
          </div>
          <span className="text-3xs text-rose-600 font-mono">Descartadas</span>
        </div>

        <div className="p-4 rounded-xl bg-white border border-amber-200">
          <span className="text-3xs font-mono uppercase tracking-wider text-slate-500">Possíveis Duplicatas</span>
          <div className="text-2xl font-black text-amber-600 font-sans mt-1">
            {duplicateCount}
          </div>
          <span className="text-3xs text-amber-600 font-mono">Alertas Ativos</span>
        </div>

        <div className="p-4 rounded-xl bg-white border border-slate-200">
          <span className="text-3xs font-mono uppercase tracking-wider text-slate-500">Inconsistências</span>
          <div className="text-2xl font-black text-slate-700 font-sans mt-1">
            {importJob.errors?.length || 0}
          </div>
          <span className="text-3xs text-slate-400 font-mono">Notas de Validação</span>
        </div>
      </div>

      {/* Filter Tabs & Search Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-200 pb-4">
        
        {/* Navigation Filter Tabs */}
        <div className="flex items-center gap-1 overflow-x-auto pb-1 sm:pb-0 scrollbar-none">
          <button
            onClick={() => setFilterTab('all')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition ${
              filterTab === 'all'
                ? 'bg-slate-900 text-white'
                : 'text-slate-600 hover:bg-slate-200/60'
            }`}
          >
            Todas ({questions.length})
          </button>
          
          <button
            onClick={() => setFilterTab('pending_review')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition ${
              filterTab === 'pending_review'
                ? 'bg-amber-600 text-white'
                : 'text-slate-600 hover:bg-slate-200/60'
            }`}
          >
            Aguardando Revisão ({pendingCount})
          </button>

          <button
            onClick={() => setFilterTab('approved')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition ${
              filterTab === 'approved'
                ? 'bg-emerald-600 text-white'
                : 'text-slate-600 hover:bg-slate-200/60'
            }`}
          >
            Aprovadas ({approvedCount})
          </button>

          <button
            onClick={() => setFilterTab('rejected')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition ${
              filterTab === 'rejected'
                ? 'bg-rose-600 text-white'
                : 'text-slate-600 hover:bg-slate-200/60'
            }`}
          >
            Rejeitadas ({rejectedCount})
          </button>

          {duplicateCount > 0 && (
            <button
              onClick={() => setFilterTab('duplicates')}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition flex items-center gap-1 ${
                filterTab === 'duplicates'
                  ? 'bg-amber-500 text-white'
                  : 'text-amber-700 bg-amber-100/60 hover:bg-amber-100'
              }`}
            >
              <AlertTriangle className="w-3 h-3" />
              Duplicatas ({duplicateCount})
            </button>
          )}
        </div>

        {/* Search Input */}
        <div className="relative w-full sm:w-72">
          <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
            placeholder="Buscar por caso clínico ou nº..."
            className="w-full pl-9 pr-3 py-1.5 text-xs rounded-xl border border-slate-300 bg-white focus:outline-none focus:border-blue-600 focus:ring-1 focus:ring-blue-600"
          />
        </div>

      </div>

      {/* Questions List */}
      <div className="space-y-3">
        {filteredQuestions.length === 0 ? (
          <div className="py-12 text-center bg-white rounded-2xl border border-slate-200 p-6">
            <BookOpen className="w-8 h-8 text-slate-300 mx-auto mb-2" />
            <p className="text-xs font-mono text-slate-500">Nenhuma questão encontrada para este filtro.</p>
          </div>
        ) : (
          filteredQuestions.map((q) => {
            const isApproved = q.status === 'approved';
            const isRejected = q.status === 'rejected';
            const isPending = q.status === 'pending_review';

            return (
              <div
                key={q.id}
                className={`p-5 rounded-2xl border bg-white transition-all shadow-sm hover:border-slate-300 space-y-3.5 ${
                  q.isPossibleDuplicate ? 'border-amber-300 bg-amber-50/20' : 'border-slate-200'
                }`}
              >
                {/* Card Top Row */}
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                  <div className="flex items-center gap-2.5 flex-wrap">
                    <span className="w-7 h-7 rounded-lg bg-blue-50 text-blue-700 font-mono font-bold text-xs flex items-center justify-center border border-blue-200">
                      #{q.questionNumber || '—'}
                    </span>

                    <span className="px-2.5 py-0.5 rounded-full text-3xs font-mono font-semibold bg-slate-100 text-slate-700">
                      {q.specialtyName || 'Clínica Médica'}
                    </span>

                    {q.sourcePage && (
                      <span className="px-2 py-0.5 rounded-md text-3xs font-mono text-slate-500 bg-slate-50 border border-slate-200">
                        Pág. {q.sourcePage}
                      </span>
                    )}

                    {q.isPossibleDuplicate && (
                      <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-3xs font-mono font-bold bg-amber-100 text-amber-800 border border-amber-300">
                        <AlertTriangle className="w-3 h-3 text-amber-600" />
                        Possível Duplicata
                      </span>
                    )}

                    {q.validationErrors && q.validationErrors.length > 0 && (
                      <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-3xs font-mono font-bold bg-rose-100 text-rose-800 border border-rose-300">
                        Inconsistência ({q.validationErrors.length})
                      </span>
                    )}
                  </div>

                  {/* Status Indicator & Fast Actions */}
                  <div className="flex items-center gap-2 self-end sm:self-auto">
                    <span className={`px-2.5 py-1 rounded-full text-3xs font-mono font-bold uppercase tracking-wider ${
                      isApproved
                        ? 'bg-emerald-100 text-emerald-800'
                        : isRejected
                        ? 'bg-rose-100 text-rose-800'
                        : 'bg-amber-100 text-amber-800'
                    }`}>
                      {isApproved ? 'Aprovada' : isRejected ? 'Rejeitada' : 'Aguardando Revisão'}
                    </span>

                    {/* Quick Approve Button */}
                    {!isApproved && (
                      <button
                        onClick={() => handleQuickStatus(q.id, 'approved')}
                        className="p-1.5 rounded-lg bg-emerald-50 text-emerald-700 border border-emerald-200 hover:bg-emerald-100 transition-colors"
                        title="Aprovar questão imediatamente"
                      >
                        <Check className="w-4 h-4" />
                      </button>
                    )}

                    {/* Quick Reject Button */}
                    {!isRejected && (
                      <button
                        onClick={() => handleQuickStatus(q.id, 'rejected')}
                        className="p-1.5 rounded-lg bg-rose-50 text-rose-700 border border-rose-200 hover:bg-rose-100 transition-colors"
                        title="Rejeitar questão"
                      >
                        <X className="w-4 h-4" />
                      </button>
                    )}

                    {/* Detailed Review Button */}
                    <button
                      onClick={() => {
                        setSelectedQuestion(q);
                        setIsReviewOpen(true);
                      }}
                      className="px-3 py-1 rounded-lg bg-slate-900 text-white text-xs font-semibold hover:bg-blue-600 transition-colors flex items-center gap-1.5 shadow-sm"
                    >
                      <Eye className="w-3.5 h-3.5" />
                      Revisar & Editar
                    </button>
                  </div>
                </div>

                {/* Duplicate Reason Warning banner if flagged */}
                {q.isPossibleDuplicate && q.duplicateReason && (
                  <div className="p-2.5 rounded-lg bg-amber-50/80 border border-amber-200 text-xs text-amber-800 font-sans flex items-center gap-2">
                    <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0" />
                    <span>{q.duplicateReason}</span>
                  </div>
                )}

                {/* Clinical Statement Stem Preview */}
                <p className="text-xs sm:text-sm text-slate-800 font-sans leading-relaxed line-clamp-3">
                  {q.statement}
                </p>

                {/* Alternatives List Summary */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-1">
                  {q.options?.map(opt => {
                    const isOptionCorrect = q.correctAnswer === opt.id;
                    return (
                      <div
                        key={opt.id}
                        className={`px-3 py-1.5 rounded-lg text-xs border flex items-start gap-2 ${
                          isOptionCorrect
                            ? 'bg-emerald-50 border-emerald-300 text-emerald-900 font-medium'
                            : 'bg-slate-50/80 border-slate-200 text-slate-700'
                        }`}
                      >
                        <span className={`w-5 h-5 rounded font-mono font-bold text-3xs flex items-center justify-center shrink-0 ${
                          isOptionCorrect ? 'bg-emerald-600 text-white' : 'bg-slate-200 text-slate-700'
                        }`}>
                          {opt.id}
                        </span>
                        <span className="truncate flex-1">{opt.text}</span>
                        {isOptionCorrect && (
                          <span className="text-3xs font-mono font-bold text-emerald-700 uppercase shrink-0">
                            Gabarito
                          </span>
                        )}
                      </div>
                    );
                  })}
                </div>

              </div>
            );
          })
        )}
      </div>

      {/* Question Review Modal */}
      {selectedQuestion && (
        <QuestionReviewModal
          question={selectedQuestion}
          isOpen={isReviewOpen}
          onClose={() => {
            setIsReviewOpen(false);
            setSelectedQuestion(null);
          }}
          onSave={handleSaveModal}
          onApprove={handleApproveModal}
          onReject={handleRejectModal}
        />
      )}

    </div>
  );
};
