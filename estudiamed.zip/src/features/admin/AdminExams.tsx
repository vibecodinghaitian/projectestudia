import React, { useState, useEffect } from 'react';
import { useExam } from '../../context/ExamContext';
import { Badge } from '../../components/common/Badge';
import { Button } from '../../components/common/Button';
import { Modal } from '../../components/common/Modal';
import { EXAM_FLAGS } from '../../lib/utils';
import { 
  Plus, 
  Edit, 
  Check, 
  Globe 
} from 'lucide-react';
import { examService } from '../../services/examService';
import { Exam } from '../../types';

export function AdminExams() {
  const { exams, refreshExams } = useExam();
  const [isCreateOpen, setIsCreateOpen] = useState(false);
  const [editingExam, setEditingExam] = useState<Exam | null>(null);

  // Form states
  const [name, setName] = useState('');
  const [code, setCode] = useState('');
  const [country, setCountry] = useState('');
  const [countryCode, setCountryCode] = useState('BR');
  const [description, setDescription] = useState('');
  const [active, setActive] = useState(true);
  const [yearsInput, setYearsInput] = useState('2024, 2023, 2022');
  const [saving, setSaving] = useState(false);

  const resetForm = () => {
    setName('');
    setCode('');
    setCountry('');
    setCountryCode('BR');
    setDescription('');
    setActive(true);
    setYearsInput('2024, 2023, 2022');
    setEditingExam(null);
  };

  const handleOpenCreate = () => {
    resetForm();
    setIsCreateOpen(true);
  };

  const handleOpenEdit = (exam: Exam) => {
    setEditingExam(exam);
    setName(exam.name);
    setCode(exam.code);
    setCountry(exam.country);
    setCountryCode(exam.countryCode || 'BR');
    setDescription(exam.description);
    setActive(exam.active);
    setYearsInput(exam.availableYears?.join(', ') || '2024');
    setIsCreateOpen(true);
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name || !code) return;
    setSaving(true);
    try {
      const parsedYears = yearsInput
        .split(',')
        .map(y => parseInt(y.trim()))
        .filter(n => !isNaN(n));

      if (editingExam) {
        await examService.updateExam(editingExam.id, {
          name,
          code,
          country,
          countryCode,
          description,
          active,
          availableYears: parsedYears,
        });
      } else {
        await examService.createExam({
          name,
          code,
          country,
          countryCode,
          description,
          active,
          availableYears: parsedYears,
          specialties: ['clinica-medica', 'cirurgia-geral', 'pediatria', 'ginecologia-obstetricia', 'medicina-preventiva'],
        });
      }
      await refreshExams();
      setIsCreateOpen(false);
      resetForm();
    } catch (err) {
      console.error('Failed to save exam:', err);
    } finally {
      setSaving(false);
    }
  };

  const handleToggleActive = async (exam: Exam) => {
    try {
      await examService.updateExam(exam.id, { active: !exam.active });
      await refreshExams();
    } catch (err) {
      console.error('Error toggling exam active status:', err);
    }
  };

  return (
    <div className="space-y-8">
      {/* Editorial Header */}
      <header className="border-b border-slate-200 pb-6 flex flex-col sm:flex-row sm:items-end justify-between gap-4">
        <div>
          <div className="inline-flex items-center gap-2 px-3 py-1 bg-blue-100 text-blue-700 text-xs font-bold rounded-full tracking-wide font-mono mb-3">
            <Globe className="w-3.5 h-3.5" />
            <span>ARQUITETURA MULTI-BANCA</span>
          </div>
          <h1 className="font-editorial text-4xl font-extrabold tracking-tight text-slate-900 leading-none">
            Gerenciamento de Exames Médicos
          </h1>
          <p className="text-sm text-slate-500 mt-2">
            Configure o REVALIDA Brasil ou cadastre novas bancas internacionais (MIR, ENARM, USMLE, PLAB) dinamicamente.
          </p>
        </div>

        <Button
          id="admin-add-exam-btn"
          onClick={handleOpenCreate}
          icon={<Plus className="w-4 h-4" />}
        >
          Adicionar Novo Exame
        </Button>
      </header>

      {/* Table of Exams */}
      <div className="bg-white border border-slate-200 rounded-3xl overflow-hidden shadow-sm">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50/80 border-b border-slate-200 text-slate-400 font-mono font-bold uppercase tracking-wider">
              <tr>
                <th className="px-6 py-4">Exame & País</th>
                <th className="px-6 py-4">Código</th>
                <th className="px-6 py-4">Edições Anuais</th>
                <th className="px-6 py-4">Status Alunos</th>
                <th className="px-6 py-4 text-right">Ações</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-slate-700">
              {exams.map((exam) => (
                <tr key={exam.id} className="hover:bg-slate-50/70 transition-colors">
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-3">
                      <span className="text-2xl">{EXAM_FLAGS[exam.countryCode] || '🩺'}</span>
                      <div>
                        <p className="font-bold text-slate-900">{exam.name}</p>
                        <p className="text-3xs font-mono text-slate-400 mt-0.5">{exam.country}</p>
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <Badge variant="outline">{exam.code}</Badge>
                  </td>
                  <td className="px-6 py-4 font-mono font-bold text-slate-600">
                    {exam.availableYears?.join(', ') || 'N/A'}
                  </td>
                  <td className="px-6 py-4">
                    <button
                      onClick={() => handleToggleActive(exam)}
                      className="cursor-pointer flex items-center gap-1.5"
                    >
                      {exam.active ? (
                        <Badge variant="success" dot>
                          Ativo
                        </Badge>
                      ) : (
                        <Badge variant="default">Inativo</Badge>
                      )}
                    </button>
                  </td>
                  <td className="px-6 py-4 text-right">
                    <div className="flex items-center justify-end gap-2">
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => handleOpenEdit(exam)}
                        icon={<Edit className="w-3.5 h-3.5" />}
                      >
                        Editar
                      </Button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Modal */}
      <Modal
        isOpen={isCreateOpen}
        onClose={() => setIsCreateOpen(false)}
        title={editingExam ? 'Editar Exame Médico' : 'Cadastrar Novo Exame Médico'}
        description="Configure as propriedades da banca examinadora e disponibilidade de anos."
      >
        <form onSubmit={handleSave} className="space-y-4">
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">Nome do Exame</label>
            <input
              type="text"
              required
              value={name}
              onChange={e => setName(e.target.value)}
              placeholder="Ex: MIR Espanha (Médico Interno Residente)"
              className="w-full px-3 py-2 text-xs border border-slate-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:outline-none"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Sigla / Código</label>
              <input
                type="text"
                required
                value={code}
                onChange={e => setCode(e.target.value)}
                placeholder="Ex: MIR"
                className="w-full px-3 py-2 text-xs border border-slate-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:outline-none"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">País</label>
              <input
                type="text"
                required
                value={country}
                onChange={e => setCountry(e.target.value)}
                placeholder="Ex: Espanha"
                className="w-full px-3 py-2 text-xs border border-slate-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:outline-none"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Código Bandeira (ISO)</label>
              <select
                value={countryCode}
                onChange={e => setCountryCode(e.target.value)}
                className="w-full px-3 py-2 text-xs border border-slate-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:outline-none"
              >
                <option value="BR">Brasil (🇧🇷 BR)</option>
                <option value="ES">Espanha (🇪🇸 ES)</option>
                <option value="MX">México (🇲🇽 MX)</option>
                <option value="US">Estados Unidos (🇺🇸 US)</option>
                <option value="GB">Reino Unido (🇬🇧 GB)</option>
              </select>
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Anos Disponíveis (separados por vírgula)</label>
              <input
                type="text"
                value={yearsInput}
                onChange={e => setYearsInput(e.target.value)}
                placeholder="2024, 2023, 2022"
                className="w-full px-3 py-2 text-xs border border-slate-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:outline-none"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">Descrição</label>
            <textarea
              rows={3}
              value={description}
              onChange={e => setDescription(e.target.value)}
              placeholder="Descreva as características, banca examinadora e estrutura do exame..."
              className="w-full px-3 py-2 text-xs border border-slate-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:outline-none"
            />
          </div>

          <div className="flex items-center gap-2 pt-2">
            <input
              type="checkbox"
              id="exam-active-checkbox"
              checked={active}
              onChange={e => setActive(e.target.checked)}
              className="rounded text-blue-600 focus:ring-blue-500 h-4 w-4"
            />
            <label htmlFor="exam-active-checkbox" className="text-xs font-semibold text-slate-700 cursor-pointer">
              Ativo para acesso dos estudantes no catálogo
            </label>
          </div>

          <div className="flex justify-end gap-2 pt-4 border-t border-slate-100">
            <Button
              type="button"
              variant="outline"
              size="sm"
              onClick={() => setIsCreateOpen(false)}
            >
              Cancelar
            </Button>
            <Button
              type="submit"
              size="sm"
              loading={saving}
            >
              {editingExam ? 'Salvar Alterações' : 'Criar Exame'}
            </Button>
          </div>
        </form>
      </Modal>
    </div>
  );
}
