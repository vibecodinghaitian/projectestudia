import React, { useState, useEffect } from 'react';
import { PromoCode, PlanId } from '../../types';
import { subscriptionService } from '../../services/subscriptionService';
import { 
  Tag, 
  Plus, 
  Trash2, 
  Power, 
  Check, 
  X, 
  AlertCircle, 
  ArrowLeft,
  Calendar,
  Layers,
  Sparkles
} from 'lucide-react';

interface AdminPromosProps {
  onNavigate: (path: string) => void;
}

export function AdminPromos({ onNavigate }: AdminPromosProps) {
  const [promos, setPromos] = useState<PromoCode[]>([]);
  const [loading, setLoading] = useState(true);
  const [creating, setCreating] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);

  // New promo form state
  const [code, setCode] = useState('');
  const [discountType, setDiscountType] = useState<'percent' | 'fixed' | 'free_first_month'>('free_first_month');
  const [discountValue, setDiscountValue] = useState<number>(100);
  const [planId, setPlanId] = useState<string>('all');
  const [maxRedemptions, setMaxRedemptions] = useState<string>('');
  const [expiresAt, setExpiresAt] = useState<string>('');

  const loadPromos = async () => {
    setLoading(true);
    try {
      const data = await subscriptionService.getAdminPromoCodes();
      setPromos(data);
    } catch (err: any) {
      setError('Falha ao carregar cupons promocionais.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadPromos();
  }, []);

  const handleCreatePromo = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!code.trim()) {
      setError('Código do cupom é obrigatório.');
      return;
    }

    setError(null);
    setSuccess(null);

    try {
      await subscriptionService.createAdminPromoCode({
        code: code.trim().toUpperCase(),
        discount_type: discountType,
        discount_value: Number(discountValue),
        applicable_plan: planId === 'all' ? undefined : (planId as PlanId),
        max_redemptions: maxRedemptions ? parseInt(maxRedemptions, 10) : undefined,
        expires_at: expiresAt || undefined,
        active: true,
      });

      setSuccess(`Cupom ${code.toUpperCase()} criado com sucesso!`);
      setCode('');
      setMaxRedemptions('');
      setExpiresAt('');
      setCreating(false);
      loadPromos();
    } catch (err: any) {
      setError(err.message || 'Erro ao criar cupom.');
    }
  };

  const handleToggle = async (id: string) => {
    try {
      await subscriptionService.toggleAdminPromoCode(id);
      loadPromos();
    } catch (err: any) {
      setError('Erro ao alternar status do cupom.');
    }
  };

  const handleDelete = async (id: string) => {
    if (!confirm('Deseja realmente excluir este cupom promocional?')) return;
    try {
      await subscriptionService.deleteAdminPromoCode(id);
      loadPromos();
    } catch (err: any) {
      setError('Erro ao deletar cupom.');
    }
  };

  return (
    <div className="space-y-6">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <button
            onClick={() => onNavigate('/admin')}
            className="text-xs font-mono text-slate-500 hover:text-slate-900 flex items-center gap-1 mb-2"
          >
            <ArrowLeft className="w-3.5 h-3.5" />
            <span>Voltar ao Painel Admin</span>
          </button>
          <h1 className="font-editorial text-2xl sm:text-3xl font-extrabold text-slate-900">
            Gerenciador de Cupons & Promoções
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 font-mono mt-1">
            Validação de descontos no servidor (Stripe + Estudiamed)
          </p>
        </div>

        <button
          onClick={() => setCreating(!creating)}
          className="px-4 py-2.5 rounded-xl text-xs font-bold text-white bg-blue-600 hover:bg-blue-700 transition-colors flex items-center gap-1.5 shadow-xs shrink-0 cursor-pointer"
        >
          {creating ? <X className="w-4 h-4" /> : <Plus className="w-4 h-4" />}
          <span>{creating ? 'Cancelar' : 'Criar Novo Cupom'}</span>
        </button>
      </div>

      {error && (
        <div className="p-4 rounded-2xl bg-rose-50 border border-rose-200 text-xs font-mono text-rose-800 flex items-center gap-2">
          <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
          <span>{error}</span>
        </div>
      )}

      {success && (
        <div className="p-4 rounded-2xl bg-emerald-50 border border-emerald-200 text-xs font-mono text-emerald-800 flex items-center gap-2">
          <Check className="w-4 h-4 text-emerald-600 shrink-0" />
          <span>{success}</span>
        </div>
      )}

      {/* Create Promo Drawer */}
      {creating && (
        <form onSubmit={handleCreatePromo} className="bg-white border border-slate-200 rounded-3xl p-6 shadow-sm space-y-4 animate-in fade-in duration-200">
          <h2 className="font-editorial text-lg font-bold text-slate-900">
            Novo Cupom de Desconto
          </h2>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            <div>
              <label className="block text-xs font-mono font-bold text-slate-700 mb-1">
                CÓDIGO DO CUPOM *
              </label>
              <input
                type="text"
                required
                value={code}
                onChange={e => setCode(e.target.value.toUpperCase())}
                placeholder="EX: REVALIDA2026"
                className="w-full px-3.5 py-2 text-xs uppercase font-mono font-bold border border-slate-300 rounded-xl focus:border-blue-600 focus:outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-mono font-bold text-slate-700 mb-1">
                TIPO DE DESCONTO
              </label>
              <select
                value={discountType}
                onChange={e => setDiscountType(e.target.value as any)}
                className="w-full px-3.5 py-2 text-xs border border-slate-300 rounded-xl focus:border-blue-600 focus:outline-none font-sans"
              >
                <option value="free_first_month">100% OFF no Primeiro Mês (Grátis)</option>
                <option value="percent">Porcentagem (%)</option>
                <option value="fixed">Valor Fixo ($)</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-mono font-bold text-slate-700 mb-1">
                VALOR DO DESCONTO
              </label>
              <input
                type="number"
                value={discountValue}
                onChange={e => setDiscountValue(Number(e.target.value))}
                min={0}
                max={100}
                className="w-full px-3.5 py-2 text-xs border border-slate-300 rounded-xl focus:border-blue-600 focus:outline-none font-mono"
              />
            </div>

            <div>
              <label className="block text-xs font-mono font-bold text-slate-700 mb-1">
                PLANO APLICÁVEL
              </label>
              <select
                value={planId}
                onChange={e => setPlanId(e.target.value)}
                className="w-full px-3.5 py-2 text-xs border border-slate-300 rounded-xl focus:border-blue-600 focus:outline-none font-sans"
              >
                <option value="all">Todos os Planos (Starter, Pro, Premium)</option>
                <option value="starter">Apenas Starter ($1.99)</option>
                <option value="pro">Apenas Pro ($2.99)</option>
                <option value="premium">Apenas Premium ($3.99)</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-mono font-bold text-slate-700 mb-1">
                LIMITE DE USOS (OPCIONAL)
              </label>
              <input
                type="number"
                value={maxRedemptions}
                onChange={e => setMaxRedemptions(e.target.value)}
                placeholder="Ex: 500 (Vazio = Ilimitado)"
                className="w-full px-3.5 py-2 text-xs border border-slate-300 rounded-xl focus:border-blue-600 focus:outline-none font-mono"
              />
            </div>

            <div>
              <label className="block text-xs font-mono font-bold text-slate-700 mb-1">
                DATA DE EXPIRAÇÃO
              </label>
              <input
                type="date"
                value={expiresAt}
                onChange={e => setExpiresAt(e.target.value)}
                className="w-full px-3.5 py-2 text-xs border border-slate-300 rounded-xl focus:border-blue-600 focus:outline-none font-sans"
              />
            </div>
          </div>

          <div className="flex justify-end pt-2">
            <button
              type="submit"
              className="px-6 py-2.5 text-xs font-bold text-white bg-blue-600 hover:bg-blue-700 rounded-xl transition-colors shadow-xs cursor-pointer"
            >
              Salvar e Ativar Cupom
            </button>
          </div>
        </form>
      )}

      {/* Promos Table */}
      <div className="bg-white border border-slate-200 rounded-3xl overflow-hidden shadow-xs">
        <div className="px-6 py-4 border-b border-slate-100 bg-slate-50 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Tag className="w-4 h-4 text-blue-600" />
            <span className="font-editorial text-base font-bold text-slate-900">
              Cupons Cadastrados ({promos.length})
            </span>
          </div>
        </div>

        {loading ? (
          <div className="p-12 text-center text-xs font-mono text-slate-400">
            Carregando cupons...
          </div>
        ) : promos.length === 0 ? (
          <div className="p-12 text-center text-xs font-mono text-slate-400">
            Nenhum cupom cadastrado.
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs font-mono">
              <thead className="bg-slate-50 text-slate-500 border-b border-slate-100 uppercase text-3xs">
                <tr>
                  <th className="px-6 py-3 font-bold">Código</th>
                  <th className="px-6 py-3 font-bold">Tipo & Desconto</th>
                  <th className="px-6 py-3 font-bold">Plano</th>
                  <th className="px-6 py-3 font-bold">Resgates</th>
                  <th className="px-6 py-3 font-bold">Expiração</th>
                  <th className="px-6 py-3 font-bold">Status</th>
                  <th className="px-6 py-3 font-bold text-right">Ações</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-slate-700">
                {promos.map((p) => (
                  <tr key={p.id} className="hover:bg-slate-50/60 transition-colors">
                    <td className="px-6 py-3.5 font-bold text-slate-900 flex items-center gap-2">
                      <span className="px-2 py-0.5 rounded-md bg-blue-50 text-blue-700 border border-blue-100">
                        {p.code}
                      </span>
                    </td>
                    <td className="px-6 py-3.5">
                      {p.discount_type === 'free_first_month'
                        ? '1º Mês Grátis (100% OFF)'
                        : p.discount_type === 'percent'
                        ? `${p.discount_value}% OFF`
                        : `$${p.discount_value} OFF`}
                    </td>
                    <td className="px-6 py-3.5">
                      <span className="capitalize">{p.applicable_plan || 'Todos'}</span>
                    </td>
                    <td className="px-6 py-3.5">
                      <strong>{p.current_redemptions}</strong>
                      {p.max_redemptions ? ` / ${p.max_redemptions}` : ' (Ilimitado)'}
                    </td>
                    <td className="px-6 py-3.5 text-slate-500">
                      {p.expires_at ? new Date(p.expires_at).toLocaleDateString() : 'Sem expiração'}
                    </td>
                    <td className="px-6 py-3.5">
                      <span
                        className={`px-2 py-0.5 rounded-full text-3xs font-bold uppercase ${
                          p.active
                            ? 'bg-emerald-100 text-emerald-800'
                            : 'bg-slate-200 text-slate-600'
                        }`}
                      >
                        {p.active ? 'Ativo' : 'Inativo'}
                      </span>
                    </td>
                    <td className="px-6 py-3.5 text-right space-x-2">
                      <button
                        onClick={() => handleToggle(p.id)}
                        className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition-colors cursor-pointer"
                        title={p.active ? 'Desativar' : 'Ativar'}
                      >
                        <Power className="w-3.5 h-3.5" />
                      </button>
                      <button
                        onClick={() => handleDelete(p.id)}
                        className="p-1.5 rounded-lg text-rose-400 hover:text-rose-700 hover:bg-rose-50 transition-colors cursor-pointer"
                        title="Excluir cupom"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}
