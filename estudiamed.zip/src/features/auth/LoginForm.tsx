import React from 'react';
import { StudyModeScene } from './components/StudyModeScene';

interface LoginFormProps {
  onNavigate: (path: string) => void;
}

export function LoginForm({ onNavigate }: LoginFormProps) {
  return <StudyModeScene onNavigate={onNavigate} />;
}
