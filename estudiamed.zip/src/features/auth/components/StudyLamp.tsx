import React from 'react';
import { motion } from 'motion/react';
import { PullCord } from './PullCord';

interface StudyLampProps {
  isOn: boolean;
  onToggle: () => void;
  isReducedMotion?: boolean;
}

export function StudyLamp({ isOn, onToggle, isReducedMotion = false }: StudyLampProps) {
  return (
    <div className="relative flex flex-col items-center select-none pointer-events-auto">
      {/* Lamp Head & Arm Structure */}
      <div className="relative flex flex-col items-center">
        {/* Upper Arm & Mounting Joint */}
        <div className="w-16 h-3 bg-gradient-to-r from-amber-700 via-amber-500 to-amber-800 rounded-t-sm shadow-md" />
        
        {/* Lamp Shade (Architectural Medical Study Lamp) */}
        <div className="relative w-48 sm:w-56 h-20 sm:h-24">
          {/* Outer Shade Shell */}
          <div
            className={`w-full h-full rounded-t-[70px] rounded-b-xl border-t-2 border-x-2 transition-all duration-700 ${
              isOn
                ? 'bg-gradient-to-b from-slate-900 via-slate-800 to-slate-900 border-amber-500/60 shadow-[0_-2px_15px_rgba(245,158,11,0.2)]'
                : 'bg-gradient-to-b from-slate-950 via-slate-900 to-slate-950 border-slate-700/40 shadow-inner'
            }`}
          >
            {/* Brushed Brass Decorative Finial */}
            <div className="absolute -top-3 left-1/2 -translate-x-1/2 w-6 h-3 rounded-t-full bg-gradient-to-r from-amber-600 via-amber-400 to-amber-700 border-t border-amber-300/40" />

            {/* Specular Highlight along shade rim */}
            <div className="absolute inset-x-4 top-2 h-[1px] bg-white/10 rounded-full" />

            {/* Interior Reflector & Glow Cavity */}
            <div className="absolute inset-x-2 bottom-0 h-10 overflow-hidden flex items-center justify-center">
              {/* Warm interior reflector glow */}
              <div
                className={`w-full h-full rounded-b-lg transition-all duration-700 ${
                  isOn
                    ? 'bg-gradient-to-t from-amber-200/90 via-amber-400/50 to-transparent opacity-100 shadow-[inset_0_0_25px_rgba(251,191,36,0.9)]'
                    : 'bg-slate-950/80 opacity-40'
                }`}
              />

              {/* Incandescent / Warm LED Bulb */}
              <div
                className={`absolute bottom-1 w-10 h-10 rounded-full transition-all duration-500 ${
                  isOn
                    ? 'bg-gradient-to-b from-white via-amber-200 to-amber-400 shadow-[0_0_35px_12px_rgba(251,191,36,0.95),0_0_80px_30px_rgba(245,158,11,0.45)] scale-105'
                    : 'bg-gradient-to-b from-slate-800 to-slate-900 border border-slate-700/60 opacity-60 scale-95'
                }`}
              >
                {/* Glowing Filament Accent when ON */}
                {isOn && (
                  <div className="absolute inset-2 rounded-full border border-amber-100/80 opacity-90 animate-pulse" />
                )}
              </div>
            </div>
          </div>

          {/* Lower Brass Trim Rim */}
          <div
            className={`absolute -bottom-1 inset-x-0 h-2 rounded-b-md transition-colors duration-500 ${
              isOn
                ? 'bg-gradient-to-r from-amber-600 via-amber-300 to-amber-600 shadow-[0_2px_8px_rgba(245,158,11,0.5)]'
                : 'bg-gradient-to-r from-slate-700 via-amber-900/40 to-slate-800'
            }`}
          />
        </div>

        {/* Pull Cord Hanging on the Right Edge of Lamp */}
        <div className="absolute -right-4 sm:-right-6 top-16 sm:top-20 z-20">
          <PullCord isOn={isOn} onToggle={onToggle} isReducedMotion={isReducedMotion} />
        </div>
      </div>
    </div>
  );
}
