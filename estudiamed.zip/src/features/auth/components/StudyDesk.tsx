import React from 'react';
import { motion } from 'motion/react';

interface StudyDeskProps {
  isOn: boolean;
  isReducedMotion?: boolean;
}

export function StudyDesk({ isOn, isReducedMotion = false }: StudyDeskProps) {
  return (
    <div
      aria-hidden="true"
      className="absolute inset-x-0 bottom-0 h-44 sm:h-56 pointer-events-none overflow-hidden select-none z-0"
    >
      {/* Desk Surface Edge / Bevel */}
      <div className="absolute inset-x-0 top-0 h-[2px] bg-gradient-to-r from-slate-900 via-slate-700/60 to-slate-900" />

      {/* Desk Matte Surface */}
      <div
        className={`w-full h-full transition-colors duration-700 ${
          isOn
            ? 'bg-gradient-to-b from-slate-950 via-[#0B0F19] to-[#06080E]'
            : 'bg-[#05070B]'
        }`}
      >
        {/* Subtle Warm Reflection across desk center */}
        <motion.div
          initial={false}
          animate={{ opacity: isOn ? 0.35 : 0 }}
          transition={{ duration: isReducedMotion ? 0.3 : 0.8 }}
          className="absolute inset-0 bg-[radial-gradient(ellipse_60%_40%_at_50%_0%,rgba(245,158,11,0.25),transparent_70%)]"
        />

        {/* Fine Desk Grain / Leather Desk Mat Texture */}
        <div className="absolute inset-x-12 sm:inset-x-24 top-4 bottom-0 rounded-t-2xl border-t border-x border-slate-800/40 bg-slate-950/40 backdrop-blur-3xs" />
      </div>
    </div>
  );
}
