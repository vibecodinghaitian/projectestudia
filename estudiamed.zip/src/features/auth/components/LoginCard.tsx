import React, { useState, forwardRef } from 'react';
import { useAuth } from '../../../context/AuthContext';
import { Button } from '../../../components/common/Button';
import { Badge } from '../../../components/common/Badge';
import { 
  LogIn, 
  Lock, 
  Mail, 
  AlertCircle, 
  ArrowRight,
  Eye,
  EyeOff
} from 'lucide-react';
import { ForgotPasswordModal } from './ForgotPasswordModal';

interface LoginCardProps {
  onNavigate: (path: string) => void;
  isOn: boolean;
}

export const LoginCard = forwardRef<HTMLInputElement, LoginCardProps>(
  ({ onNavigate, isOn }, emailInputRef) => {
    const { loginWithEmail, loginWithGoogle, simulateRole } = useAuth();
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [showPassword, setShowPassword] = useState(false);
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);
    const [isForgotModalOpen, setIsForgotModalOpen] = useState(false);

    const handleSubmit = async (e: React.FormEvent) => {
      e.preventDefault();
      if (!email || !password) return;
      setError(null);
      setLoading(true);
      try {
        const prof = await loginWithEmail(email, password);
        onNavigate(prof.role === 'admin' ? '/admin' : '/dashboard');
      } catch (err: any) {
        console.error('Login error:', err);
        setError(err?.message || 'Identifiants invalides. Vérifiez votre adresse email et mot de passe.');
      } finally {
        setLoading(false);
      }
    };

    const handleGoogleLogin = async () => {
      setError(null);
      setLoading(true);
      try {
        const prof = await loginWithGoogle();
        onNavigate(prof.role === 'admin' ? '/admin' : '/dashboard');
      } catch (err: any) {
        console.error('Google login error:', err);
        setError(err?.message || 'Échec de connexion avec le compte Google.');
      } finally {
        setLoading(false);
      }
    };

    const handleQuickDemo = (role: 'student' | 'admin') => {
      simulateRole(role);
      onNavigate(role === 'admin' ? '/admin' : '/dashboard');
    };

    return (
      <div
        id="study-login-card"
        className="w-full max-w-md bg-slate-900/85 backdrop-blur-xl border border-slate-700/60 rounded-3xl p-7 sm:p-9 shadow-2xl text-slate-100 space-y-6 relative overflow-hidden"
      >
        {/* Subtle Warm Top Rim Highlight */}
        <div className="absolute inset-x-8 top-0 h-[1px] bg-gradient-to-r from-transparent via-amber-400/50 to-transparent" />

        {/* Branding & Medical Welcome Header */}
        <div className="text-center space-y-2">
          <div className="flex items-center justify-center gap-2.5 mb-1">
            <div className="w-8 h-8 rounded-xl bg-blue-600 flex items-center justify-center text-white font-bold text-base shadow-md">
              E
            </div>
            <span className="font-editorial text-2xl sm:text-3xl font-extrabold tracking-tight text-white">
              ESTUDIAMED
            </span>
          </div>

          <div className="text-[10px] font-mono uppercase tracking-widest text-amber-300/80">
            Medical Exam Preparation
          </div>

          <div className="pt-2">
            <h2 className="text-lg sm:text-xl font-bold text-slate-100 tracking-tight">
              Bienvenue sur Estudiamed
            </h2>
            <p className="text-xs text-slate-400 mt-0.5 max-w-xs mx-auto leading-relaxed">
              Préparez vos examens médicaux avec méthode.
            </p>
          </div>
        </div>

        {/* Error notification */}
        {error && (
          <div className="p-3 bg-rose-950/80 border border-rose-800/80 rounded-xl text-xs text-rose-300 flex items-start gap-2 animate-in fade-in">
            <AlertCircle className="w-4 h-4 shrink-0 mt-0.5 text-rose-400" />
            <span>{error}</span>
          </div>
        )}

        {/* Login Form */}
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-xs font-medium text-slate-300 mb-1">
              Email
            </label>
            <div className="relative">
              <Mail className="w-4 h-4 text-slate-500 absolute left-3.5 top-2.5" />
              <input
                ref={emailInputRef}
                id="login-email-input"
                type="email"
                required
                disabled={!isOn}
                value={email}
                onChange={e => setEmail(e.target.value)}
                placeholder="medecin@exemple.com"
                className="w-full pl-10 pr-3.5 py-2 text-xs bg-slate-950/70 border border-slate-700/80 text-white rounded-xl placeholder:text-slate-600 focus:ring-2 focus:ring-amber-400/60 focus:border-amber-400/80 focus:outline-none transition-all"
              />
            </div>
          </div>

          <div>
            <div className="flex items-center justify-between mb-1">
              <label className="block text-xs font-medium text-slate-300">
                Password
              </label>
              <button
                type="button"
                onClick={() => setIsForgotModalOpen(true)}
                className="text-[11px] text-amber-300/90 hover:text-amber-200 transition-colors cursor-pointer hover:underline"
              >
                Mot de passe oublié ?
              </button>
            </div>
            <div className="relative">
              <Lock className="w-4 h-4 text-slate-500 absolute left-3.5 top-2.5" />
              <input
                id="login-password-input"
                type={showPassword ? 'text' : 'password'}
                required
                disabled={!isOn}
                value={password}
                onChange={e => setPassword(e.target.value)}
                placeholder="••••••••"
                className="w-full pl-10 pr-10 py-2 text-xs bg-slate-950/70 border border-slate-700/80 text-white rounded-xl placeholder:text-slate-600 focus:ring-2 focus:ring-amber-400/60 focus:border-amber-400/80 focus:outline-none transition-all"
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute right-3 top-2.5 text-slate-500 hover:text-slate-300 transition-colors cursor-pointer"
                title={showPassword ? 'Masquer' : 'Afficher'}
              >
                {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>
          </div>

          <Button
            id="login-submit-btn"
            type="submit"
            disabled={!isOn}
            loading={loading}
            className="w-full mt-2 bg-blue-600 hover:bg-blue-500 text-white shadow-md font-semibold"
            icon={<LogIn className="w-4 h-4" />}
          >
            Se connecter
          </Button>
        </form>

        {/* Divider */}
        <div className="relative my-3 text-center">
          <div className="absolute inset-0 flex items-center">
            <div className="w-full border-t border-slate-800" />
          </div>
          <span className="relative bg-slate-900 px-3 text-[10px] uppercase tracking-widest text-slate-500 font-mono">
            OU
          </span>
        </div>

        {/* Google Authentication */}
        <Button
          id="google-login-btn"
          type="button"
          variant="outline"
          disabled={!isOn}
          className="w-full bg-slate-950/80 hover:bg-slate-950 border-slate-700 text-slate-200 text-xs"
          onClick={handleGoogleLogin}
        >
          <svg className="w-4 h-4 mr-2 shrink-0" viewBox="0 0 24 24">
            <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/>
            <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/>
            <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"/>
            <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"/>
          </svg>
          Continuer avec Google
        </Button>

        {/* Sandbox quick evaluation switches */}
        <div className="pt-3 border-t border-slate-800/80 -mx-7 sm:-mx-9 -mb-7 sm:-mb-9 p-5 bg-slate-950/70 rounded-b-3xl space-y-2">
          <p className="text-[9px] font-mono uppercase tracking-widest text-slate-500 text-center font-bold">
            ACCÈS RAPIDE SANDBOX (TEST)
          </p>
          <div className="grid grid-cols-2 gap-2">
            <button
              type="button"
              onClick={() => handleQuickDemo('student')}
              className="px-3 py-1.5 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-700/80 text-[11px] font-medium text-slate-300 hover:text-white transition-colors cursor-pointer"
            >
              Mode Étudiant
            </button>
            <button
              type="button"
              onClick={() => handleQuickDemo('admin')}
              className="px-3 py-1.5 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-700/80 text-[11px] font-medium text-amber-300 hover:text-amber-200 transition-colors cursor-pointer"
            >
              Mode Admin
            </button>
          </div>
        </div>

        {/* Create account link */}
        <div className="text-center pt-2">
          <p className="text-xs text-slate-400">
            Nouveau sur la plateforme ?{' '}
            <button
              type="button"
              onClick={() => onNavigate('/register')}
              className="text-amber-300 font-semibold hover:text-amber-200 hover:underline cursor-pointer"
            >
              Créer un compte
            </button>
          </p>
        </div>

        {/* Forgot Password Modal */}
        <ForgotPasswordModal
          isOpen={isForgotModalOpen}
          onClose={() => setIsForgotModalOpen(false)}
          initialEmail={email}
        />
      </div>
    );
  }
);
LoginCard.displayName = 'LoginCard';
