import React from 'react';
import { motion } from 'motion/react';

interface AmbientLightProps {
  isOn: boolean;
  isReducedMotion?: boolean;
}

export function AmbientLight({ isOn, isReducedMotion = false }: AmbientLightProps) {
  return (
    <div
      aria-hidden="true"
      className="absolute inset-0 pointer-events-none overflow-hidden z-0"
    >
      {/* Primary Radiant Cone of Light from the Lamp */}
      <motion.div
        initial={false}
        animate={{
          opacity: isOn ? 1 : 0,
          scale: isOn ? 1 : 0.85,
        }}
        transition={{
          duration: isReducedMotion ? 0.3 : 0.8,
          ease: [0.16, 1, 0.3, 1],
          delay: isOn ? (isReducedMotion ? 0 : 0.15) : 0,
        }}
        className="absolute top-16 sm:top-20 left-1/2 -translate-x-1/2 w-[850px] sm:w-[1100px] h-[750px] sm:h-[900px]"
        style={{
          background:
            'radial-gradient(ellipse 65% 55% at 50% 10%, rgba(254, 243, 199, 0.35) 0%, rgba(251, 191, 36, 0.22) 28%, rgba(245, 158, 11, 0.10) 55%, rgba(15, 23, 42, 0) 80%)',
          filter: 'blur(24px)',
        }}
      />

      {/* Desk Surface Golden Pool (Intense reflection on the desk center) */}
      <motion.div
        initial={false}
        animate={{
          opacity: isOn ? 0.95 : 0,
          scale: isOn ? 1 : 0.9,
        }}
        transition={{
          duration: isReducedMotion ? 0.3 : 0.7,
          ease: 'easeOut',
          delay: isOn ? (isReducedMotion ? 0 : 0.2) : 0,
        }}
        className="absolute top-48 sm:top-56 left-1/2 -translate-x-1/2 w-[550px] sm:w-[750px] h-[500px] sm:h-[650px]"
        style={{
          background:
            'radial-gradient(circle at 50% 40%, rgba(253, 230, 138, 0.18) 0%, rgba(245, 158, 11, 0.08) 45%, transparent 75%)',
          filter: 'blur(36px)',
        }}
      />

      {/* Subtle Warm Atmospheric Backlight on Dark Midnight Walls */}
      <motion.div
        initial={false}
        animate={{
          opacity: isOn ? 0.4 : 0,
        }}
        transition={{
          duration: isReducedMotion ? 0.3 : 0.9,
          delay: isOn ? (isReducedMotion ? 0 : 0.25) : 0,
        }}
        className="absolute -top-10 left-1/2 -translate-x-1/2 w-full h-[450px]"
        style={{
          background:
            'radial-gradient(ellipse 70% 30% at 50% 0%, rgba(245, 158, 11, 0.14) 0%, rgba(30, 58, 138, 0.08) 50%, transparent 80%)',
        }}
      />
    </div>
  );
}
