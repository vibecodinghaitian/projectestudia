import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { StudyLamp } from './StudyLamp';
import { StudyDesk } from './StudyDesk';
import { StudyObjects } from './StudyObjects';
import { AmbientLight } from './AmbientLight';
import { LoginCard } from './LoginCard';
import { Sparkles } from 'lucide-react';

interface StudyModeSceneProps {
  onNavigate: (path: string) => void;
}

export function StudyModeScene({ onNavigate }: StudyModeSceneProps) {
  const [isOn, setIsOn] = useState<boolean>(false);
  const [showStudyBadge, setShowStudyBadge] = useState<boolean>(false);
  const [isReducedMotion, setIsReducedMotion] = useState<boolean>(false);
  const emailInputRef = useRef<HTMLInputElement>(null);
  const badgeTimerRef = useRef<NodeJS.Timeout | null>(null);

  // Check user system preference for reduced motion
  useEffect(() => {
    if (typeof window !== 'undefined') {
      const mediaQuery = window.matchMedia('(prefers-reduced-motion: reduce)');
      setIsReducedMotion(mediaQuery.matches);
      const handleChange = (e: MediaQueryListEvent) => setIsReducedMotion(e.matches);
      mediaQuery.addEventListener('change', handleChange);
      return () => mediaQuery.removeEventListener('change', handleChange);
    }
  }, []);

  // Handle Lamp Toggle
  const handleToggle = () => {
    const nextState = !isOn;
    setIsOn(nextState);

    if (nextState) {
      // Show subtle "STUDY MODE" badge briefly
      setShowStudyBadge(true);
      if (badgeTimerRef.current) clearTimeout(badgeTimerRef.current);
      badgeTimerRef.current = setTimeout(() => {
        setShowStudyBadge(false);
      }, 3500);

      // Auto-focus email input after animation finishes (~1200ms or 300ms if reduced motion)
      const focusDelay = isReducedMotion ? 200 : 1200;
      setTimeout(() => {
        emailInputRef.current?.focus();
      }, focusDelay);
    } else {
      setShowStudyBadge(false);
      if (badgeTimerRef.current) clearTimeout(badgeTimerRef.current);
    }
  };

  return (
    <div
      id="study-mode-scene-container"
      className="relative min-h-[88vh] w-full flex flex-col items-center justify-center bg-[#070A12] text-slate-100 overflow-hidden select-none py-12 px-4 sm:px-6 transition-colors duration-1000"
    >
      {/* 1. Realistic Ambient Light Simulation Layer */}
      <AmbientLight isOn={isOn} isReducedMotion={isReducedMotion} />

      {/* 2. Wooden Study Desk Base Layer */}
      <StudyDesk isOn={isOn} isReducedMotion={isReducedMotion} />

      {/* 3. Subtle Medical Academic Study Objects */}
      <StudyObjects isOn={isOn} isReducedMotion={isReducedMotion} />

      {/* 4. Elegant Floating "STUDY MODE" Indicator */}
      <div className="absolute top-6 left-1/2 -translate-x-1/2 z-30 pointer-events-none">
        <AnimatePresence>
          {showStudyBadge && (
            <motion.div
              initial={{ opacity: 0, y: -10, scale: 0.95 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: -8, scale: 0.95 }}
              transition={{ duration: 0.5, ease: 'easeOut' }}
              className="px-3.5 py-1 rounded-full bg-amber-500/15 border border-amber-400/40 text-amber-300 text-[10px] font-mono font-bold tracking-widest uppercase flex items-center gap-2 shadow-[0_0_20px_rgba(245,158,11,0.2)] backdrop-blur-md"
            >
              <span className="w-1.5 h-1.5 rounded-full bg-amber-400 animate-ping" />
              <span>STUDY MODE ACTIVE</span>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* 5. Main Composition: Desk Lamp & Illuminated Login Card */}
      <div className="relative z-20 w-full max-w-lg flex flex-col items-center">
        {/* The Medical Study Desk Lamp */}
        <div className="mb-2 sm:mb-4">
          <StudyLamp
            isOn={isOn}
            onToggle={handleToggle}
            isReducedMotion={isReducedMotion}
          />
        </div>

        {/* Dynamic Dark Mode Room Hint when Lamp is OFF */}
        {!isOn && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: [0.4, 0.8, 0.4] }}
            transition={{ duration: 3, repeat: Infinity, ease: 'easeInOut' }}
            className="text-center my-8 max-w-xs space-y-2 pointer-events-none"
          >
            <p className="font-editorial text-xl font-medium text-slate-400/90 italic">
              « Salle d'étude médicale »
            </p>
            <p className="text-xs font-mono text-amber-400/70 tracking-wide uppercase">
              Puxe a cordinha da lâmpada para acender o modo estudo
            </p>
          </motion.div>
        )}

        {/* Illuminated Login Card Container */}
        <motion.div
          initial={false}
          animate={{
            opacity: isOn ? 1 : 0.04,
            y: isOn ? 0 : 20,
            scale: isOn ? 1 : 0.96,
            pointerEvents: isOn ? 'auto' : 'none',
          }}
          transition={{
            duration: isReducedMotion ? 0.3 : 0.7,
            delay: isOn ? (isReducedMotion ? 0 : 0.4) : 0,
            ease: [0.16, 1, 0.3, 1],
          }}
          className="w-full flex justify-center mt-2 sm:mt-4"
        >
          <LoginCard
            ref={emailInputRef}
            onNavigate={onNavigate}
            isOn={isOn}
          />
        </motion.div>
      </div>

      {/* Screen Reader Live Status Announcement */}
      <div className="sr-only" aria-live="polite" aria-atomic="true">
        {isOn
          ? 'Mode étude activé. La lampe est allumée et le formulaire de connexion est visible.'
          : 'Mode étude désactivé. La lampe est éteinte.'}
      </div>
    </div>
  );
}
