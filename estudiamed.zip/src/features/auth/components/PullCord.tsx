import React, { useState, useEffect, useRef } from 'react';
import { motion, useAnimation } from 'motion/react';

interface PullCordProps {
  isOn: boolean;
  onToggle: () => void;
  isReducedMotion?: boolean;
}

export function PullCord({ isOn, onToggle, isReducedMotion = false }: PullCordProps) {
  const [isPulling, setIsPulling] = useState(false);
  const cordControls = useAnimation();
  const beadRef = useRef<HTMLButtonElement>(null);

  const triggerPull = async () => {
    if (isPulling) return;
    setIsPulling(true);

    if (isReducedMotion) {
      onToggle();
      setIsPulling(false);
      return;
    }

    // 0ms: Cord moves down
    await cordControls.start({
      scaleY: 1.35,
      y: 18,
      transition: { duration: 0.1, ease: 'easeOut' },
    });

    // Toggle lamp state right at max extension (100ms)
    onToggle();

    // 100ms - 600ms: Cord swings with natural pendulum damping
    await cordControls.start({
      scaleY: 1,
      y: 0,
      rotate: [0, 8, -6, 4, -2, 0],
      transition: {
        y: { type: 'spring', stiffness: 450, damping: 14 },
        scaleY: { type: 'spring', stiffness: 450, damping: 14 },
        rotate: { duration: 0.8, ease: 'easeInOut' },
      },
    });

    setIsPulling(false);
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' || e.key === ' ') {
      e.preventDefault();
      triggerPull();
    }
  };

  return (
    <div className="relative flex flex-col items-center">
      <motion.div
        animate={cordControls}
        style={{ transformOrigin: 'top center' }}
        className="flex flex-col items-center cursor-pointer select-none"
        onClick={triggerPull}
      >
        {/* Cord Line (Beaded chain look) */}
        <div className="w-[2px] h-14 bg-gradient-to-b from-amber-600/90 via-amber-400/80 to-amber-600/90 shadow-xs" />

        {/* Pull Bead / Brass Toggle Handle */}
        <button
          ref={beadRef}
          id="lamp-pull-cord-btn"
          type="button"
          role="button"
          tabIndex={0}
          aria-label="Activer ou désactiver le mode étude"
          aria-pressed={isOn}
          onKeyDown={handleKeyDown}
          onClick={(e) => {
            e.stopPropagation();
            triggerPull();
          }}
          className={`group relative -mt-0.5 w-4 h-7 rounded-full transition-all duration-300 focus:outline-none focus-visible:ring-2 focus-visible:ring-amber-400 focus-visible:ring-offset-2 focus-visible:ring-offset-slate-900 cursor-pointer ${
            isOn
              ? 'bg-gradient-to-b from-amber-300 via-amber-400 to-amber-600 shadow-[0_0_12px_rgba(245,158,11,0.6)]'
              : 'bg-gradient-to-b from-slate-600 via-amber-900/60 to-slate-800 shadow-sm'
          }`}
        >
          {/* Subtle metallic ridges */}
          <div className="absolute inset-x-0 top-1.5 h-[1px] bg-white/40" />
          <div className="absolute inset-x-0 top-3 h-[1px] bg-black/30" />
          <div className="absolute inset-x-0 bottom-1.5 h-[1px] bg-white/20" />

          {/* Interactive Hint Indicator when Lamp is OFF */}
          {!isOn && (
            <span className="absolute -bottom-7 left-1/2 -translate-x-1/2 px-2 py-0.5 rounded-full bg-slate-800/90 border border-amber-500/40 text-[9px] font-mono text-amber-300 uppercase tracking-widest whitespace-nowrap shadow-lg animate-pulse pointer-events-none">
              Puxe aqui
            </span>
          )}
        </button>
      </motion.div>
    </div>
  );
}
