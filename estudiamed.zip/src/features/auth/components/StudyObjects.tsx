import React from 'react';
import { motion } from 'motion/react';

interface StudyObjectsProps {
  isOn: boolean;
  isReducedMotion?: boolean;
}

export function StudyObjects({ isOn, isReducedMotion = false }: StudyObjectsProps) {
  return (
    <div
      aria-hidden="true"
      className="absolute inset-0 pointer-events-none select-none overflow-hidden z-1"
    >
      {/* 1. LEFT PERIPHERY: Closed Medical Textbook & ECG Strip (Desktop / Tablet) */}
      <motion.div
        initial={false}
        animate={{
          opacity: isOn ? 0.85 : 0.08,
          x: isOn ? 0 : -8,
          y: isOn ? 0 : 6,
        }}
        transition={{
          duration: isReducedMotion ? 0.3 : 0.8,
          delay: isOn ? (isReducedMotion ? 0 : 0.35) : 0,
          ease: 'easeOut',
        }}
        className="hidden md:flex flex-col absolute left-4 lg:left-12 bottom-12 sm:bottom-16 w-56 lg:w-64 rotate-[-6deg] origin-bottom-left"
      >
        {/* Medical Textbook: "Robbins & Cotran - Patologia Médica" */}
        <div
          className={`relative rounded-r-xl rounded-l-xs p-4 transition-all duration-700 ${
            isOn
              ? 'bg-gradient-to-r from-slate-900 via-amber-950/60 to-slate-900 border-l-4 border-amber-600/70 shadow-2xl'
              : 'bg-slate-950 border-l-2 border-slate-800'
          }`}
          style={{ height: '140px' }}
        >
          {/* Gold Foil Embossed Spine & Title */}
          <div className="flex flex-col justify-between h-full text-slate-300">
            <div>
              <div className="flex items-center gap-1.5 opacity-60 text-[9px] font-mono tracking-widest uppercase text-amber-300">
                <span>VOL. I</span>
                <span>•</span>
                <span>PROVAS & BANCA</span>
              </div>
              <p className="font-editorial text-sm font-bold text-amber-200/90 mt-1 tracking-tight">
                TRATADO DE MEDICINA CLÍNICA
              </p>
              <p className="text-[9px] text-slate-400 font-mono mt-0.5">Diagnóstico & Conduta Médica</p>
            </div>

            {/* Subtle Gold Ribbon Bookmark */}
            <div className="absolute right-6 -bottom-3 w-3 h-8 bg-amber-500/90 rounded-b shadow-md" />

            <div className="text-[8px] font-mono text-amber-400/60 tracking-wider">
              ESTUDIAMED ACADEMIC PRESS
            </div>
          </div>
        </div>

        {/* Small ECG Strip Resting under the Book */}
        <div className="mt-2 ml-4 p-2 bg-amber-100/10 border border-amber-400/20 rounded-md backdrop-blur-xs w-48 rotate-[-3deg] shadow-sm">
          <div className="flex items-center justify-between text-[7px] font-mono text-amber-300/80 mb-1">
            <span>DII - RITMO SINUSAL</span>
            <span>72 BPM</span>
          </div>
          {/* ECG SVG Waveform */}
          <svg className="w-full h-5 stroke-amber-400/70 fill-none" viewBox="0 0 160 20">
            <path
              d="M0,10 L20,10 L24,10 L28,7 L32,10 L36,10 L38,13 L40,1 L43,18 L46,10 L50,10 L56,6 L62,10 L80,10 L84,10 L88,7 L92,10 L96,10 L98,13 L100,1 L103,18 L106,10 L110,10 L116,6 L122,10 L160,10"
              strokeWidth="1.2"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
          </svg>
        </div>
      </motion.div>

      {/* 2. RIGHT PERIPHERY: Anatomical Sketch, Stethoscope & Medical Pen */}
      <motion.div
        initial={false}
        animate={{
          opacity: isOn ? 0.85 : 0.08,
          x: isOn ? 0 : 8,
          y: isOn ? 0 : 6,
        }}
        transition={{
          duration: isReducedMotion ? 0.3 : 0.85,
          delay: isOn ? (isReducedMotion ? 0 : 0.4) : 0,
          ease: 'easeOut',
        }}
        className="hidden md:flex flex-col absolute right-4 lg:right-12 bottom-10 sm:bottom-14 w-60 lg:w-68 rotate-[4deg] origin-bottom-right"
      >
        {/* Anatomical Study Note on Parchment Card */}
        <div
          className={`relative rounded-xl p-4 transition-all duration-700 ${
            isOn
              ? 'bg-slate-900/90 border border-amber-500/30 shadow-2xl backdrop-blur-xs'
              : 'bg-slate-950 border border-slate-800/60'
          }`}
        >
          <div className="flex items-center justify-between text-[9px] font-mono text-amber-300/80 mb-2">
            <span>CASO CLÍNICO #042</span>
            <span>REVALIDA / MIR</span>
          </div>

          <div className="flex items-center gap-3">
            {/* Cardiac Anatomical Diagram Icon */}
            <div className="w-12 h-12 rounded-lg bg-amber-500/10 border border-amber-500/20 flex items-center justify-center shrink-0">
              <svg className="w-8 h-8 stroke-amber-300/80 fill-none" viewBox="0 0 24 24">
                <path
                  d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z"
                  strokeWidth="1.2"
                />
                <path d="M12 7v5l3 3" strokeWidth="1" />
              </svg>
            </div>
            <div className="text-[10px] text-slate-300 font-sans leading-tight">
              <p className="font-semibold text-amber-200">Ausculta Cardíaca</p>
              <p className="text-slate-400 text-[9px] mt-0.5">Sopro sistólico ejetivo em foco aórtico (Estenose Aórtica).</p>
            </div>
          </div>

          {/* Handwritten-like bullets */}
          <div className="mt-3 pt-2 border-t border-slate-800 text-[9px] text-slate-400 font-mono space-y-1">
            <div className="flex items-center gap-1.5 text-emerald-400/90">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
              <span>Conduta: Ecocardiograma Transtorácico</span>
            </div>
          </div>
        </div>

        {/* Brushed Stainless Medical Pen */}
        <div className="mt-3 ml-8 flex items-center gap-2 rotate-[-8deg] opacity-70">
          <div className="w-40 h-2 bg-gradient-to-r from-slate-400 via-amber-200 to-slate-500 rounded-full shadow-sm" />
          <div className="w-3 h-1 bg-amber-400 rounded-xs" />
        </div>
      </motion.div>

      {/* 3. MOBILE AMBIENT MEDICAL ACCENT (Very subtle ECG wave at bottom for mobile) */}
      <motion.div
        initial={false}
        animate={{ opacity: isOn ? 0.4 : 0 }}
        transition={{ duration: 0.5 }}
        className="md:hidden absolute bottom-3 inset-x-8 flex items-center justify-between text-[8px] font-mono text-amber-400/60"
      >
        <span>MODO ESTUDO • REVALIDA BRASIL</span>
        <span>72 BPM • SINUSAL</span>
      </motion.div>
    </div>
  );
}
