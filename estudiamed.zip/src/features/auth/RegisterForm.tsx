import React, { useState } from 'react';
import { useAuth } from '../../context/AuthContext';
import { useExam } from '../../context/ExamContext';
import { Button } from '../../components/common/Button';
import { 
  UserPlus, 
  Lock, 
  Mail, 
  User, 
  AlertCircle
} from 'lucide-react';

interface RegisterFormProps {
  onNavigate: (path: string) => void;
}

export function RegisterForm({ onNavigate }: RegisterFormProps) {
  const { registerWithEmail } = useAuth();
  const { exams } = useExam();
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [targetExamId, setTargetExamId] = useState('revalida-br');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name || !email || !password) return;
    setError(null);
    setLoading(true);
    try {
      await registerWithEmail(email, password, name);
      onNavigate('/dashboard');
    } catch (err: any) {
      console.error('Registration error:', err);
      setError(err?.message || 'Falha ao criar conta. Tente novamente.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-md mx-auto my-12 bg-white border border-slate-200 rounded-3xl p-8 sm:p-10 shadow-sm space-y-6">
      <div className="text-center space-y-2">
        <div className="w-10 h-10 rounded-xl bg-blue-600 flex items-center justify-center text-white font-bold text-lg mx-auto mb-3 shadow-sm">
          E
        </div>
        <div className="inline-block px-3 py-1 bg-blue-100 text-blue-800 text-3xs font-bold rounded-full uppercase tracking-wider font-mono">
          NOVA CONTA MÉDICA
        </div>
        <h2 className="font-editorial text-3xl font-extrabold tracking-tight text-slate-900">
          Criar Conta Estudiamed
        </h2>
        <p className="text-xs text-slate-500 max-w-xs mx-auto">
          Inicie sua preparação personalizada para o REVALIDA e exames médicos internacionais.
        </p>
      </div>

      {error && (
        <div className="p-3 bg-rose-50 border border-rose-200 rounded-xl text-xs text-rose-700 flex items-start gap-2">
          <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
          <span>{error}</span>
        </div>
      )}

      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label className="block text-xs font-semibold text-slate-700 mb-1">Nome Completo</label>
          <div className="relative">
            <User className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
            <input
              id="register-name-input"
              type="text"
              required
              value={name}
              onChange={e => setName(e.target.value)}
              placeholder="Dr(a). Seu Nome"
              className="w-full pl-9 pr-3 py-2 text-xs border border-slate-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:outline-none"
            />
          </div>
        </div>

        <div>
          <label className="block text-xs font-semibold text-slate-700 mb-1">E-mail</label>
          <div className="relative">
            <Mail className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
            <input
              id="register-email-input"
              type="email"
              required
              value={email}
              onChange={e => setEmail(e.target.value)}
              placeholder="medico@exemplo.com"
              className="w-full pl-9 pr-3 py-2 text-xs border border-slate-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:outline-none"
            />
          </div>
        </div>

        <div>
          <label className="block text-xs font-semibold text-slate-700 mb-1">Senha</label>
          <div className="relative">
            <Lock className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
            <input
              id="register-password-input"
              type="password"
              required
              minLength={6}
              value={password}
              onChange={e => setPassword(e.target.value)}
              placeholder="Mínimo 6 caracteres"
              className="w-full pl-9 pr-3 py-2 text-xs border border-slate-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:outline-none"
            />
          </div>
        </div>

        <div>
          <label className="block text-xs font-semibold text-slate-700 mb-1">Exame de Foco Inicial</label>
          <select
            value={targetExamId}
            onChange={e => setTargetExamId(e.target.value)}
            className="w-full px-3 py-2 text-xs border border-slate-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:outline-none"
          >
            {exams.map(exam => (
              <option key={exam.id} value={exam.id}>
                {exam.name} ({exam.country})
              </option>
            ))}
          </select>
          <span className="text-3xs text-slate-400 mt-1 block font-mono">
            Você pode alternar de exame a qualquer momento na plataforma.
          </span>
        </div>

        <Button
          id="register-submit-btn"
          type="submit"
          className="w-full mt-2"
          loading={loading}
          icon={<UserPlus className="w-4 h-4" />}
        >
          Criar Conta de Estudante
        </Button>
      </form>

      <div className="text-center pt-2">
        <p className="text-xs text-slate-500">
          Já possui cadastro?{' '}
          <button
            onClick={() => onNavigate('/login')}
            className="text-blue-600 font-semibold hover:underline cursor-pointer"
          >
            Fazer login
          </button>
        </p>
      </div>
    </div>
  );
}
