import React, { useEffect } from 'react';
import { LandingNavbar } from './components/LandingNavbar';
import { HeroSection } from './components/HeroSection';
import { ValuePropsSection } from './components/ValuePropsSection';
import { ExamCatalogSection } from './components/ExamCatalogSection';
import { HowItWorksSection } from './components/HowItWorksSection';
import { TrustSection } from './components/TrustSection';
import { PricingSection } from './components/PricingSection';
import { FaqSection } from './components/FaqSection';
import { FinalCtaSection } from './components/FinalCtaSection';
import { LandingFooter } from './components/LandingFooter';

interface LandingPageProps {
  onNavigate: (path: string) => void;
}

export function LandingPage({ onNavigate }: LandingPageProps) {
  useEffect(() => {
    // Scroll to top on landing page mount
    window.scrollTo(0, 0);
  }, []);

  return (
    <div className="min-h-screen bg-white text-slate-900 flex flex-col font-sans selection:bg-blue-100 selection:text-blue-900">
      {/* Sticky Header with Navigation & Language Selector */}
      <LandingNavbar onNavigate={onNavigate} />

      {/* Main Page Flow */}
      <main className="flex-1">
        {/* 1. Hero with Live Study Visual & Lamp Mode aesthetics */}
        <HeroSection onNavigate={onNavigate} />

        {/* 2. Value Propositions (Question Bank, Simulations, Corrections, Progress) */}
        <ValuePropsSection />

        {/* 3. Multi-Exam Catalog (REVALIDA Active + MIR, ENARM, USMLE, PLAB coming soon) */}
        <ExamCatalogSection onNavigate={onNavigate} />

        {/* 4. 3-Step Study Workflow */}
        <HowItWorksSection />

        {/* 5. Serious Academic Trust & Integrity Pillars */}
        <TrustSection />

        {/* 6. Pricing Plans ($1.99 / $2.99 / $3.99) & Promo Codes */}
        <PricingSection onNavigate={onNavigate} />

        {/* 7. Comprehensive Multilingual FAQ (8 localized questions) */}
        <FaqSection />

        {/* 8. Final Conversion CTA */}
        <FinalCtaSection onNavigate={onNavigate} />
      </main>

      {/* Academic Medical Footer */}
      <LandingFooter onNavigate={onNavigate} />
    </div>
  );
}
