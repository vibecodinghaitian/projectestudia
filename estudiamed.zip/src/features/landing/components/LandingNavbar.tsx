import React, { useState } from 'react';
import { useLanguage } from '../../../context/LanguageContext';
import { LanguageSelector } from './LanguageSelector';
import { useAuth } from '../../../context/AuthContext';
import { Menu, X, BookOpen, ArrowRight, ShieldCheck, User } from 'lucide-react';

interface LandingNavbarProps {
  onNavigate: (path: string) => void;
}

export function LandingNavbar({ onNavigate }: LandingNavbarProps) {
  const { t } = useLanguage();
  const { user, isAuthenticated, isAdmin } = useAuth();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const scrollToSection = (id: string) => {
    setMobileMenuOpen(false);
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <header className="sticky top-0 z-40 w-full bg-white/95 backdrop-blur-md border-b border-slate-200/80 transition-all">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-18 flex items-center justify-between">
        
        {/* Brand Logo */}
        <div 
          onClick={() => onNavigate('/')} 
          className="flex items-center gap-3 cursor-pointer group select-none"
        >
          <div className="w-9 h-9 rounded-xl bg-blue-600 flex items-center justify-center text-white shadow-xs group-hover:bg-blue-700 transition-colors">
            <span className="font-editorial text-lg font-bold">E</span>
          </div>
          <div>
            <span className="font-editorial text-xl font-extrabold tracking-tight text-slate-900 leading-none block">
              ESTUDIAMED
            </span>
            <span className="text-3xs font-mono font-medium text-slate-400 tracking-wider uppercase block mt-0.5">
              Medical Examination Platform
            </span>
          </div>
        </div>

        {/* Desktop Navigation Links */}
        <nav className="hidden md:flex items-center gap-8 text-xs font-semibold text-slate-600">
          <button
            onClick={() => scrollToSection('top')}
            className="hover:text-blue-600 transition-colors py-1 cursor-pointer"
          >
            {t.nav.home}
          </button>
          <button
            onClick={() => scrollToSection('exams')}
            className="hover:text-blue-600 transition-colors py-1 cursor-pointer"
          >
            {t.nav.exams}
          </button>
          <button
            onClick={() => scrollToSection('features')}
            className="hover:text-blue-600 transition-colors py-1 cursor-pointer"
          >
            {t.nav.features}
          </button>
          <button
            onClick={() => scrollToSection('pricing')}
            className="hover:text-blue-600 transition-colors py-1 cursor-pointer"
          >
            {t.nav.pricing}
          </button>
          <button
            onClick={() => scrollToSection('faq')}
            className="hover:text-blue-600 transition-colors py-1 cursor-pointer"
          >
            {t.nav.faq}
          </button>
        </nav>

        {/* Right Actions: Language Selector + Auth */}
        <div className="hidden sm:flex items-center gap-3">
          <LanguageSelector />

          {isAuthenticated ? (
            <div className="flex items-center gap-2">
              <button
                onClick={() => onNavigate(isAdmin ? '/admin' : '/dashboard')}
                className="px-4 py-2 rounded-xl text-xs font-bold bg-slate-900 text-white hover:bg-slate-800 transition-colors flex items-center gap-2 shadow-xs"
              >
                {isAdmin ? <ShieldCheck className="w-3.5 h-3.5 text-amber-400" /> : <User className="w-3.5 h-3.5" />}
                <span>{isAdmin ? t.nav.admin : t.nav.dashboard}</span>
                <ArrowRight className="w-3.5 h-3.5 text-slate-400" />
              </button>
            </div>
          ) : (
            <div className="flex items-center gap-2">
              <button
                onClick={() => onNavigate('/login')}
                className="px-3.5 py-2 rounded-xl text-xs font-semibold text-slate-700 hover:text-slate-900 hover:bg-slate-100 transition-colors cursor-pointer"
              >
                {t.nav.login}
              </button>

              <button
                onClick={() => onNavigate('/register')}
                className="px-4 py-2 rounded-xl text-xs font-bold text-white bg-blue-600 hover:bg-blue-700 transition-colors flex items-center gap-1.5 shadow-xs cursor-pointer"
              >
                <span>{t.nav.getStarted}</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          )}
        </div>

        {/* Mobile Hamburger Button */}
        <div className="flex items-center gap-2 md:hidden">
          <LanguageSelector />
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="p-2 rounded-xl text-slate-600 hover:text-slate-900 hover:bg-slate-100 transition-colors"
            aria-label="Toggle navigation menu"
          >
            {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>
      </div>

      {/* Mobile Drawer */}
      {mobileMenuOpen && (
        <div className="md:hidden border-b border-slate-200 bg-white px-4 pt-3 pb-6 space-y-4 animate-in slide-in-from-top-2 duration-200">
          <div className="flex flex-col space-y-2 text-sm font-semibold text-slate-700">
            <button
              onClick={() => scrollToSection('top')}
              className="text-left px-3 py-2 rounded-xl hover:bg-slate-50 transition-colors"
            >
              {t.nav.home}
            </button>
            <button
              onClick={() => scrollToSection('exams')}
              className="text-left px-3 py-2 rounded-xl hover:bg-slate-50 transition-colors"
            >
              {t.nav.exams}
            </button>
            <button
              onClick={() => scrollToSection('features')}
              className="text-left px-3 py-2 rounded-xl hover:bg-slate-50 transition-colors"
            >
              {t.nav.features}
            </button>
            <button
              onClick={() => scrollToSection('pricing')}
              className="text-left px-3 py-2 rounded-xl hover:bg-slate-50 transition-colors"
            >
              {t.nav.pricing}
            </button>
            <button
              onClick={() => scrollToSection('faq')}
              className="text-left px-3 py-2 rounded-xl hover:bg-slate-50 transition-colors"
            >
              {t.nav.faq}
            </button>
          </div>

          <div className="pt-3 border-t border-slate-100 flex flex-col gap-2">
            {isAuthenticated ? (
              <button
                onClick={() => {
                  setMobileMenuOpen(false);
                  onNavigate(isAdmin ? '/admin' : '/dashboard');
                }}
                className="w-full py-2.5 rounded-xl text-xs font-bold text-white bg-slate-900 text-center flex items-center justify-center gap-2"
              >
                <span>{isAdmin ? t.nav.admin : t.nav.dashboard}</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            ) : (
              <>
                <button
                  onClick={() => {
                    setMobileMenuOpen(false);
                    onNavigate('/login');
                  }}
                  className="w-full py-2.5 rounded-xl text-xs font-semibold text-slate-700 bg-slate-100 text-center"
                >
                  {t.nav.login}
                </button>
                <button
                  onClick={() => {
                    setMobileMenuOpen(false);
                    onNavigate('/register');
                  }}
                  className="w-full py-2.5 rounded-xl text-xs font-bold text-white bg-blue-600 text-center flex items-center justify-center gap-2"
                >
                  <span>{t.nav.getStarted}</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </>
            )}
          </div>
        </div>
      )}
    </header>
  );
}
