import React, { useState } from 'react';
import { useLanguage } from '../../../context/LanguageContext';
import { 
  Clock, 
  CheckCircle2, 
  BookOpen, 
  Sparkles, 
  Activity, 
  Flame, 
  ChevronRight,
  Stethoscope,
  Award,
  Layers
} from 'lucide-react';

export function StudyVisualMockup() {
  const { t } = useLanguage();
  const [selectedOption, setSelectedOption] = useState<string>('A');
  const [showRationale, setShowRationale] = useState<boolean>(true);

  const options = [
    { id: 'A', text: t.studyVisual.optA, isCorrect: true },
    { id: 'B', text: t.studyVisual.optB, isCorrect: false },
    { id: 'C', text: t.studyVisual.optC, isCorrect: false },
    { id: 'D', text: t.studyVisual.optD, isCorrect: false },
  ];

  return (
    <div className="relative w-full max-w-2xl mx-auto select-none">
      {/* Background Soft Glow (Study Mode Lamp subtle ambient) */}
      <div className="absolute -top-6 -right-6 w-72 h-72 bg-amber-400/10 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute -bottom-6 -left-6 w-72 h-72 bg-blue-500/10 rounded-full blur-3xl pointer-events-none" />

      {/* Main Terminal Frame */}
      <div className="relative bg-white border border-slate-200/90 rounded-3xl shadow-xl shadow-slate-200/50 overflow-hidden">
        
        {/* Top Study Bar Header */}
        <div className="bg-slate-900 text-white px-5 py-3.5 flex items-center justify-between border-b border-slate-800">
          <div className="flex items-center gap-2.5">
            <div className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse" />
            <span className="text-xs font-mono font-bold tracking-tight text-slate-200">
              {t.studyVisual.examTitle}
            </span>
          </div>

          <div className="flex items-center gap-3">
            <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-slate-800 text-amber-300 text-3xs font-mono font-semibold">
              <Clock className="w-3 h-3 text-amber-400" />
              <span>{t.studyVisual.timeRemaining}</span>
            </div>
          </div>
        </div>

        {/* Sub-header with Specialty and Analytics pill */}
        <div className="bg-slate-50/90 px-5 py-2.5 border-b border-slate-100 flex flex-wrap items-center justify-between gap-2 text-3xs font-mono">
          <div className="flex items-center gap-2 text-slate-600">
            <span className="px-2 py-0.5 rounded-md bg-blue-100 text-blue-800 font-bold">
              {t.studyVisual.specialty}
            </span>
            <span className="text-slate-400">•</span>
            <span className="font-semibold text-slate-700">{t.studyVisual.questionNumber}</span>
          </div>

          <div className="flex items-center gap-3 text-slate-500">
            <span className="text-emerald-700 font-bold flex items-center gap-1">
              <Award className="w-3 h-3" />
              {t.studyVisual.accuracyRate}
            </span>
          </div>
        </div>

        {/* Clinical Vignette Body */}
        <div className="p-5 sm:p-6 space-y-4">
          <div className="space-y-2">
            <div className="flex items-center gap-1.5 text-xs font-mono font-bold text-slate-400 uppercase tracking-wider">
              <Stethoscope className="w-3.5 h-3.5 text-blue-600" />
              <span>Clinical Vignette</span>
            </div>
            <p className="text-xs sm:text-sm text-slate-800 leading-relaxed font-normal">
              {t.studyVisual.stem}
            </p>
          </div>

          {/* Interactive Option List */}
          <div className="space-y-2 pt-1">
            {options.map(opt => {
              const isSelected = selectedOption === opt.id;
              return (
                <div
                  key={opt.id}
                  onClick={() => setSelectedOption(opt.id)}
                  className={`p-3 rounded-2xl border text-xs transition-all cursor-pointer flex items-start gap-3 ${
                    isSelected
                      ? opt.isCorrect
                        ? 'bg-emerald-50/80 border-emerald-300 text-emerald-950 shadow-xs'
                        : 'bg-rose-50/80 border-rose-300 text-rose-950'
                      : 'bg-white border-slate-200/80 text-slate-700 hover:border-blue-300 hover:bg-slate-50/60'
                  }`}
                >
                  <span
                    className={`w-6 h-6 rounded-lg text-xs font-mono font-bold flex items-center justify-center shrink-0 mt-0.5 transition-colors ${
                      isSelected
                        ? opt.isCorrect
                          ? 'bg-emerald-600 text-white'
                          : 'bg-rose-600 text-white'
                        : 'bg-slate-100 text-slate-700'
                    }`}
                  >
                    {opt.id}
                  </span>
                  <span className="flex-1 leading-relaxed text-xs">
                    {opt.text}
                  </span>
                </div>
              );
            })}
          </div>

          {/* Detailed Clinical Rationale */}
          {showRationale && (
            <div className="p-3.5 rounded-2xl bg-blue-50/70 border border-blue-100 space-y-1.5 animate-in fade-in duration-200">
              <div className="flex items-center justify-between text-3xs font-mono font-bold text-blue-900">
                <span className="flex items-center gap-1.5">
                  <Sparkles className="w-3.5 h-3.5 text-blue-600" />
                  {t.studyVisual.explanationHeader}
                </span>
                <span className="px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 font-bold">
                  {t.studyVisual.correctBadge}
                </span>
              </div>
              <p className="text-xs text-blue-950 leading-relaxed font-normal">
                {t.studyVisual.explanationText}
              </p>
            </div>
          )}
        </div>

        {/* Bottom Floating Stats Panel */}
        <div className="px-5 py-3 bg-slate-900 text-white border-t border-slate-800 flex items-center justify-between text-3xs font-mono">
          <div className="flex items-center gap-4">
            <span className="text-slate-400">
              Banco Ativo: <strong className="text-white">INEP 2020–2024</strong>
            </span>
            <span className="hidden sm:inline text-slate-600">•</span>
            <span className="hidden sm:inline text-slate-400">
              Modo: <strong className="text-blue-400">Simulação Realista</strong>
            </span>
          </div>

          <div className="flex items-center gap-1 text-emerald-400 font-bold">
            <CheckCircle2 className="w-3.5 h-3.5" />
            <span>Validação Médica Homologada</span>
          </div>
        </div>
      </div>
    </div>
  );
}
