import React, { useState } from 'react';
import { useLanguage } from '../../../context/LanguageContext';
import { PRICING_PLANS } from '../../../services/subscriptionService';
import { PlanId, PricingPlan } from '../../../types';
import { CheckoutModal } from './CheckoutModal';
import { 
  Check, 
  Sparkles, 
  Tag, 
  ShieldCheck, 
  CreditCard, 
  ArrowRight,
  Zap
} from 'lucide-react';

interface PricingSectionProps {
  onNavigate: (path: string) => void;
}

export function PricingSection({ onNavigate }: PricingSectionProps) {
  const { t, language } = useLanguage();
  const [selectedPlan, setSelectedPlan] = useState<PricingPlan | null>(null);
  const [isCheckoutOpen, setIsCheckoutOpen] = useState(false);
  const [activePromoCode, setActivePromoCode] = useState('REVALIDA2026');

  const localizedPlans = PRICING_PLANS[language] || PRICING_PLANS.en;
  const plansArray: PricingPlan[] = [
    localizedPlans.starter,
    localizedPlans.pro,
    localizedPlans.premium,
  ];

  const handleSelectPlan = (plan: PricingPlan) => {
    setSelectedPlan(plan);
    setIsCheckoutOpen(true);
  };

  return (
    <section id="pricing" className="py-16 lg:py-24 bg-slate-50 border-b border-slate-200/80 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto space-y-3 mb-12">
          <div className="inline-flex items-center gap-2 px-3 py-1 bg-emerald-100 text-emerald-800 text-xs font-mono font-bold rounded-full">
            <Tag className="w-3.5 h-3.5" />
            <span>ASSINATURA MENSAL TRANSPARENTE</span>
          </div>
          <h2 className="font-editorial text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight">
            {t.pricing.sectionTitle}
          </h2>
          <p className="text-sm sm:text-base text-slate-500 leading-relaxed">
            {t.pricing.sectionSubtitle}
          </p>
        </div>

        {/* Promo Code Highlight Banner */}
        <div className="max-w-2xl mx-auto mb-12 bg-slate-900 text-white rounded-2xl p-4 sm:p-5 border border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-4 shadow-sm">
          <div className="flex items-center gap-3 text-center sm:text-left">
            <div className="w-10 h-10 rounded-xl bg-amber-400/20 text-amber-300 flex items-center justify-center shrink-0">
              <Sparkles className="w-5 h-5" />
            </div>
            <div>
              <span className="text-3xs font-mono uppercase text-amber-300 font-bold block">
                CUPOM DE LANÇAMENTO REVALIDA
              </span>
              <p className="text-xs text-slate-200 font-semibold mt-0.5">
                Utilize <code className="bg-slate-800 px-2 py-0.5 rounded text-amber-300 font-mono font-bold">REVALIDA2026</code> no checkout para 100% OFF no 1º mês.
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={() => handleSelectPlan(localizedPlans.pro)}
            className="px-4 py-2 rounded-xl text-xs font-bold bg-amber-400 text-slate-950 hover:bg-amber-300 transition-colors shrink-0 shadow-xs cursor-pointer"
          >
            Ativar 1º Mês Grátis
          </button>
        </div>

        {/* Pricing Cards Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 items-stretch">
          {plansArray.map((plan) => {
            const isPro = plan.isPopular;

            return (
              <div
                key={plan.id}
                className={`relative rounded-3xl p-8 transition-all flex flex-col justify-between ${
                  isPro
                    ? 'bg-white border-2 border-blue-600 shadow-xl shadow-blue-500/10 ring-1 ring-blue-600/20 -translate-y-1 lg:-translate-y-2'
                    : 'bg-white border border-slate-200 shadow-sm hover:border-slate-300'
                }`}
              >
                {/* Popular Tag */}
                {isPro && (
                  <div className="absolute -top-3.5 left-1/2 -translate-x-1/2 px-4 py-1 rounded-full bg-blue-600 text-white text-3xs font-mono font-bold uppercase tracking-widest shadow-xs">
                    {t.pricing.mostPopular}
                  </div>
                )}

                <div className="space-y-6">
                  {/* Plan Name & Price */}
                  <div>
                    <h3 className="font-editorial text-2xl font-bold text-slate-900">
                      {plan.name}
                    </h3>
                    <p className="text-xs font-mono text-slate-500 mt-1">
                      {typeof plan.questionLimit === 'number'
                        ? `Até ${plan.questionLimit.toLocaleString()} questões`
                        : 'Questões Ilimitadas'}
                    </p>
                  </div>

                  {/* Price display */}
                  <div className="flex items-baseline gap-1">
                    <span className="font-editorial text-4xl sm:text-5xl font-extrabold text-slate-900">
                      ${plan.priceMonthlyUSD.toFixed(2)}
                    </span>
                    <span className="text-xs font-mono text-slate-500">
                      {t.pricing.perMonth}
                    </span>
                  </div>

                  {/* Features List */}
                  <div className="space-y-3 pt-2 border-t border-slate-100">
                    <span className="text-3xs font-mono font-bold text-slate-400 uppercase tracking-wider block">
                      Recursos Inclusos:
                    </span>
                    <ul className="space-y-2.5 text-xs text-slate-700">
                      {plan.features.map((feat, idx) => (
                        <li key={idx} className="flex items-start gap-2.5">
                          <Check className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                          <span className="leading-relaxed">{feat}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>

                {/* Card Bottom CTA */}
                <div className="pt-8 space-y-2">
                  <button
                    onClick={() => handleSelectPlan(plan)}
                    className={`w-full py-3.5 rounded-2xl text-xs font-bold transition-all flex items-center justify-center gap-2 shadow-xs cursor-pointer ${
                      isPro
                        ? 'bg-blue-600 hover:bg-blue-700 text-white shadow-blue-500/20'
                        : 'bg-slate-900 hover:bg-slate-800 text-white'
                    }`}
                  >
                    <span>{plan.ctaKey}</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>

                  <p className="text-center text-3xs font-mono text-slate-400">
                    Sem fidelidade • Cancele quando quiser
                  </p>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Checkout Modal */}
      <CheckoutModal
        isOpen={isCheckoutOpen}
        onClose={() => setIsCheckoutOpen(false)}
        plan={selectedPlan}
        initialPromoCode={activePromoCode}
        onNavigate={onNavigate}
      />
    </section>
  );
}
