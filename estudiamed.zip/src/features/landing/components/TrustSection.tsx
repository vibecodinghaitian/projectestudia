import React from 'react';
import { useLanguage } from '../../../context/LanguageContext';
import { ShieldCheck, FileText, CheckCircle2, Award, Zap } from 'lucide-react';

export function TrustSection() {
  const { t } = useLanguage();

  const pillars = [
    {
      title: t.trust.pillar1Title,
      desc: t.trust.pillar1Desc,
      badge: 'INEP & Ministério',
    },
    {
      title: t.trust.pillar2Title,
      desc: t.trust.pillar2Desc,
      badge: 'Fidelidade de Prova',
    },
    {
      title: t.trust.pillar3Title,
      desc: t.trust.pillar3Desc,
      badge: 'Diretrizes Médicas',
    },
    {
      title: t.trust.pillar4Title,
      desc: t.trust.pillar4Desc,
      badge: 'Sem Distrações',
    },
  ];

  return (
    <section className="py-16 lg:py-24 bg-slate-900 text-white relative overflow-hidden">
      {/* Subtle Background Elements */}
      <div className="absolute inset-0 bg-[radial-gradient(#1e293b_1px,transparent_1px)] [background-size:20px_20px] opacity-40" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto space-y-3 mb-14">
          <div className="inline-flex items-center gap-2 px-3 py-1 bg-slate-800 text-blue-400 text-xs font-mono font-bold rounded-full border border-slate-700">
            <ShieldCheck className="w-3.5 h-3.5 text-blue-400" />
            <span>RIGOR ACADÊMICO</span>
          </div>
          <h2 className="font-editorial text-3xl sm:text-4xl font-extrabold text-white tracking-tight">
            {t.trust.sectionTitle}
          </h2>
          <p className="text-sm sm:text-base text-slate-400 leading-relaxed">
            {t.trust.sectionSubtitle}
          </p>
        </div>

        {/* 4 Pillars Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {pillars.map((p, idx) => (
            <div
              key={idx}
              className="bg-slate-800/60 border border-slate-700/80 rounded-3xl p-6 space-y-3 hover:border-slate-600 transition-colors"
            >
              <div className="flex items-center justify-between">
                <span className="px-2 py-0.5 rounded-md bg-slate-700/80 text-blue-300 text-3xs font-mono font-semibold">
                  {p.badge}
                </span>
                <CheckCircle2 className="w-4 h-4 text-emerald-400" />
              </div>

              <h3 className="font-editorial text-lg font-bold text-slate-100">
                {p.title}
              </h3>
              <p className="text-xs text-slate-400 leading-relaxed font-normal">
                {p.desc}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
