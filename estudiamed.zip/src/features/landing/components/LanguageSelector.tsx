import React from 'react';
import { useLanguage } from '../../../context/LanguageContext';
import { SupportedLanguage } from '../../../types';
import { Globe } from 'lucide-react';

interface LanguageSelectorProps {
  variant?: 'pill' | 'minimal' | 'footer';
  className?: string;
}

export function LanguageSelector({ variant = 'pill', className = '' }: LanguageSelectorProps) {
  const { language, setLanguage } = useLanguage();

  const languages: { code: SupportedLanguage; label: string; flag: string }[] = [
    { code: 'en', label: 'EN', flag: '🇺🇸' },
    { code: 'es', label: 'ES', flag: '🇪🇸' },
    { code: 'pt', label: 'PT', flag: '🇧🇷' },
  ];

  if (variant === 'footer') {
    return (
      <div className={`flex items-center gap-1 bg-slate-100 p-1 rounded-xl border border-slate-200 ${className}`}>
        <Globe className="w-3.5 h-3.5 text-slate-400 ml-1.5" />
        {languages.map(lang => (
          <button
            key={lang.code}
            onClick={() => setLanguage(lang.code)}
            className={`px-2.5 py-1 text-xs font-mono font-bold rounded-lg transition-all ${
              language === lang.code
                ? 'bg-white text-slate-900 shadow-xs border border-slate-200/80'
                : 'text-slate-500 hover:text-slate-800'
            }`}
          >
            {lang.label}
          </button>
        ))}
      </div>
    );
  }

  return (
    <div
      className={`inline-flex items-center p-0.5 rounded-xl bg-slate-100/90 border border-slate-200/80 text-xs font-mono font-bold ${className}`}
      role="group"
      aria-label="Language selector"
    >
      {languages.map(lang => (
        <button
          key={lang.code}
          type="button"
          onClick={() => setLanguage(lang.code)}
          className={`px-2.5 py-1 rounded-lg transition-all text-xs flex items-center gap-1 ${
            language === lang.code
              ? 'bg-blue-600 text-white shadow-xs'
              : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200/60'
          }`}
        >
          <span>{lang.label}</span>
        </button>
      ))}
    </div>
  );
}
