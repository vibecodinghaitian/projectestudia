import React from 'react';
import { useLanguage } from '../../../context/LanguageContext';
import { 
  BookOpenCheck, 
  Timer, 
  FileCheck2, 
  TrendingUp,
  Sparkles,
  ShieldCheck,
  Stethoscope,
  BrainCircuit
} from 'lucide-react';

export function ValuePropsSection() {
  const { t } = useLanguage();

  const features = [
    {
      id: 'qb',
      icon: <BookOpenCheck className="w-6 h-6 text-blue-600" />,
      title: t.valueProps.feat1Title,
      description: t.valueProps.feat1Desc,
      tag: 'Especialidades',
    },
    {
      id: 'sim',
      icon: <Timer className="w-6 h-6 text-indigo-600" />,
      title: t.valueProps.feat2Title,
      description: t.valueProps.feat2Desc,
      tag: 'Cronometrado',
    },
    {
      id: 'corr',
      icon: <FileCheck2 className="w-6 h-6 text-emerald-600" />,
      title: t.valueProps.feat3Title,
      description: t.valueProps.feat3Desc,
      tag: 'Gabarito Oficial',
    },
    {
      id: 'prog',
      icon: <TrendingUp className="w-6 h-6 text-amber-600" />,
      title: t.valueProps.feat4Title,
      description: t.valueProps.feat4Desc,
      tag: 'Diagnóstico',
    },
  ];

  return (
    <section id="features" className="py-16 lg:py-24 bg-white border-y border-slate-200/80">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto space-y-3 mb-14">
          <div className="inline-flex items-center gap-2 px-3 py-1 bg-blue-50 text-blue-700 text-xs font-mono font-bold rounded-full">
            <BrainCircuit className="w-3.5 h-3.5" />
            <span>ESTRUTURA DE APRENDIZADO</span>
          </div>
          <h2 className="font-editorial text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight">
            {t.valueProps.sectionTitle}
          </h2>
          <p className="text-sm sm:text-base text-slate-500 leading-relaxed">
            {t.valueProps.sectionSubtitle}
          </p>
        </div>

        {/* 4 Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {features.map((feat) => (
            <div
              key={feat.id}
              className="bg-slate-50/80 border border-slate-200/90 rounded-3xl p-6 sm:p-7 space-y-4 hover:bg-white hover:border-blue-300 hover:shadow-md transition-all group"
            >
              <div className="w-12 h-12 rounded-2xl bg-white border border-slate-200/80 flex items-center justify-center shadow-2xs group-hover:scale-105 transition-transform">
                {feat.icon}
              </div>

              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <h3 className="font-editorial text-lg font-bold text-slate-900 group-hover:text-blue-600 transition-colors">
                    {feat.title}
                  </h3>
                </div>
                <p className="text-xs sm:text-sm text-slate-600 leading-relaxed font-normal">
                  {feat.description}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
