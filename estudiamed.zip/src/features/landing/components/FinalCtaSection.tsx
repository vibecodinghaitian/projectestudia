import React from 'react';
import { useLanguage } from '../../../context/LanguageContext';
import { ArrowRight, Sparkles, Stethoscope, ShieldCheck } from 'lucide-react';

interface FinalCtaSectionProps {
  onNavigate: (path: string) => void;
}

export function FinalCtaSection({ onNavigate }: FinalCtaSectionProps) {
  const { t } = useLanguage();

  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section className="py-20 lg:py-28 bg-gradient-to-b from-white to-slate-100 border-t border-slate-200/80 relative overflow-hidden">
      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 text-center space-y-6 relative">
        
        <div className="inline-flex items-center gap-2 px-3 py-1 bg-blue-100 text-blue-800 text-xs font-mono font-bold rounded-full">
          <Stethoscope className="w-3.5 h-3.5" />
          <span>ESTUDIAMED PREPARATION</span>
        </div>

        <h2 className="font-editorial text-3xl sm:text-5xl font-extrabold text-slate-900 tracking-tight leading-tight">
          {t.finalCta.headline}
        </h2>

        <p className="text-sm sm:text-base text-slate-600 max-w-2xl mx-auto leading-relaxed font-normal">
          {t.finalCta.supporting}
        </p>

        <div className="flex flex-col sm:flex-row items-center justify-center gap-3 pt-4">
          <button
            onClick={() => onNavigate('/register')}
            className="w-full sm:w-auto px-8 py-4 rounded-2xl text-sm font-bold text-white bg-blue-600 hover:bg-blue-700 transition-all flex items-center justify-center gap-2 shadow-lg shadow-blue-600/25 hover:scale-[1.01] active:scale-[0.99] cursor-pointer"
          >
            <span>{t.finalCta.primaryBtn}</span>
            <ArrowRight className="w-4 h-4" />
          </button>

          <button
            onClick={() => scrollToSection('pricing')}
            className="w-full sm:w-auto px-7 py-4 rounded-2xl text-sm font-semibold text-slate-700 bg-white hover:bg-slate-50 border border-slate-300 transition-colors flex items-center justify-center gap-2 shadow-2xs cursor-pointer"
          >
            <span>{t.finalCta.secondaryBtn}</span>
          </button>
        </div>
      </div>
    </section>
  );
}
