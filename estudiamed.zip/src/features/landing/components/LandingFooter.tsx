import React from 'react';
import { useLanguage } from '../../../context/LanguageContext';
import { LanguageSelector } from './LanguageSelector';

interface LandingFooterProps {
  onNavigate: (path: string) => void;
}

export function LandingFooter({ onNavigate }: LandingFooterProps) {
  const { t } = useLanguage();

  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <footer className="bg-slate-900 text-white pt-16 pb-12 border-t border-slate-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12">
        
        {/* Top 4-Column Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-10">
          
          {/* Brand & Description Column */}
          <div className="lg:col-span-2 space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-xl bg-blue-600 flex items-center justify-center text-white text-xs font-bold font-editorial">
                E
              </div>
              <span className="font-editorial text-xl font-bold tracking-tight text-white">
                ESTUDIAMED
              </span>
            </div>
            <p className="text-xs text-slate-400 leading-relaxed max-w-sm font-normal">
              {t.footer.tagline}
            </p>

            <div className="pt-2">
              <span className="text-3xs font-mono uppercase tracking-wider text-slate-400 block mb-2 font-bold">
                {t.footer.language}
              </span>
              <LanguageSelector variant="footer" />
            </div>
          </div>

          {/* Column 2: Examinations */}
          <div className="space-y-3">
            <h4 className="text-xs font-mono font-bold uppercase tracking-widest text-slate-300">
              {t.footer.examsGroup}
            </h4>
            <ul className="space-y-2 text-xs text-slate-400 font-sans">
              <li>
                <button
                  onClick={() => scrollToSection('exams')}
                  className="hover:text-white transition-colors text-left flex items-center gap-1.5"
                >
                  <span>REVALIDA (Brasil)</span>
                  <span className="px-1 py-0.2 rounded bg-emerald-500/20 text-emerald-300 text-3xs font-mono">Ativo</span>
                </button>
              </li>
              <li>
                <span className="text-slate-400 flex items-center gap-1.5">
                  <span>MIR (Espanha)</span>
                  <span className="text-3xs font-mono text-slate-400">Em Breve</span>
                </span>
              </li>
              <li>
                <span className="text-slate-400 flex items-center gap-1.5">
                  <span>ENARM (México)</span>
                  <span className="text-3xs font-mono text-slate-400">Em Breve</span>
                </span>
              </li>
              <li>
                <span className="text-slate-400 flex items-center gap-1.5">
                  <span>USMLE (EUA)</span>
                  <span className="text-3xs font-mono text-slate-400">Em Breve</span>
                </span>
              </li>
              <li>
                <span className="text-slate-400 flex items-center gap-1.5">
                  <span>PLAB (Reino Unido)</span>
                  <span className="text-3xs font-mono text-slate-400">Em Breve</span>
                </span>
              </li>
            </ul>
          </div>

          {/* Column 3: Platform */}
          <div className="space-y-3">
            <h4 className="text-xs font-mono font-bold uppercase tracking-widest text-slate-300">
              {t.footer.productGroup}
            </h4>
            <ul className="space-y-2 text-xs text-slate-400">
              <li>
                <button onClick={() => scrollToSection('features')} className="hover:text-white transition-colors">
                  {t.nav.features}
                </button>
              </li>
              <li>
                <button onClick={() => scrollToSection('pricing')} className="hover:text-white transition-colors">
                  {t.nav.pricing}
                </button>
              </li>
              <li>
                <button onClick={() => scrollToSection('faq')} className="hover:text-white transition-colors">
                  {t.nav.faq}
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('/login')} className="hover:text-white transition-colors">
                  {t.nav.login}
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('/register')} className="hover:text-white transition-colors">
                  {t.nav.getStarted}
                </button>
              </li>
            </ul>
          </div>

          {/* Column 4: Legal & Policies */}
          <div className="space-y-3">
            <h4 className="text-xs font-mono font-bold uppercase tracking-widest text-slate-300">
              {t.footer.legalGroup}
            </h4>
            <ul className="space-y-2 text-xs text-slate-400">
              <li>
                <span className="text-slate-400 hover:text-slate-300 transition-colors cursor-pointer">
                  {t.footer.terms}
                </span>
              </li>
              <li>
                <span className="text-slate-400 hover:text-slate-300 transition-colors cursor-pointer">
                  {t.footer.privacy}
                </span>
              </li>
              <li>
                <span className="text-slate-400 hover:text-slate-300 transition-colors cursor-pointer">
                  {t.footer.refunds}
                </span>
              </li>
            </ul>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="pt-8 border-t border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-4 text-3xs font-mono text-slate-400">
          <p>{t.footer.copyright}</p>
          <div className="flex items-center gap-4">
            <span>Stripe Security Standard</span>
            <span>•</span>
            <span>Multimodal Gemini OCR</span>
            <span>•</span>
            <span>Multi-Exam Medical Architecture</span>
          </div>
        </div>
      </div>
    </footer>
  );
}
