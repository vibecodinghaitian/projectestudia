import React from 'react';
import { useLanguage } from '../../../context/LanguageContext';
import { StudyVisualMockup } from './StudyVisualMockup';
import { ArrowRight, Sparkles, CheckCircle, Shield, BookOpen, Layers } from 'lucide-react';

interface HeroSectionProps {
  onNavigate: (path: string) => void;
}

export function HeroSection({ onNavigate }: HeroSectionProps) {
  const { t } = useLanguage();

  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section id="top" className="relative pt-8 pb-16 lg:pt-14 lg:pb-24 overflow-hidden">
      {/* Medical Blue Subtle Grid Background */}
      <div className="absolute inset-0 bg-[linear-gradient(to_right,#e2e8f015_1px,transparent_1px),linear-gradient(to_bottom,#e2e8f015_1px,transparent_1px)] bg-[size:4rem_4rem] [mask-image:radial-gradient(ellipse_60%_50%_at_50%_0%,#000_70%,transparent_100%)] pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
        
        {/* Top Badges Matrix */}
        <div className="flex flex-wrap items-center justify-center gap-2.5 mb-6 animate-in fade-in duration-300">
          
          {/* Active Exam Badge */}
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs font-mono font-bold shadow-2xs">
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-ping" />
            <span>REVALIDA 🇧🇷</span>
            <span className="px-1.5 py-0.2 rounded bg-emerald-200 text-emerald-900 text-3xs uppercase">
              {t.hero.badgeAvailable}
            </span>
          </div>

          {/* Future Exams Badges */}
          <div className="hidden sm:inline-flex items-center gap-2 px-3 py-1 rounded-full bg-slate-100 border border-slate-200 text-slate-600 text-xs font-mono font-medium">
            <span>MIR 🇪🇸</span>
            <span>•</span>
            <span>ENARM 🇲🇽</span>
            <span>•</span>
            <span>USMLE 🇺🇸</span>
            <span className="px-1.5 py-0.2 rounded bg-slate-200 text-slate-700 text-3xs font-semibold uppercase">
              {t.hero.badgeComingSoon}
            </span>
          </div>

          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-blue-50 border border-blue-200 text-blue-800 text-xs font-mono font-semibold">
            <Sparkles className="w-3.5 h-3.5 text-blue-600" />
            <span>{t.hero.badgeAiPowered}</span>
          </div>
        </div>

        {/* Hero Title & Subtext */}
        <div className="text-center max-w-4xl mx-auto space-y-5">
          <h1 className="font-editorial text-4xl sm:text-5xl lg:text-6xl font-extrabold tracking-tight text-slate-900 leading-[1.1]">
            {t.hero.headline}
          </h1>
          <p className="text-base sm:text-lg text-slate-600 max-w-2xl mx-auto leading-relaxed font-normal">
            {t.hero.supportingText}
          </p>

          {/* Action CTAs */}
          <div className="flex flex-col sm:flex-row items-center justify-center gap-3 pt-2">
            <button
              onClick={() => onNavigate('/register')}
              className="w-full sm:w-auto px-7 py-3.5 rounded-2xl text-sm font-bold text-white bg-blue-600 hover:bg-blue-700 transition-all flex items-center justify-center gap-2 shadow-md shadow-blue-500/20 hover:scale-[1.01] active:scale-[0.99] cursor-pointer"
            >
              <span>{t.hero.ctaPrimary}</span>
              <ArrowRight className="w-4 h-4" />
            </button>

            <button
              onClick={() => scrollToSection('exams')}
              className="w-full sm:w-auto px-6 py-3.5 rounded-2xl text-sm font-semibold text-slate-700 bg-white hover:bg-slate-50 border border-slate-300 transition-colors flex items-center justify-center gap-2 shadow-2xs cursor-pointer"
            >
              <span>{t.hero.ctaSecondary}</span>
            </button>
          </div>
        </div>

        {/* Hero Study Mockup Visual */}
        <div className="mt-12 lg:mt-16">
          <StudyVisualMockup />
        </div>
      </div>
    </section>
  );
}
