import React, { useState } from 'react';
import { useLanguage } from '../../../context/LanguageContext';
import { useAuth } from '../../../context/AuthContext';
import { PlanId, PricingPlan, PromoValidationResult } from '../../../types';
import { subscriptionService } from '../../../services/subscriptionService';
import { 
  X, 
  Check, 
  Sparkles, 
  ShieldCheck, 
  Lock, 
  ArrowRight, 
  CreditCard,
  AlertCircle,
  Tag
} from 'lucide-react';

interface CheckoutModalProps {
  isOpen: boolean;
  onClose: () => void;
  plan: PricingPlan | null;
  initialPromoCode?: string;
  onNavigate: (path: string) => void;
}

export function CheckoutModal({
  isOpen,
  onClose,
  plan,
  initialPromoCode = '',
  onNavigate,
}: CheckoutModalProps) {
  const { t, language } = useLanguage();
  const { user, isAuthenticated } = useAuth();

  const [email, setEmail] = useState(user?.email || '');
  const [promoCodeInput, setPromoCodeInput] = useState(initialPromoCode || '');
  const [validationResult, setValidationResult] = useState<PromoValidationResult | null>(null);
  const [validating, setValidating] = useState(false);
  const [checkingOut, setCheckingOut] = useState(false);
  const [checkoutError, setCheckoutError] = useState<string | null>(null);

  if (!isOpen || !plan) return null;

  const handleValidatePromo = async () => {
    if (!promoCodeInput.trim()) return;
    setValidating(true);
    setCheckoutError(null);
    try {
      const result = await subscriptionService.validatePromoCode(promoCodeInput.trim(), plan.id);
      setValidationResult(result);
      if (!result.valid) {
        setCheckoutError(result.message || 'Código promocional inválido.');
      }
    } catch (err: any) {
      setCheckoutError('Erro ao validar código promocional.');
    } finally {
      setValidating(false);
    }
  };

  const handleStartCheckout = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email && !isAuthenticated) {
      setCheckoutError('Por favor insira seu e-mail para continuar.');
      return;
    }

    setCheckingOut(true);
    setCheckoutError(null);

    try {
      const session = await subscriptionService.createCheckoutSession({
        planId: plan.id,
        email: email || user?.email,
        userId: user?.uid || `guest_${Date.now()}`,
        promoCode: validationResult?.valid ? promoCodeInput.trim() : undefined,
        successUrl: '/dashboard',
        cancelUrl: '/pricing',
      });

      if (session.checkoutUrl) {
        // In this environment, navigate smoothly to destination
        if (session.checkoutUrl.startsWith('http')) {
          window.location.href = session.checkoutUrl;
        } else {
          onClose();
          onNavigate(session.checkoutUrl);
        }
      } else {
        onClose();
        onNavigate('/dashboard');
      }
    } catch (err: any) {
      console.error('Checkout error:', err);
      setCheckoutError(err.message || 'Falha ao iniciar checkout Stripe.');
    } finally {
      setCheckingOut(false);
    }
  };

  const isFirstMonthFree = validationResult?.discountSummary?.firstMonthFree;
  const firstMonthAmount = validationResult?.discountSummary?.finalPriceFirstMonth ?? plan.priceMonthlyUSD;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in duration-200">
      <div className="bg-white border border-slate-200 rounded-3xl max-w-lg w-full overflow-hidden shadow-2xl animate-in zoom-in-95 duration-200">
        
        {/* Header */}
        <div className="px-6 py-5 border-b border-slate-100 bg-slate-50/90 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-blue-600 flex items-center justify-center text-white text-xs font-bold font-editorial">
              E
            </div>
            <div>
              <h3 className="font-editorial text-lg font-bold text-slate-900 leading-none">
                {t.pricing.checkoutModalTitle}
              </h3>
              <p className="text-3xs font-mono text-slate-500 mt-0.5">
                Stripe Subscriptions • USD
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-xl text-slate-400 hover:text-slate-700 hover:bg-slate-200/60 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Modal Form */}
        <form onSubmit={handleStartCheckout} className="p-6 space-y-5">
          
          {/* Plan Summary Box */}
          <div className="p-4 rounded-2xl bg-blue-50/70 border border-blue-100 flex items-center justify-between">
            <div>
              <span className="text-3xs font-mono font-bold text-blue-700 uppercase tracking-wider">
                {t.pricing.planSummary}
              </span>
              <h4 className="font-editorial text-xl font-bold text-slate-900 mt-0.5">
                Plano {plan.name}
              </h4>
              <p className="text-3xs font-mono text-slate-600">
                {typeof plan.questionLimit === 'number'
                  ? `Até ${plan.questionLimit.toLocaleString()} questões`
                  : 'Questões Ilimitadas'}
              </p>
            </div>

            <div className="text-right">
              {isFirstMonthFree ? (
                <div>
                  <span className="text-xs text-slate-400 line-through mr-1 font-mono">
                    ${plan.priceMonthlyUSD.toFixed(2)}
                  </span>
                  <span className="font-editorial text-2xl font-extrabold text-emerald-700">
                    $0.00
                  </span>
                  <span className="block text-3xs font-mono text-emerald-800 font-bold">
                    1º Mês Grátis
                  </span>
                </div>
              ) : (
                <div>
                  <span className="font-editorial text-2xl font-extrabold text-slate-900">
                    ${firstMonthAmount.toFixed(2)}
                  </span>
                  <span className="text-3xs font-mono text-slate-500 block">
                    {t.pricing.perMonth}
                  </span>
                </div>
              )}
            </div>
          </div>

          {/* Email input if not logged in */}
          {!isAuthenticated && (
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                E-mail para Acesso
              </label>
              <input
                type="email"
                required
                value={email}
                onChange={e => setEmail(e.target.value)}
                placeholder="seu.email@medicina.com"
                className="w-full px-3.5 py-2 text-xs border border-slate-300 rounded-xl focus:outline-none focus:border-blue-600 font-sans"
              />
            </div>
          )}

          {/* Promo code input & validation */}
          <div className="space-y-1.5">
            <label className="block text-xs font-semibold text-slate-700">
              {t.pricing.promoCodeLabel}
            </label>
            <div className="flex items-center gap-2">
              <div className="relative flex-1">
                <Tag className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  value={promoCodeInput}
                  onChange={e => setPromoCodeInput(e.target.value.toUpperCase())}
                  placeholder={t.pricing.promoPlaceholder}
                  className="w-full pl-8 pr-3 py-2 text-xs uppercase font-mono font-bold border border-slate-300 rounded-xl focus:outline-none focus:border-blue-600"
                />
              </div>

              <button
                type="button"
                onClick={handleValidatePromo}
                disabled={validating || !promoCodeInput.trim()}
                className="px-4 py-2 text-xs font-bold text-slate-800 bg-slate-100 hover:bg-slate-200 border border-slate-200 rounded-xl transition-colors shrink-0 disabled:opacity-50"
              >
                {validating ? '...' : t.pricing.applyPromo}
              </button>
            </div>

            {/* Quick 1-click REVALIDA2026 suggestion button */}
            {!validationResult?.valid && (
              <div className="flex items-center gap-1 text-3xs font-mono text-slate-500 pt-0.5">
                <span>Dica: use</span>
                <button
                  type="button"
                  onClick={() => {
                    setPromoCodeInput('REVALIDA2026');
                    subscriptionService.validatePromoCode('REVALIDA2026', plan.id).then(setValidationResult);
                  }}
                  className="font-bold text-blue-600 hover:underline cursor-pointer"
                >
                  REVALIDA2026
                </button>
                <span>para 1º mês 100% grátis.</span>
              </div>
            )}

            {/* Promo Result Feedback */}
            {validationResult?.valid && (
              <div className="p-2.5 rounded-xl bg-emerald-50 border border-emerald-200 text-3xs font-mono text-emerald-800 flex items-center gap-2">
                <Check className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                <span>
                  <strong>{promoCodeInput}:</strong> {validationResult.discountSummary?.displayPromoText}
                </span>
              </div>
            )}

            {checkoutError && (
              <div className="p-2.5 rounded-xl bg-rose-50 border border-rose-200 text-3xs font-mono text-rose-800 flex items-center gap-2">
                <AlertCircle className="w-3.5 h-3.5 text-rose-600 shrink-0" />
                <span>{checkoutError}</span>
              </div>
            )}
          </div>

          {/* Pricing Disclaimer */}
          <div className="p-3 rounded-2xl bg-slate-50 border border-slate-200/80 text-3xs text-slate-500 space-y-1 font-mono">
            <div className="flex items-center gap-1.5 text-slate-700 font-bold">
              <Lock className="w-3 h-3 text-slate-400" />
              <span>{t.pricing.secureNotice}</span>
            </div>
            <p>{t.pricing.cancelNotice}</p>
          </div>

          {/* Submit Checkout Button */}
          <button
            type="submit"
            disabled={checkingOut}
            className="w-full py-3.5 rounded-2xl text-xs font-bold text-white bg-blue-600 hover:bg-blue-700 transition-all flex items-center justify-center gap-2 shadow-md shadow-blue-500/20 disabled:opacity-60 cursor-pointer"
          >
            <CreditCard className="w-4 h-4" />
            <span>
              {checkingOut
                ? 'Conectando ao Stripe...'
                : isFirstMonthFree
                ? t.pricing.freeTrialCta
                : t.pricing.proceedToStripe}
            </span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </form>
      </div>
    </div>
  );
}
