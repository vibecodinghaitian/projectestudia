import React from 'react';
import { useLanguage } from '../../../context/LanguageContext';
import { Layers, CheckCircle2, TrendingUp, Compass } from 'lucide-react';

export function HowItWorksSection() {
  const { t } = useLanguage();

  const steps = [
    {
      num: '01',
      icon: <Compass className="w-6 h-6 text-blue-600" />,
      title: t.howItWorks.step1Title,
      description: t.howItWorks.step1Desc,
    },
    {
      num: '02',
      icon: <Layers className="w-6 h-6 text-indigo-600" />,
      title: t.howItWorks.step2Title,
      description: t.howItWorks.step2Desc,
    },
    {
      num: '03',
      icon: <TrendingUp className="w-6 h-6 text-emerald-600" />,
      title: t.howItWorks.step3Title,
      description: t.howItWorks.step3Desc,
    },
  ];

  return (
    <section className="py-16 lg:py-24 bg-white border-b border-slate-200/80">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto space-y-3 mb-14">
          <div className="inline-flex items-center gap-2 px-3 py-1 bg-slate-100 text-slate-700 text-xs font-mono font-bold rounded-full">
            <span>FLUXO DE ESTUDO</span>
          </div>
          <h2 className="font-editorial text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight">
            {t.howItWorks.sectionTitle}
          </h2>
          <p className="text-sm sm:text-base text-slate-500 leading-relaxed">
            {t.howItWorks.sectionSubtitle}
          </p>
        </div>

        {/* Steps Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 relative">
          {steps.map((step, idx) => (
            <div
              key={step.num}
              className="relative bg-slate-50/70 border border-slate-200/80 rounded-3xl p-7 space-y-4 hover:border-slate-300 transition-colors"
            >
              <div className="flex items-center justify-between">
                <div className="w-12 h-12 rounded-2xl bg-white border border-slate-200/80 flex items-center justify-center shadow-2xs">
                  {step.icon}
                </div>
                <span className="text-2xl font-editorial font-bold text-slate-300">
                  {step.num}
                </span>
              </div>

              <div className="space-y-2">
                <h3 className="font-editorial text-lg font-bold text-slate-900">
                  {step.title}
                </h3>
                <p className="text-xs sm:text-sm text-slate-600 leading-relaxed font-normal">
                  {step.description}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
