import React from 'react';
import { useLanguage } from '../../../context/LanguageContext';
import { Badge } from '../../../components/common/Badge';
import { ArrowRight, Lock, CheckCircle2, Globe2, Sparkles, BookOpen } from 'lucide-react';

interface ExamCatalogSectionProps {
  onNavigate: (path: string) => void;
}

export function ExamCatalogSection({ onNavigate }: ExamCatalogSectionProps) {
  const { t } = useLanguage();

  const examCards = [
    {
      id: 'revalida-br',
      code: 'REVALIDA',
      title: t.exams.revalidaTitle,
      country: t.exams.revalidaCountry,
      flag: '🇧🇷',
      description: t.exams.revalidaDesc,
      status: 'active',
      badgeText: t.exams.availableNow,
      ctaText: t.exams.revalidaCta,
      stats: '1.200+ Questões • 5 Grandes Áreas',
      editions: '2020 — 2024.2',
    },
    {
      id: 'mir-es',
      code: 'MIR',
      title: t.exams.mirTitle,
      country: t.exams.mirCountry,
      flag: '🇪🇸',
      description: t.exams.mirDesc,
      status: 'coming_soon',
      badgeText: t.exams.comingSoon,
      ctaText: t.exams.comingSoon,
      stats: 'Em Ingestão Multimodal',
      editions: 'Edição 2024 / 2025',
    },
    {
      id: 'enarm-mx',
      code: 'ENARM',
      title: t.exams.enarmTitle,
      country: t.exams.enarmCountry,
      flag: '🇲🇽',
      description: t.exams.enarmDesc,
      status: 'coming_soon',
      badgeText: t.exams.comingSoon,
      ctaText: t.exams.comingSoon,
      stats: 'Em Estruturação',
      editions: 'Edição XLVIII',
    },
    {
      id: 'usmle-us',
      code: 'USMLE',
      title: t.exams.usmleTitle,
      country: t.exams.usmleCountry,
      flag: '🇺🇸',
      description: t.exams.usmleDesc,
      status: 'coming_soon',
      badgeText: t.exams.comingSoon,
      ctaText: t.exams.comingSoon,
      stats: 'Step 1 & Step 2 CK',
      editions: 'Clinical Vignettes',
    },
    {
      id: 'plab-uk',
      code: 'PLAB / UKMLA',
      title: t.exams.plabTitle,
      country: t.exams.plabCountry,
      flag: '🇬🇧',
      description: t.exams.plabDesc,
      status: 'coming_soon',
      badgeText: t.exams.comingSoon,
      ctaText: t.exams.comingSoon,
      stats: 'GMC Assessment',
      editions: 'Part 1 Applied Knowledge',
    },
  ];

  return (
    <section id="exams" className="py-16 lg:py-24 bg-slate-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto space-y-3 mb-14">
          <div className="inline-flex items-center gap-2 px-3 py-1 bg-blue-100 text-blue-800 text-xs font-mono font-bold rounded-full">
            <Globe2 className="w-3.5 h-3.5" />
            <span>CATÁLOGO MULTI-EXAME</span>
          </div>
          <h2 className="font-editorial text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight">
            {t.exams.sectionTitle}
          </h2>
          <p className="text-sm sm:text-base text-slate-500 leading-relaxed">
            {t.exams.sectionSubtitle}
          </p>
        </div>

        {/* Exams Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {examCards.map((exam) => {
            const isActive = exam.status === 'active';

            return (
              <div
                key={exam.id}
                className={`rounded-3xl p-7 border transition-all flex flex-col justify-between ${
                  isActive
                    ? 'bg-white border-blue-200 shadow-md ring-1 ring-blue-500/10 hover:border-blue-400'
                    : 'bg-slate-100/70 border-slate-200/90 opacity-80'
                }`}
              >
                <div className="space-y-4">
                  {/* Card Top: Flag + Badges */}
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2.5">
                      <span className="text-2xl" role="img" aria-label={exam.country}>
                        {exam.flag}
                      </span>
                      <div>
                        <h3 className="font-editorial text-xl font-bold text-slate-900 leading-tight">
                          {exam.code}
                        </h3>
                        <p className="text-3xs font-mono text-slate-500">{exam.country}</p>
                      </div>
                    </div>

                    <span
                      className={`px-2.5 py-1 rounded-full text-3xs font-mono font-bold uppercase tracking-wider ${
                        isActive
                          ? 'bg-emerald-100 text-emerald-800'
                          : 'bg-slate-200 text-slate-600'
                      }`}
                    >
                      {exam.badgeText}
                    </span>
                  </div>

                  <p className="text-xs sm:text-sm text-slate-600 leading-relaxed font-normal">
                    {exam.description}
                  </p>

                  <div className="pt-2 border-t border-slate-100/80 space-y-1 text-3xs font-mono text-slate-500">
                    <div>Status: <strong className="text-slate-700">{exam.stats}</strong></div>
                    <div>Edições: <span className="text-slate-600">{exam.editions}</span></div>
                  </div>
                </div>

                {/* Bottom CTA */}
                <div className="pt-6">
                  {isActive ? (
                    <button
                      onClick={() => onNavigate('/register')}
                      className="w-full py-3 rounded-2xl text-xs font-bold text-white bg-blue-600 hover:bg-blue-700 transition-colors flex items-center justify-center gap-2 shadow-xs cursor-pointer"
                    >
                      <span>{exam.ctaText}</span>
                      <ArrowRight className="w-3.5 h-3.5" />
                    </button>
                  ) : (
                    <button
                      disabled
                      className="w-full py-3 rounded-2xl text-xs font-semibold text-slate-400 bg-slate-200/70 cursor-not-allowed flex items-center justify-center gap-2"
                    >
                      <Lock className="w-3.5 h-3.5" />
                      <span>{exam.ctaText}</span>
                    </button>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
