/**
 * ESTUDIAMED - Multi-Exam Medical Preparation Platform
 * Editorial Aesthetic Architecture: Firebase Auth, Firestore, Multi-Exam Schema, RBAC, Gemini Pipeline, Multilingual Landing & Stripe Subscriptions
 */

import React, { useState, useEffect } from 'react';
import { AuthProvider, useAuth } from './context/AuthContext';
import { ExamProvider, useExam } from './context/ExamContext';
import { LanguageProvider } from './context/LanguageContext';
import { Navbar } from './components/common/Navbar';
import { LandingPage } from './features/landing/LandingPage';
import { LoginForm } from './features/auth/LoginForm';
import { RegisterForm } from './features/auth/RegisterForm';
import { StudentDashboard } from './features/dashboard/StudentDashboard';
import { ExamCatalog } from './features/exams/ExamCatalog';
import { ExamDetail } from './features/exams/ExamDetail';
import { AdminOverview } from './features/admin/AdminOverview';
import { AdminExams } from './features/admin/AdminExams';
import { AdminQuestions } from './features/admin/AdminQuestions';
import { AdminImports } from './features/admin/AdminImports';
import { AdminImportDetail } from './features/admin/AdminImportDetail';
import { AdminPromos } from './features/admin/AdminPromos';
import { AdminUsers } from './features/admin/AdminUsers';

function AppContent() {
  const { role, isAdmin } = useAuth();
  const [currentPath, setCurrentPath] = useState<string>(() => {
    return window.location.pathname || '/';
  });

  const navigate = (path: string) => {
    setCurrentPath(path);
    window.history.pushState(null, '', path);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  useEffect(() => {
    const handlePopState = () => {
      setCurrentPath(window.location.pathname || '/');
    };
    window.addEventListener('popstate', handlePopState);
    return () => window.removeEventListener('popstate', handlePopState);
  }, []);

  const isLandingPage = currentPath === '/' || currentPath === '/landing' || currentPath === '/pricing';
  const isLoginPage = currentPath === '/login';

  // Landing page has its own dedicated top bar, hero, and footer
  if (isLandingPage) {
    return <LandingPage onNavigate={navigate} />;
  }

  // Determine active view based on path
  const renderView = () => {
    if (currentPath === '/login') {
      return <LoginForm onNavigate={navigate} />;
    }
    if (currentPath === '/register') {
      return <RegisterForm onNavigate={navigate} />;
    }

    // Exam Detail Route: /exams/:examId
    if (currentPath.startsWith('/exams/')) {
      const examId = currentPath.replace('/exams/', '');
      return <ExamDetail examId={examId} onNavigate={navigate} />;
    }

    if (currentPath === '/exams') {
      return <ExamCatalog onNavigate={navigate} />;
    }

    // Admin Routes
    if (currentPath === '/admin' || currentPath === '/admin/overview') {
      return <AdminOverview onNavigate={navigate} />;
    }
    if (currentPath === '/admin/exams') {
      return <AdminExams />;
    }
    if (currentPath === '/admin/questions') {
      return <AdminQuestions />;
    }
    if (currentPath.startsWith('/admin/imports/')) {
      const importId = currentPath.replace('/admin/imports/', '');
      return <AdminImportDetail importId={importId} onNavigate={navigate} />;
    }
    if (currentPath === '/admin/imports') {
      return <AdminImports onNavigate={navigate} />;
    }
    if (currentPath === '/admin/promos') {
      return <AdminPromos onNavigate={navigate} />;
    }
    if (currentPath === '/admin/users') {
      return <AdminUsers />;
    }

    // Default to student dashboard
    return <StudentDashboard onNavigate={navigate} />;
  };

  return (
    <div
      className={`min-h-screen flex flex-col font-sans antialiased selection:bg-blue-100 selection:text-blue-900 ${
        isLoginPage ? 'bg-[#070A12] text-slate-100' : 'bg-slate-50 text-slate-900'
      }`}
    >
      {/* Top Main Navigation for Authenticated/App sections */}
      <Navbar currentPath={currentPath} onNavigate={navigate} />

      {/* Main Page Canvas */}
      <main
        className={`flex-1 w-full ${
          isLoginPage
            ? 'p-0 flex flex-col'
            : 'max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-10'
        }`}
      >
        {renderView()}
      </main>

      {/* Editorial Aesthetic Footer */}
      <footer
        className={`border-t py-8 text-xs ${
          isLoginPage
            ? 'bg-[#05070D] border-slate-800/80 text-slate-500'
            : 'bg-white border-slate-200 text-slate-500 mt-16'
        }`}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-7 h-7 rounded-lg bg-blue-600 flex items-center justify-center text-white text-xs font-bold font-mono">
              E
            </div>
            <div>
              <span className={`font-extrabold tracking-tight ${isLoginPage ? 'text-slate-200' : 'text-slate-900'}`}>
                ESTUDIAMED
              </span>
              <span className="text-slate-500 text-3xs font-mono ml-2">v1.1.0 • Medical Licensing Platform</span>
            </div>
          </div>

          <div className="flex items-center gap-3 text-3xs font-mono text-slate-500">
            <button onClick={() => navigate('/')} className="hover:text-slate-900 transition-colors">Início</button>
            <span>•</span>
            <span>REVALIDA (Brasil)</span>
            <span>•</span>
            <span>MIR (Espanha)</span>
            <span>•</span>
            <span>ENARM (México)</span>
            <span>•</span>
            <span>USMLE (EUA)</span>
          </div>

          <div className="flex items-center gap-1.5 text-3xs font-mono text-slate-500">
            <span>Powered by Gemini AI & Stripe Subscriptions</span>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default function App() {
  return (
    <LanguageProvider>
      <AuthProvider>
        <ExamProvider>
          <AppContent />
        </ExamProvider>
      </AuthProvider>
    </LanguageProvider>
  );
}
