import React, { useState } from 'react';
import { 
  X, 
  CheckCircle2, 
  XCircle, 
  AlertTriangle, 
  Save, 
  BookOpen, 
  GraduationCap, 
  Layers, 
  FileText,
  AlertOctagon,
  HelpCircle
} from 'lucide-react';
import { Question, QuestionStatus, QuestionDifficulty } from '../../types';

interface QuestionReviewModalProps {
  question: Question;
  isOpen: boolean;
  onClose: () => void;
  onSave: (updated: Question) => Promise<void>;
  onApprove: (questionId: string) => Promise<void>;
  onReject: (questionId: string) => Promise<void>;
}

const SPECIALTY_OPTIONS = [
  { id: 'clinica-medica', name: 'Clínica Médica' },
  { id: 'cirurgia', name: 'Cirurgia Geral' },
  { id: 'pediatria', name: 'Pediatria' },
  { id: 'ginecologia-obstetricia', name: 'Ginecologia e Obstetrícia' },
  { id: 'medicina-preventiva', name: 'Medicina Preventiva e Social' },
  { id: 'urgencia-emergencia', name: 'Urgência e Emergência' },
  { id: 'cardiologia', name: 'Cardiologia' },
  { id: 'pneumologia', name: 'Pneumologia' },
  { id: 'infectologia', name: 'Infectologia' },
  { id: 'neurologia', name: 'Neurologia' },
  { id: 'psiquiatria', name: 'Psiquiatria' },
];

export const QuestionReviewModal: React.FC<QuestionReviewModalProps> = ({
  question,
  isOpen,
  onClose,
  onSave,
  onApprove,
  onReject,
}) => {
  if (!isOpen) return null;

  const [statement, setStatement] = useState(question.statement);
  const [options, setOptions] = useState(question.options || []);
  const [correctAnswer, setCorrectAnswer] = useState(question.correctAnswer || 'A');
  const [specialtyId, setSpecialtyId] = useState(question.specialtyId || 'clinica-medica');
  const [specialtyName, setSpecialtyName] = useState(question.specialtyName || 'Clínica Médica');
  const [difficulty, setDifficulty] = useState<QuestionDifficulty>(question.difficulty || 'medium');
  const [explanation, setExplanation] = useState(question.explanation || '');
  const [status, setStatus] = useState<QuestionStatus>(question.status);
  const [saving, setSaving] = useState(false);

  const handleOptionTextChange = (id: string, text: string) => {
    setOptions(prev => prev.map(opt => opt.id === id ? { ...opt, text } : opt));
  };

  const handleSpecialtyChange = (newSpecId: string) => {
    setSpecialtyId(newSpecId);
    const found = SPECIALTY_OPTIONS.find(s => s.id === newSpecId);
    if (found) setSpecialtyName(found.name);
  };

  const handleSaveOnly = async () => {
    setSaving(true);
    try {
      await onSave({
        ...question,
        statement,
        options,
        correctAnswer,
        specialtyId,
        specialtyName,
        difficulty,
        explanation,
        status,
        updatedAt: new Date().toISOString(),
      });
      onClose();
    } finally {
      setSaving(false);
    }
  };

  const handleApproveAction = async () => {
    setSaving(true);
    try {
      await onSave({
        ...question,
        statement,
        options,
        correctAnswer,
        specialtyId,
        specialtyName,
        difficulty,
        explanation,
        status: 'approved',
        updatedAt: new Date().toISOString(),
      });
      await onApprove(question.id);
      onClose();
    } finally {
      setSaving(false);
    }
  };

  const handleRejectAction = async () => {
    setSaving(true);
    try {
      await onSave({
        ...question,
        statement,
        options,
        correctAnswer,
        specialtyId,
        specialtyName,
        difficulty,
        explanation,
        status: 'rejected',
        updatedAt: new Date().toISOString(),
      });
      await onReject(question.id);
      onClose();
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-950/70 backdrop-blur-sm flex items-center justify-center p-4 sm:p-6">
      <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 w-full max-w-4xl max-h-[92vh] flex flex-col overflow-hidden animate-in fade-in zoom-in-95 duration-200">
        
        {/* Header */}
        <div className="px-6 py-4 border-b border-slate-200 bg-slate-50/80 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-blue-600/10 text-blue-700 flex items-center justify-center font-mono font-bold text-sm">
              #{question.questionNumber || '—'}
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-base font-bold text-slate-900 font-sans">
                  Revisão de Questão Médica
                </h3>
                <span className={`px-2 py-0.5 rounded-full text-3xs font-mono font-semibold uppercase tracking-wider ${
                  status === 'approved'
                    ? 'bg-emerald-100 text-emerald-800'
                    : status === 'rejected'
                    ? 'bg-rose-100 text-rose-800'
                    : 'bg-amber-100 text-amber-800'
                }`}>
                  {status === 'approved' ? 'Aprovada' : status === 'rejected' ? 'Rejeitada' : 'Aguardando Revisão'}
                </span>
              </div>
              <p className="text-xs text-slate-500 font-mono mt-0.5">
                {question.source || question.examId.toUpperCase()} • {question.year || ''} {question.sourcePage ? `• Página ${question.sourcePage}` : ''}
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-200/60 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Scrollable Body */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6">
          
          {/* Possible Duplicate Warning */}
          {question.isPossibleDuplicate && (
            <div className="p-4 rounded-xl bg-amber-50 border border-amber-200 text-amber-900 flex items-start gap-3">
              <AlertTriangle className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
              <div>
                <h4 className="text-xs font-bold uppercase tracking-wider text-amber-800 font-mono">
                  Atenção: Possível Duplicidade Detectada
                </h4>
                <p className="text-xs text-amber-700 mt-1">
                  {question.duplicateReason || 'O enunciado desta questão possui alta similaridade com uma questão já registrada no banco.'}
                </p>
              </div>
            </div>
          )}

          {/* Validation Warnings */}
          {question.validationErrors && question.validationErrors.length > 0 && (
            <div className="p-4 rounded-xl bg-rose-50 border border-rose-200 text-rose-900 flex items-start gap-3">
              <AlertOctagon className="w-5 h-5 text-rose-600 shrink-0 mt-0.5" />
              <div>
                <h4 className="text-xs font-bold uppercase tracking-wider text-rose-800 font-mono">
                  Inconsistências de Estrutura
                </h4>
                <ul className="text-xs text-rose-700 mt-1 list-disc list-inside space-y-0.5">
                  {question.validationErrors.map((err, i) => (
                    <li key={i}>{err}</li>
                  ))}
                </ul>
              </div>
            </div>
          )}

          {/* Clinical Vignette / Statement */}
          <div className="space-y-2">
            <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 font-mono">
              Enunciado / Caso Clínico Oficial
            </label>
            <textarea
              value={statement}
              onChange={e => setStatement(e.target.value)}
              rows={6}
              className="w-full rounded-xl border border-slate-300 bg-white p-3.5 text-sm text-slate-900 focus:border-blue-600 focus:ring-1 focus:ring-blue-600 leading-relaxed transition font-sans"
              placeholder="Digite ou ajuste o enunciado do caso clínico..."
            />
          </div>

          {/* Answer Alternatives */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 font-mono">
                Alternativas & Gabarito Oficial
              </label>
              <span className="text-3xs text-slate-500 font-mono">
                Selecione o botão da letra correspondente ao Gabarito Oficial
              </span>
            </div>

            <div className="space-y-2.5">
              {options.map((opt) => {
                const isCorrect = correctAnswer === opt.id;
                return (
                  <div
                    key={opt.id}
                    className={`flex items-start gap-3 p-3 rounded-xl border transition-all ${
                      isCorrect
                        ? 'border-emerald-500 bg-emerald-50/50 shadow-sm'
                        : 'border-slate-200 bg-white hover:border-slate-300'
                    }`}
                  >
                    <button
                      type="button"
                      onClick={() => setCorrectAnswer(opt.id)}
                      className={`w-8 h-8 rounded-lg font-mono font-bold text-xs flex items-center justify-center shrink-0 transition-colors ${
                        isCorrect
                          ? 'bg-emerald-600 text-white shadow-sm'
                          : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                      }`}
                      title="Clique para marcar esta alternativa como o Gabarito Oficial"
                    >
                      {opt.id}
                    </button>

                    <textarea
                      value={opt.text}
                      onChange={e => handleOptionTextChange(opt.id, e.target.value)}
                      rows={2}
                      className={`flex-1 rounded-lg border p-2 text-xs text-slate-900 focus:outline-none transition leading-relaxed ${
                        isCorrect
                          ? 'border-emerald-300 bg-white focus:border-emerald-600'
                          : 'border-slate-200 bg-slate-50/60 focus:border-blue-500 focus:bg-white'
                      }`}
                      placeholder={`Texto da alternativa ${opt.id}...`}
                    />

                    {isCorrect && (
                      <span className="inline-flex items-center gap-1 text-3xs font-mono font-bold text-emerald-700 uppercase bg-emerald-100 px-2 py-1 rounded-md shrink-0 self-center">
                        <CheckCircle2 className="w-3 h-3" /> Gabarito
                      </span>
                    )}
                  </div>
                );
              })}
            </div>
          </div>

          {/* Categorization & Metadata Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 p-4 bg-slate-50 rounded-xl border border-slate-200">
            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 font-mono mb-1.5">
                Especialidade Médica
              </label>
              <select
                value={specialtyId}
                onChange={e => handleSpecialtyChange(e.target.value)}
                className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-xs text-slate-800 focus:border-blue-600 focus:ring-1 focus:ring-blue-600 font-sans"
              >
                {SPECIALTY_OPTIONS.map(spec => (
                  <option key={spec.id} value={spec.id}>
                    {spec.name}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 font-mono mb-1.5">
                Nível de Dificuldade Estimado
              </label>
              <select
                value={difficulty}
                onChange={e => setDifficulty(e.target.value as QuestionDifficulty)}
                className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-xs text-slate-800 focus:border-blue-600 focus:ring-1 focus:ring-blue-600 font-sans"
              >
                <option value="easy">Fácil (Conceitos Essenciais)</option>
                <option value="medium">Média (Casos Clínicos Padrão)</option>
                <option value="hard">Difícil (Condutas de Alta Complexidade)</option>
              </select>
            </div>
          </div>

          {/* Medical Explanation / Justification */}
          <div className="space-y-2">
            <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 font-mono">
              Comentário / Justificativa Médica Oficial
            </label>
            <textarea
              value={explanation}
              onChange={e => setExplanation(e.target.value)}
              rows={4}
              className="w-full rounded-xl border border-slate-300 bg-white p-3 text-xs text-slate-900 focus:border-blue-600 focus:ring-1 focus:ring-blue-600 leading-relaxed font-sans"
              placeholder="Explicação comentada, referências de diretrizes (MS/FEBRASGO/SBC) e raciocínio clínico..."
            />
          </div>

        </div>

        {/* Footer Actions */}
        <div className="px-6 py-4 border-t border-slate-200 bg-slate-50 flex flex-col sm:flex-row items-center justify-between gap-3">
          <button
            type="button"
            onClick={onClose}
            className="w-full sm:w-auto px-4 py-2 rounded-xl text-xs font-semibold text-slate-600 hover:bg-slate-200/70 transition"
          >
            Fechar sem Salvar
          </button>

          <div className="w-full sm:w-auto flex items-center gap-2 justify-end">
            <button
              type="button"
              disabled={saving}
              onClick={handleRejectAction}
              className="px-3.5 py-2 rounded-xl text-xs font-semibold text-rose-700 bg-rose-100 hover:bg-rose-200 transition flex items-center gap-1.5"
            >
              <XCircle className="w-4 h-4" />
              Rejeitar Questão
            </button>

            <button
              type="button"
              disabled={saving}
              onClick={handleSaveOnly}
              className="px-3.5 py-2 rounded-xl text-xs font-semibold text-slate-700 bg-white border border-slate-300 hover:bg-slate-100 transition flex items-center gap-1.5 shadow-sm"
            >
              <Save className="w-4 h-4" />
              Salvar Alterações
            </button>

            <button
              type="button"
              disabled={saving}
              onClick={handleApproveAction}
              className="px-4 py-2 rounded-xl text-xs font-bold text-white bg-blue-600 hover:bg-blue-700 transition flex items-center gap-1.5 shadow-sm"
            >
              <CheckCircle2 className="w-4 h-4" />
              Aprovar Questão (Visível p/ Alunos)
            </button>
          </div>
        </div>

      </div>
    </div>
  );
};
