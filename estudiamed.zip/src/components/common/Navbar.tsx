import React from 'react';
import { useAuth } from '../../context/AuthContext';
import { ExamSelector } from './ExamSelector';
import { Badge } from './Badge';
import { Button } from './Button';
import { 
  Stethoscope, 
  ShieldCheck, 
  User, 
  LogOut, 
  LogIn
} from 'lucide-react';

interface NavbarProps {
  currentPath: string;
  onNavigate: (path: string) => void;
}

export function Navbar({ currentPath, onNavigate }: NavbarProps) {
  const { user, profile, role, logout, simulateRole } = useAuth();
  const [showRoleMenu, setShowRoleMenu] = React.useState(false);

  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-slate-200 shadow-2xs">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 sm:h-20 gap-4">
          {/* Logo & Platform Name */}
          <div className="flex items-center gap-6">
            <button
              id="brand-logo"
              onClick={() => onNavigate(role === 'admin' ? '/admin' : '/dashboard')}
              className="flex items-center gap-3 text-left cursor-pointer group"
            >
              <div className="w-9 h-9 rounded-xl bg-blue-600 flex items-center justify-center font-bold text-white shadow-sm group-hover:scale-105 transition-transform">
                E
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <span className="text-xl font-extrabold tracking-tighter text-slate-900">
                    ESTUDIAMED
                  </span>
                  <span className="text-3xs uppercase font-bold tracking-widest px-2 py-0.5 bg-blue-100 text-blue-800 rounded-full font-mono">
                    EDITION 2026
                  </span>
                </div>
                <p className="text-2xs text-slate-400 font-mono hidden sm:block">Plataforma de Exames Médicos</p>
              </div>
            </button>

            {/* Exam Selector in Navbar */}
            <div className="hidden md:block">
              <ExamSelector />
            </div>
          </div>

          {/* Navigation Links for Desktop */}
          <nav className="hidden lg:flex items-center gap-1.5 bg-slate-100/80 p-1 rounded-2xl border border-slate-200/80">
            {role === 'student' ? (
              <>
                <button
                  id="nav-student-dashboard"
                  onClick={() => onNavigate('/dashboard')}
                  className={`flex items-center gap-2 px-3.5 py-1.5 text-xs font-semibold rounded-xl transition-all cursor-pointer ${
                    currentPath === '/dashboard'
                      ? 'bg-white text-slate-900 shadow-xs'
                      : 'text-slate-600 hover:text-slate-900 hover:bg-white/50'
                  }`}
                >
                  <span className={`w-1.5 h-1.5 rounded-full ${currentPath === '/dashboard' ? 'bg-blue-500' : 'bg-slate-400'}`}></span>
                  Dashboard
                </button>
                <button
                  id="nav-student-exams"
                  onClick={() => onNavigate('/exams')}
                  className={`flex items-center gap-2 px-3.5 py-1.5 text-xs font-semibold rounded-xl transition-all cursor-pointer ${
                    currentPath.startsWith('/exams')
                      ? 'bg-white text-slate-900 shadow-xs'
                      : 'text-slate-600 hover:text-slate-900 hover:bg-white/50'
                  }`}
                >
                  <span className={`w-1.5 h-1.5 rounded-full ${currentPath.startsWith('/exams') ? 'bg-blue-500' : 'bg-slate-400'}`}></span>
                  Catálogo de Exames
                </button>
              </>
            ) : (
              <>
                <button
                  id="nav-admin-overview"
                  onClick={() => onNavigate('/admin')}
                  className={`flex items-center gap-2 px-3.5 py-1.5 text-xs font-semibold rounded-xl transition-all cursor-pointer ${
                    currentPath === '/admin'
                      ? 'bg-slate-900 text-white shadow-xs'
                      : 'text-slate-600 hover:text-slate-900 hover:bg-white/50'
                  }`}
                >
                  <span className={`w-1.5 h-1.5 rounded-full ${currentPath === '/admin' ? 'bg-blue-400' : 'bg-slate-400'}`}></span>
                  Overview
                </button>
                <button
                  id="nav-admin-exams"
                  onClick={() => onNavigate('/admin/exams')}
                  className={`flex items-center gap-2 px-3.5 py-1.5 text-xs font-semibold rounded-xl transition-all cursor-pointer ${
                    currentPath === '/admin/exams'
                      ? 'bg-slate-900 text-white shadow-xs'
                      : 'text-slate-600 hover:text-slate-900 hover:bg-white/50'
                  }`}
                >
                  <span className={`w-1.5 h-1.5 rounded-full ${currentPath === '/admin/exams' ? 'bg-blue-400' : 'bg-slate-400'}`}></span>
                  Exames
                </button>
                <button
                  id="nav-admin-questions"
                  onClick={() => onNavigate('/admin/questions')}
                  className={`flex items-center gap-2 px-3.5 py-1.5 text-xs font-semibold rounded-xl transition-all cursor-pointer ${
                    currentPath === '/admin/questions'
                      ? 'bg-slate-900 text-white shadow-xs'
                      : 'text-slate-600 hover:text-slate-900 hover:bg-white/50'
                  }`}
                >
                  <span className={`w-1.5 h-1.5 rounded-full ${currentPath === '/admin/questions' ? 'bg-blue-400' : 'bg-slate-400'}`}></span>
                  Banco de Questões
                </button>
                <button
                  id="nav-admin-imports"
                  onClick={() => onNavigate('/admin/imports')}
                  className={`flex items-center gap-2 px-3.5 py-1.5 text-xs font-semibold rounded-xl transition-all cursor-pointer ${
                    currentPath === '/admin/imports'
                      ? 'bg-slate-900 text-white shadow-xs'
                      : 'text-slate-600 hover:text-slate-900 hover:bg-white/50'
                  }`}
                >
                  <span className={`w-1.5 h-1.5 rounded-full ${currentPath === '/admin/imports' ? 'bg-blue-400' : 'bg-slate-400'}`}></span>
                  Imports (Gemini)
                </button>
                <button
                  id="nav-admin-promos"
                  onClick={() => onNavigate('/admin/promos')}
                  className={`flex items-center gap-2 px-3.5 py-1.5 text-xs font-semibold rounded-xl transition-all cursor-pointer ${
                    currentPath === '/admin/promos'
                      ? 'bg-slate-900 text-white shadow-xs'
                      : 'text-slate-600 hover:text-slate-900 hover:bg-white/50'
                  }`}
                >
                  <span className={`w-1.5 h-1.5 rounded-full ${currentPath === '/admin/promos' ? 'bg-blue-400' : 'bg-slate-400'}`}></span>
                  Cupons & Planos
                </button>
                <button
                  id="nav-admin-users"
                  onClick={() => onNavigate('/admin/users')}
                  className={`flex items-center gap-2 px-3.5 py-1.5 text-xs font-semibold rounded-xl transition-all cursor-pointer ${
                    currentPath === '/admin/users'
                      ? 'bg-slate-900 text-white shadow-xs'
                      : 'text-slate-600 hover:text-slate-900 hover:bg-white/50'
                  }`}
                >
                  <span className={`w-1.5 h-1.5 rounded-full ${currentPath === '/admin/users' ? 'bg-blue-400' : 'bg-slate-400'}`}></span>
                  Usuários & RBAC
                </button>
              </>
            )}
          </nav>

          {/* Right Action Items */}
          <div className="flex items-center gap-3">
            {/* Role Switcher */}
            <div className="relative">
              <button
                id="role-switch-trigger"
                onClick={() => setShowRoleMenu(!showRoleMenu)}
                className={`flex items-center gap-2 px-3 py-1.5 text-xs font-mono font-bold rounded-xl border transition-all cursor-pointer ${
                  role === 'admin'
                    ? 'bg-slate-900 text-white border-slate-800'
                    : 'bg-blue-50 text-blue-800 border-blue-200'
                }`}
                title="Alternar perfil de visualização para testar permissões"
              >
                <span className={`w-2 h-2 rounded-full ${role === 'admin' ? 'bg-rose-400' : 'bg-blue-500'}`}></span>
                <span className="uppercase tracking-widest">{role}</span>
              </button>

              {showRoleMenu && (
                <div className="absolute right-0 mt-2 w-60 bg-white rounded-2xl shadow-xl border border-slate-200 py-2 z-50 text-xs animate-in fade-in zoom-in-95">
                  <div className="px-4 py-1.5 border-b border-slate-100 font-mono text-3xs uppercase font-bold text-slate-400 tracking-wider">
                    Alternar Papel (RBAC Sandbox):
                  </div>
                  <button
                    onClick={() => {
                      simulateRole('student');
                      setShowRoleMenu(false);
                      onNavigate('/dashboard');
                    }}
                    className="w-full text-left px-4 py-2.5 hover:bg-slate-50 flex items-center justify-between text-slate-700 font-medium"
                  >
                    <div className="flex items-center gap-2">
                      <span className="w-2 h-2 rounded-full bg-blue-500"></span>
                      <span>Papel Aluno (STUDENT)</span>
                    </div>
                    {role === 'student' && <span className="text-blue-600 font-bold">✓</span>}
                  </button>
                  <button
                    onClick={() => {
                      simulateRole('admin');
                      setShowRoleMenu(false);
                      onNavigate('/admin');
                    }}
                    className="w-full text-left px-4 py-2.5 hover:bg-slate-50 flex items-center justify-between text-slate-700 font-medium"
                  >
                    <div className="flex items-center gap-2">
                      <span className="w-2 h-2 rounded-full bg-slate-900"></span>
                      <span>Papel Admin (ADMIN)</span>
                    </div>
                    {role === 'admin' && <span className="text-slate-900 font-bold">✓</span>}
                  </button>
                </div>
              )}
            </div>

            {/* User Profile / Auth Actions */}
            {user ? (
              <div className="flex items-center gap-2">
                <div className="hidden sm:flex flex-col text-right">
                  <span className="text-xs font-bold text-slate-800 leading-tight">
                    {profile?.name || user.displayName || 'Médico(a)'}
                  </span>
                  <span className="text-3xs font-mono text-slate-400 truncate max-w-[130px]">
                    {profile?.email || user.email}
                  </span>
                </div>
                <button
                  id="user-logout-btn"
                  onClick={() => {
                    logout();
                    onNavigate('/login');
                  }}
                  className="p-2 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-xl transition-colors cursor-pointer"
                  title="Sair"
                >
                  <LogOut className="w-4 h-4" />
                </button>
              </div>
            ) : (
              <div className="flex items-center gap-2">
                <Button
                  id="navbar-login-btn"
                  size="sm"
                  variant="outline"
                  onClick={() => onNavigate('/login')}
                  icon={<LogIn className="w-3.5 h-3.5" />}
                >
                  Entrar
                </Button>
              </div>
            )}
          </div>
        </div>

        {/* Mobile Sub-bar for Exam Selector */}
        <div className="md:hidden py-2 border-t border-slate-100 flex items-center justify-between">
          <ExamSelector compact />
          <span className="text-3xs font-mono text-slate-400 uppercase tracking-wider">Multi-Exam Engine</span>
        </div>
      </div>
    </header>
  );
}
