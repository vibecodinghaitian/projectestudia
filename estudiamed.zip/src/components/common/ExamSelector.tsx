import React from 'react';
import { useExam } from '../../context/ExamContext';
import { EXAM_FLAGS } from '../../lib/utils';
import { ChevronDown, Check, Sparkles } from 'lucide-react';

interface ExamSelectorProps {
  compact?: boolean;
}

export function ExamSelector({ compact = false }: ExamSelectorProps) {
  const { exams, selectedExam, setSelectedExamId } = useExam();
  const [isOpen, setIsOpen] = React.useState(false);
  const dropdownRef = React.useRef<HTMLDivElement>(null);

  React.useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    }
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  if (!selectedExam) return null;

  return (
    <div className="relative inline-block text-left" ref={dropdownRef}>
      <button
        id="exam-selector-button"
        type="button"
        onClick={() => setIsOpen(!isOpen)}
        className="flex items-center gap-2 px-3 py-1.5 bg-slate-100/90 hover:bg-slate-200/90 text-slate-800 text-sm font-medium rounded-xl border border-slate-200/80 transition-all cursor-pointer shadow-2xs"
      >
        <span className="text-base">{EXAM_FLAGS[selectedExam.countryCode] || '🩺'}</span>
        <span className="font-semibold text-slate-900">{selectedExam.code}</span>
        {!compact && <span className="text-slate-500 hidden sm:inline">({selectedExam.country})</span>}
        <ChevronDown className="w-4 h-4 text-slate-400 ml-0.5" />
      </button>

      {isOpen && (
        <div className="origin-top-right absolute left-0 sm:right-0 sm:left-auto mt-2 w-72 rounded-2xl shadow-xl bg-white ring-1 ring-black/5 border border-slate-100 py-2 z-50 animate-in fade-in zoom-in-95 duration-100">
          <div className="px-3 py-2 border-b border-slate-100">
            <p className="text-2xs uppercase tracking-wider font-semibold text-slate-400 flex items-center gap-1.5">
              <Sparkles className="w-3 h-3 text-sky-500" />
              Arquitetura Multi-Exame
            </p>
            <p className="text-xs text-slate-600 mt-0.5">Selecione o exame médico de foco:</p>
          </div>
          <div className="py-1">
            {exams.map((exam) => {
              const isSelected = selectedExam.id === exam.id;
              return (
                <button
                  key={exam.id}
                  onClick={() => {
                    setSelectedExamId(exam.id);
                    setIsOpen(false);
                  }}
                  className={`w-full text-left px-3.5 py-2.5 flex items-start gap-3 hover:bg-slate-50 transition-colors cursor-pointer ${
                    isSelected ? 'bg-sky-50/70 text-sky-900' : 'text-slate-700'
                  }`}
                >
                  <span className="text-xl mt-0.5">{EXAM_FLAGS[exam.countryCode] || '🩺'}</span>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <p className="text-sm font-semibold truncate text-slate-900">{exam.name}</p>
                      {exam.active ? (
                        <span className="px-1.5 py-0.2 text-3xs font-semibold bg-emerald-100 text-emerald-800 rounded">
                          Ativo
                        </span>
                      ) : (
                        <span className="px-1.5 py-0.2 text-3xs font-semibold bg-slate-100 text-slate-600 rounded">
                          Em breve
                        </span>
                      )}
                    </div>
                    <p className="text-xs text-slate-500 line-clamp-1 mt-0.5">{exam.description}</p>
                  </div>
                  {isSelected && <Check className="w-4 h-4 text-sky-600 shrink-0 mt-1" />}
                </button>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
}
