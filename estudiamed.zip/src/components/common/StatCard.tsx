import React from 'react';
import { cn } from '../../lib/utils';

interface StatCardProps {
  id?: string;
  title: string;
  value: string | number;
  subtitle?: string;
  icon: React.ReactNode;
  colorClass?: string;
  trend?: {
    value: string;
    isPositive: boolean;
  };
  className?: string;
}

export function StatCard({
  id,
  title,
  value,
  subtitle,
  icon,
  colorClass = 'text-blue-600 bg-blue-50',
  trend,
  className,
}: StatCardProps) {
  return (
    <div
      id={id}
      className={cn(
        'bg-white border border-slate-200/90 rounded-3xl p-6 shadow-sm hover:shadow-md transition-shadow flex flex-col justify-between',
        className
      )}
    >
      <div className="flex items-center justify-between mb-4">
        <span className="text-xs font-bold uppercase tracking-widest text-slate-400">
          {title}
        </span>
        <div className={cn('p-2.5 rounded-2xl shrink-0', colorClass)}>
          {icon}
        </div>
      </div>

      <div>
        <div className="text-3xl font-extrabold tracking-tight text-slate-900 font-sans">
          {value}
        </div>
        {subtitle && (
          <p className="text-xs text-slate-500 mt-1 font-normal">
            {subtitle}
          </p>
        )}
      </div>

      {trend && (
        <div className="mt-3 pt-3 border-t border-slate-100 flex items-center gap-1.5 text-xs font-medium">
          <span
            className={cn(
              'font-mono text-2xs font-bold px-1.5 py-0.5 rounded',
              trend.isPositive ? 'text-emerald-700 bg-emerald-50' : 'text-amber-700 bg-amber-50'
            )}
          >
            {trend.value}
          </span>
        </div>
      )}
    </div>
  );
}
