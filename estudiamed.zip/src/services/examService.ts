import { 
  collection, 
  doc, 
  getDocs, 
  getDoc, 
  setDoc, 
  updateDoc, 
  deleteDoc, 
  query, 
  where 
} from 'firebase/firestore';
import { db } from '../lib/firebase';
import { Exam, Specialty } from '../types';
import { DEFAULT_EXAMS, DEFAULT_SPECIALTIES } from './seedService';
import { handleFirestoreError, OperationType } from '../lib/firestore-errors';

export const examService = {
  async getAllExams(): Promise<Exam[]> {
    const path = 'exams';
    try {
      const snap = await getDocs(collection(db, path));
      if (snap.empty) {
        return DEFAULT_EXAMS;
      }
      return snap.docs.map(d => ({ ...d.data(), id: d.id } as Exam));
    } catch (error) {
      console.warn('Falling back to default exams list:', error);
      return DEFAULT_EXAMS;
    }
  },

  async getActiveExams(): Promise<Exam[]> {
    const path = 'exams';
    try {
      const q = query(collection(db, path), where('active', '==', true));
      const snap = await getDocs(q);
      if (snap.empty) {
        return DEFAULT_EXAMS.filter(e => e.active);
      }
      return snap.docs.map(d => ({ ...d.data(), id: d.id } as Exam));
    } catch {
      return DEFAULT_EXAMS.filter(e => e.active);
    }
  },

  async getExamById(id: string): Promise<Exam | null> {
    const path = `exams/${id}`;
    try {
      const snap = await getDoc(doc(db, 'exams', id));
      if (!snap.exists()) {
        const fallback = DEFAULT_EXAMS.find(e => e.id === id);
        return fallback || null;
      }
      return { ...snap.data(), id: snap.id } as Exam;
    } catch {
      return DEFAULT_EXAMS.find(e => e.id === id) || null;
    }
  },

  async createExam(exam: Partial<Exam>): Promise<Exam> {
    const id = exam.id || exam.name?.toLowerCase().replace(/[^a-z0-9]/g, '-') || `exam-${Date.now()}`;
    const newExam: Exam = {
      id,
      name: exam.name || 'Novo Exame Médico',
      code: exam.code || 'EXAME',
      country: exam.country || 'Global',
      countryCode: exam.countryCode || 'GL',
      description: exam.description || '',
      active: exam.active ?? true,
      specialties: exam.specialties || [],
      availableYears: exam.availableYears || [new Date().getFullYear()],
      totalQuestions: exam.totalQuestions || 0,
      iconName: exam.iconName || 'Award',
      color: exam.color || '#0284c7',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    const path = `exams/${id}`;
    try {
      await setDoc(doc(db, 'exams', id), newExam);
    } catch (error) {
      handleFirestoreError(error, OperationType.CREATE, path);
    }
    return newExam;
  },

  async updateExam(id: string, updates: Partial<Exam>): Promise<void> {
    const path = `exams/${id}`;
    try {
      await updateDoc(doc(db, 'exams', id), {
        ...updates,
        updatedAt: new Date().toISOString(),
      });
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, path);
    }
  },

  async deleteExam(id: string): Promise<void> {
    const path = `exams/${id}`;
    try {
      await deleteDoc(doc(db, 'exams', id));
    } catch (error) {
      handleFirestoreError(error, OperationType.DELETE, path);
    }
  },

  async getSpecialties(examId?: string): Promise<Specialty[]> {
    const path = 'specialties';
    try {
      let q = collection(db, path);
      if (examId) {
        const queryRef = query(collection(db, path), where('examId', '==', examId));
        const snap = await getDocs(queryRef);
        if (snap.empty) {
          return DEFAULT_SPECIALTIES.filter(s => s.examId === examId);
        }
        return snap.docs.map(d => ({ ...d.data(), id: d.id } as Specialty));
      }
      const snap = await getDocs(q);
      if (snap.empty) {
        return DEFAULT_SPECIALTIES;
      }
      return snap.docs.map(d => ({ ...d.data(), id: d.id } as Specialty));
    } catch {
      return examId 
        ? DEFAULT_SPECIALTIES.filter(s => s.examId === examId)
        : DEFAULT_SPECIALTIES;
    }
  },

  async createSpecialty(specialty: Partial<Specialty>): Promise<Specialty> {
    const id = specialty.id || `spec-${Date.now()}`;
    const newSpec: Specialty = {
      id,
      examId: specialty.examId || 'revalida-br',
      name: specialty.name || 'Especialidade Médica',
      code: specialty.code || 'ESP',
      description: specialty.description || '',
      questionCount: specialty.questionCount || 0,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    const path = `specialties/${id}`;
    try {
      await setDoc(doc(db, 'specialties', id), newSpec);
    } catch (error) {
      handleFirestoreError(error, OperationType.CREATE, path);
    }
    return newSpec;
  },
};
