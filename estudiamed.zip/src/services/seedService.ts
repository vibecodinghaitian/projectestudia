import { 
  collection, 
  doc, 
  setDoc, 
  getDocs, 
  query, 
  limit, 
  serverTimestamp 
} from 'firebase/firestore';
import { db } from '../lib/firebase';
import { Exam, Specialty, Question, QuestionImport } from '../types';
import { handleFirestoreError, OperationType } from '../lib/firestore-errors';

export const DEFAULT_EXAMS: Exam[] = [
  {
    id: 'revalida-br',
    name: 'REVALIDA Brasil',
    code: 'REVALIDA',
    country: 'Brasil',
    countryCode: 'BR',
    description: 'Exame Nacional de Revalidação de Diplomas Médicos expedidos por Instituição de Educação Superior Estrangeira (INEP / MEC).',
    active: true,
    specialties: ['clinica-medica', 'cirurgia-geral', 'pediatria', 'ginecologia-obstetricia', 'medicina-preventiva'],
    availableYears: [2024, 2023, 2022, 2021, 2020],
    totalQuestions: 100,
    iconName: 'Award',
    color: '#0284c7',
    createdAt: new Date().toISOString(),
  },
  {
    id: 'mir-es',
    name: 'MIR Espanha',
    code: 'MIR',
    country: 'Espanha',
    countryCode: 'ES',
    description: 'Médico Interno Residente - Exame oficial de acesso à formação médica especializada do Ministério da Saúde da Espanha.',
    active: true,
    specialties: ['cardiologia', 'neurologia', 'pediatria-mir', 'digestivo', 'pneumologia'],
    availableYears: [2024, 2023, 2022],
    totalQuestions: 200,
    iconName: 'BookOpen',
    color: '#ea580c',
    createdAt: new Date().toISOString(),
  },
  {
    id: 'enarm-mx',
    name: 'ENARM México',
    code: 'ENARM',
    country: 'México',
    countryCode: 'MX',
    description: 'Examen Nacional para Aspirantes a Residencias Médicas regulado por la CIFRHS.',
    active: true,
    specialties: ['medicina-interna', 'pediatria-mx', 'cirugia', 'ginecologia-mx'],
    availableYears: [2024, 2023],
    totalQuestions: 280,
    iconName: 'GraduationCap',
    color: '#16a34a',
    createdAt: new Date().toISOString(),
  },
  {
    id: 'usmle-us',
    name: 'USMLE Step 1 & 2 CK',
    code: 'USMLE',
    country: 'Estados Unidos',
    countryCode: 'US',
    description: 'United States Medical Licensing Examination - 3-step examination for medical licensure in the United States.',
    active: false,
    specialties: ['pathology', 'pharmacology', 'internal-med', 'surgery-us'],
    availableYears: [2024],
    totalQuestions: 0,
    iconName: 'Globe',
    color: '#6366f1',
    createdAt: new Date().toISOString(),
  },
];

export const DEFAULT_SPECIALTIES: Specialty[] = [
  {
    id: 'clinica-medica',
    examId: 'revalida-br',
    name: 'Clínica Médica',
    code: 'CM',
    description: 'Cardiologia, Pneumologia, Nefrologia, Endocrinologia, Gastroenterologia e Infectologia.',
    questionCount: 20,
    createdAt: new Date().toISOString(),
  },
  {
    id: 'cirurgia-geral',
    examId: 'revalida-br',
    name: 'Cirurgia Geral',
    code: 'CG',
    description: 'Trauma, Abdome Agudo, Pré e Pós-operatório, Oncologia Cirúrgica.',
    questionCount: 20,
    createdAt: new Date().toISOString(),
  },
  {
    id: 'pediatria',
    examId: 'revalida-br',
    name: 'Pediatria',
    code: 'PED',
    description: 'Neonatologia, Crescimento e Desenvolvimento, Puericultura, Imunizações.',
    questionCount: 20,
    createdAt: new Date().toISOString(),
  },
  {
    id: 'ginecologia-obstetricia',
    examId: 'revalida-br',
    name: 'Ginecologia e Obstetrícia',
    code: 'GO',
    description: 'Pré-natal, Parto e Puerpério, Doenças Ginecológicas, Rastreamento Oncológico.',
    questionCount: 20,
    createdAt: new Date().toISOString(),
  },
  {
    id: 'medicina-preventiva',
    examId: 'revalida-br',
    name: 'Medicina Preventiva e Social',
    code: 'MPS',
    description: 'Epidemiologia, Bioestatística, SUS, Saúde Coletiva e Medicina do Trabalho.',
    questionCount: 20,
    createdAt: new Date().toISOString(),
  },
];

export const DEFAULT_QUESTIONS: Question[] = [
  {
    id: 'rev-2023-q01',
    examId: 'revalida-br',
    specialtyId: 'clinica-medica',
    specialtyName: 'Clínica Médica',
    year: 2023,
    questionNumber: 1,
    statement: 'Homem de 58 anos de idade, hipertenso e tabagista, dá entrada na Unidade de Emergência com queixa de dor retroesternal em aperto iniciada há 2 horas, irradiada para mandíbula e membro superior esquerdo, acompanhada de sudorese fria e náuseas. Ao exame físico: PA: 140/90 mmHg, FC: 88 bpm, FR: 18 irpm, SatO2: 97% em ar ambiente. Ausculta cardíaca e pulmonar normais. O eletrocardiograma de 12 derivações revela supradesnivelamento do segmento ST de 2,5 mm nas derivações V1 a V4. O hospital possui serviço de hemodinâmica disponível com tempo porta-balão estimado em 45 minutos. Qual é a conduta imediata mais adequada?',
    options: [
      { id: 'A', text: 'Iniciar trombólise química com Tenecteplase imediatamente na sala de emergência.' },
      { id: 'B', text: 'Encaminhar o paciente imediatamente para cineangiocoronariografia com angioplastia primária.' },
      { id: 'C', text: 'Aguardar o resultado dos marcadores de necrose miocárdica (Troponina I) antes de definir a reperfusão.' },
      { id: 'D', text: 'Administrar heparina não fracionada em infusão contínua e manter em observação clínica na UTI.' },
      { id: 'E', text: 'Realizar teste ergométrico de urgência para estratificação de risco coronariano.' },
    ],
    correctAnswer: 'B',
    explanation: 'Trata-se de um Infarto Agudo do Miocárdio com Supradesnivelamento do Segmento ST (IAMCSST) de parede anterior (V1-V4). A estratégia de reperfusão de escolha é a angioplastia primária quando realizada em até 120 minutos do primeiro contato médico ou tempo porta-balão < 90 minutos (aqui previsto em 45 min). A trombólise só estaria indicada caso o tempo porta-balão excedesse 120 minutos.',
    source: 'INEP - REVALIDA 2023.2 Prova Objetiva P1',
    sourcePage: 2,
    difficulty: 'medium',
    status: 'approved',
    tags: ['Cardiologia', 'IAMCSST', 'Emergência Médica', 'Reperfusão'],
    createdAt: new Date().toISOString(),
  },
  {
    id: 'rev-2023-q02',
    examId: 'revalida-br',
    specialtyId: 'pediatria',
    specialtyName: 'Pediatria',
    year: 2023,
    questionNumber: 2,
    statement: 'Lactente de 6 meses de idade é levado à Unidade Básica de Saúde pela mãe para consulta de rotina. Nascido a termo, peso de nascimento 3.200 g. Atualmente com 7.500 g, em aleitamento materno exclusivo até o momento. A mãe refere que a criança sustenta a cabeça firmemente, senta sem apoio por breves períodos, transfere objetos de uma mão para a outra e balbucia sílabas. O cartão de vacinas está atualizado de acordo com o Calendário Nacional de Vacinação do SUS. Em relação à introdução alimentar e suplementação profilática recomendada pelo Ministério da Saúde / Sociedade Brasileira de Pediatria:',
    options: [
      { id: 'A', text: 'Iniciar introdução de alimentos complementares mantendo o aleitamento materno; manter suplementação de ferro profilático e vitamina D.' },
      { id: 'B', text: 'Suspender imediatamente o aleitamento materno e introduzir fórmula infantil de seguimento e papas de frutas liquidificadas.' },
      { id: 'C', text: 'Postergar a introdução de alimentos até os 9 meses pois a criança está em curva de ganho ponderal satisfatória.' },
      { id: 'D', text: 'Iniciar sucos de frutas naturais coados e papas adicionadas de sal e mel de abelha silvestre.' },
      { id: 'E', text: 'Suspender a suplementação de ferro caso a alimentação contenha carnes e vísceras diariamente.' },
    ],
    correctAnswer: 'A',
    explanation: 'Aos 6 meses, completa-se o período de aleitamento materno exclusivo e inicia-se a introdução de alimentos saudáveis complementares mantendo o aleitamento até 2 anos ou mais. A profilaxia com ferro elementar e vitamina D deve ser continuada conforme diretrizes da SBP.',
    source: 'INEP - REVALIDA 2023.1',
    sourcePage: 4,
    difficulty: 'easy',
    status: 'approved',
    tags: ['Puericultura', 'Introdução Alimentar', 'Nutrição Infantil'],
    createdAt: new Date().toISOString(),
  },
  {
    id: 'rev-2023-q03',
    examId: 'revalida-br',
    specialtyId: 'cirurgia-geral',
    specialtyName: 'Cirurgia Geral',
    year: 2023,
    questionNumber: 3,
    statement: 'Homem de 26 anos é atendido no pronto-socorro após trauma automobilístico com colisão frontal contra anteparo fixo. O paciente estava com cinto de segurança de 3 pontos. À admissão: Glasgow 15, via aérea pérvia, murmúrio vesicular presente bilateralmente sem ruídos adventícios. PA: 110/70 mmHg, FC: 96 bpm. Abdome plano, discretamente doloroso à palpação profunda em hipocôndrio esquerdo, sem sinais de irritação peritoneal. Realizado ultrassom FAST (Focused Assessment with Sonography for Trauma), que evidenciou presença de líquido livre no espaço esplenorrenal (recesso esplenorrenal positivo). O paciente mantém estabilidade hemodinâmica após infusão de 500 mL de cristalóide aquecido. Qual é o próximo passo mais adequado no manejo?',
    options: [
      { id: 'A', text: 'Laparotomia exploradora de urgência para esplenectomia total imediata.' },
      { id: 'B', text: 'Tomografia computadorizada de abdome e pelve com contraste intravenoso para estadiamento de lesão esplênica.' },
      { id: 'C', text: 'Lavado peritoneal diagnóstico com análise celular e bioquímica.' },
      { id: 'D', text: 'Alta hospitalar com orientações de repouso e retorno em 48 horas se houver piora da dor.' },
      { id: 'E', text: 'Paracentese diagnóstica guiada por ultrassom na sala de emergência.' },
    ],
    correctAnswer: 'B',
    explanation: 'Em pacientes vítimas de trauma abdominal fechado que apresentam FAST positivo porém mantêm estabilidade hemodinâmica (normotenso, responsivo à reposição volêmica), a tomografia computadorizada contrastada de abdome é o exame padrão-ouro para estadiamento da lesão de víscera maciça (baço/fígado) e planejamento do tratamento não operatório (TNO). Laparotomia imediata é reservada para instabilidade hemodinâmica refratária.',
    source: 'INEP - REVALIDA 2023.2 Prova P1',
    sourcePage: 6,
    difficulty: 'medium',
    status: 'approved',
    tags: ['Trauma', 'ATLS', 'Lesão Esplênica', 'Conduta Não Operatória'],
    createdAt: new Date().toISOString(),
  },
  {
    id: 'rev-2024-draft-01',
    examId: 'revalida-br',
    specialtyId: 'ginecologia-obstetricia',
    specialtyName: 'Ginecologia e Obstetrícia',
    year: 2024,
    questionNumber: 15,
    statement: 'Primigesta de 19 anos, idade gestacional de 32 semanas pela ultrassonografia de primeiro trimestre, procura maternidade com queixa de cefaleia frontal persistente e escotomas cintilantes há 4 horas. Ao exame: PA = 160/110 mmHg (confirmada em duas medidas com intervalo de 15 min), edema de membros inferiores +++/4+, reflexos patelares vivos com clônus esgotável de 3 batimentos. BCF: 140 bpm, dinânica uterina ausente, colo grosso e fechado. Exames laboratoriais revelam proteinúria de fita 3+, plaquetas 130.000/mm³, creatinina 1,0 mg/dL, TGO 65 U/L. Qual a conduta prioritária imediata?',
    options: [
      { id: 'A', text: 'Sulfatação com Sulfato de Magnésio (esquema de Pritchard ou Zuspan) para prevenção de eclâmpsia e controle pressórico com Hidralazina IV ou Nifedipino oral.' },
      { id: 'B', text: 'Realização imediata de cesariana de emergência sem medicação prévia.' },
      { id: 'C', text: 'Prescrição de Diazepam intravenoso e sedação em quarto escuro.' },
      { id: 'D', text: 'Administração de diurético de alça (Furosemida) intravenoso para redução rápida da volemia e alívio do edema.' },
      { id: 'E', text: 'Indução do parto com ocitocina imediatamente.' },
    ],
    correctAnswer: 'A',
    explanation: 'Quadro clássico de Pré-Eclâmpsia com Sinais de Gravidade (iminência de eclâmpsia: PA >= 160/110 mmHg, sintomas neurológicos visuais e hiperreflexia). A prioridade imediata absoluta é a estabilização materna com sulfato de magnésio (neuroproteção/anticonvulsivante) e anti-hipertensivo de ação rápida. A resolução da gestação é planejada após a estabilização materna.',
    source: 'INEP - REVALIDA 2024.1 (Extracted from PDF)',
    sourcePage: 12,
    difficulty: 'hard',
    status: 'pending_review',
    tags: ['Obstetrícia', 'Pré-Eclâmpsia', 'Sulfato de Magnésio', 'Urgência Obstétrica'],
    createdAt: new Date().toISOString(),
  },
];

export const DEFAULT_IMPORTS: QuestionImport[] = [
  {
    id: 'import-rev-2023-p1',
    fileName: 'REVALIDA_2023_INEP_PROVA_P1.pdf',
    fileSize: 4820000,
    storagePath: '/exam-pdfs/revalida-br/2023/REVALIDA_2023_INEP_PROVA_P1.pdf',
    examId: 'revalida-br',
    year: 2023,
    status: 'completed',
    totalQuestions: 100,
    processedQuestions: 100,
    approvedQuestions: 98,
    rejectedQuestions: 2,
    createdBy: 'admin-system',
    createdAt: new Date(Date.now() - 86400000 * 3).toISOString(),
    completedAt: new Date(Date.now() - 86400000 * 3 + 3600000).toISOString(),
  },
  {
    id: 'import-rev-2024-p1',
    fileName: 'REVALIDA_2024_1_INEP_CADERNO_QUESTOES.pdf',
    fileSize: 5240000,
    storagePath: '/exam-pdfs/revalida-br/2024/REVALIDA_2024_1_INEP_CADERNO_QUESTOES.pdf',
    examId: 'revalida-br',
    year: 2024,
    status: 'partially_completed',
    totalQuestions: 100,
    processedQuestions: 45,
    approvedQuestions: 38,
    rejectedQuestions: 7,
    notes: 'Aguardando validação dos itens de Ginecologia e Obstetrícia',
    createdBy: 'admin-system',
    createdAt: new Date(Date.now() - 86400000 * 1).toISOString(),
  },
];

/**
 * Checks if the database is already seeded, otherwise seeds default exams, specialties, and sample questions.
 */
export async function seedInitialDatabaseIfEmpty(): Promise<{ seeded: boolean; message: string }> {
  try {
    const examsSnap = await getDocs(query(collection(db, 'exams'), limit(1)));
    if (!examsSnap.empty) {
      return { seeded: false, message: 'Database already initialized.' };
    }

    // Seed Exams
    for (const exam of DEFAULT_EXAMS) {
      await setDoc(doc(db, 'exams', exam.id), exam);
    }

    // Seed Specialties
    for (const spec of DEFAULT_SPECIALTIES) {
      await setDoc(doc(db, 'specialties', spec.id), spec);
    }

    // Seed Questions
    for (const q of DEFAULT_QUESTIONS) {
      await setDoc(doc(db, 'questions', q.id), q);
    }

    // Seed Question Imports
    for (const imp of DEFAULT_IMPORTS) {
      await setDoc(doc(db, 'questionImports', imp.id), imp);
    }

    return { seeded: true, message: 'Initial medical database seeded successfully.' };
  } catch (error) {
    console.warn('Seeding note (will use memory fallback if restricted by offline/rules):', error);
    return { seeded: false, message: 'Seeded in fallback mode.' };
  }
}
