/**
 * ESTUDIAMED - Subscription & Promo Code Client Service
 * Bridges client requests to secure server-side Stripe & promo verification APIs.
 */

import { PlanId, PricingPlan, PromoCode, PromoValidationResult, UserSubscription } from '../types';

export const PRICING_PLANS: Record<string, Record<PlanId, PricingPlan>> = {
  en: {
    starter: {
      id: 'starter',
      name: 'Starter',
      priceMonthlyUSD: 1.99,
      questionLimit: 1000,
      features: [
        'Access to approved question bank (up to 1,000 questions)',
        'Practice mode with customizable filters',
        'Basic progress & accuracy tracking',
        'Mobile and desktop browser access',
      ],
      ctaKey: 'Start with Starter',
    },
    pro: {
      id: 'pro',
      name: 'Pro',
      priceMonthlyUSD: 2.99,
      questionLimit: 3000,
      isPopular: true,
      features: [
        'Everything in Starter',
        'Up to 3,000 verified questions',
        'Realistic official exam simulations with timer',
        'Detailed medical corrections & rationale',
        'Advanced performance statistics by specialty',
        'Targeted review of incorrect answers',
      ],
      ctaKey: 'Choose Pro',
    },
    premium: {
      id: 'premium',
      name: 'Premium',
      priceMonthlyUSD: 3.99,
      questionLimit: 'unlimited',
      features: [
        'Everything in Pro',
        'Unlimited question bank access',
        'Unlimited timed simulations',
        'Comprehensive performance analytics & radar charts',
        'Full question bank access with historical editions',
        'Priority access to new AI-ingested exam editions',
      ],
      ctaKey: 'Choose Premium',
    },
  },
  es: {
    starter: {
      id: 'starter',
      name: 'Starter',
      priceMonthlyUSD: 1.99,
      questionLimit: 1000,
      features: [
        'Acceso al banco de preguntas aprobadas (hasta 1.000 preguntas)',
        'Modo de práctica con filtros por especialidad',
        'Seguimiento básico de progreso y aciertos',
        'Acceso en móvil y escritorio',
      ],
      ctaKey: 'Comenzar con Starter',
    },
    pro: {
      id: 'pro',
      name: 'Pro',
      priceMonthlyUSD: 2.99,
      questionLimit: 3000,
      isPopular: true,
      features: [
        'Todo lo incluido en Starter',
        'Hasta 3.000 preguntas verificadas',
        'Simulacros realistas de examen con temporizador',
        'Correcciones médicas detalladas y justificación',
        'Estadísticas avanzadas de rendimiento por especialidad',
        'Revisión dirigida de respuestas incorrectas',
      ],
      ctaKey: 'Elegir Pro',
    },
    premium: {
      id: 'premium',
      name: 'Premium',
      priceMonthlyUSD: 3.99,
      questionLimit: 'unlimited',
      features: [
        'Todo lo incluido en Pro',
        'Acceso ilimitado al banco de preguntas',
        'Simulacros cronometrados ilimitados',
        'Analítica completa de rendimiento y debilidades',
        'Acceso completo a ediciones históricas',
        'Acceso prioritario a nuevos exámenes procesados por IA',
      ],
      ctaKey: 'Elegir Premium',
    },
  },
  pt: {
    starter: {
      id: 'starter',
      name: 'Starter',
      priceMonthlyUSD: 1.99,
      questionLimit: 1000,
      features: [
        'Acesso ao banco de questões aprovadas (até 1.000 questões)',
        'Modo de treino com filtros por especialidade',
        'Acompanhamento básico de progresso e precisão',
        'Acesso no celular e computador',
      ],
      ctaKey: 'Começar com Starter',
    },
    pro: {
      id: 'pro',
      name: 'Pro',
      priceMonthlyUSD: 2.99,
      questionLimit: 3000,
      isPopular: true,
      features: [
        'Tudo incluído no Starter',
        'Até 3.000 questões homologadas',
        'Simulados oficiais realistas com temporizador',
        'Correções médicas detalhadas e justificativas',
        'Estatísticas avançadas de desempenho por grande área',
        'Caderno de erros para revisão ativa',
      ],
      ctaKey: 'Escolher Pro',
    },
    premium: {
      id: 'premium',
      name: 'Premium',
      priceMonthlyUSD: 3.99,
      questionLimit: 'unlimited',
      features: [
        'Tudo incluído no Pro',
        'Acesso ilimitado a todo o banco de questões',
        'Simulados cronometrados ilimitados',
        'Analítica completa de performance e diagnóstico de fraquezas',
        'Acesso a todas as edições históricas dos exames',
        'Acesso prioritário a novas provas processadas por IA',
      ],
      ctaKey: 'Escolher Premium',
    },
  },
};

export const subscriptionService = {
  /**
   * Validate promo code server-side
   */
  async validatePromoCode(code: string, planId: PlanId): Promise<PromoValidationResult> {
    try {
      const res = await fetch('/api/promo/validate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ code, planId }),
      });
      return await res.json();
    } catch (err: any) {
      return { valid: false, message: 'Server connection error during validation.' };
    }
  },

  /**
   * Create checkout session
   */
  async createCheckoutSession(params: {
    planId: PlanId;
    email?: string;
    userId?: string;
    promoCode?: string;
    successUrl?: string;
    cancelUrl?: string;
  }) {
    const res = await fetch('/api/stripe/create-checkout-session', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(params),
    });
    if (!res.ok) {
      const err = await res.json();
      throw new Error(err.error || 'Failed to initialize checkout session');
    }
    return await res.json();
  },

  /**
   * Admin: get all promo codes
   */
  async getAdminPromoCodes(): Promise<PromoCode[]> {
    const res = await fetch('/api/admin/promos');
    const data = await res.json();
    return data.promos || [];
  },

  /**
   * Admin: create promo code
   */
  async createAdminPromoCode(promo: Partial<PromoCode> & { code: string; discount_value: number }) {
    const res = await fetch('/api/admin/promos', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(promo),
    });
    if (!res.ok) {
      const err = await res.json();
      throw new Error(err.error || 'Failed to create promo code');
    }
    return await res.json();
  },

  /**
   * Admin: toggle promo code
   */
  async toggleAdminPromoCode(id: string) {
    const res = await fetch(`/api/admin/promos/${id}/toggle`, { method: 'POST' });
    return await res.json();
  },

  /**
   * Admin: delete promo code
   */
  async deleteAdminPromoCode(id: string) {
    const res = await fetch(`/api/admin/promos/${id}`, { method: 'DELETE' });
    return await res.json();
  },
};
