import { 
  collection, 
  doc, 
  getDocs, 
  getDoc, 
  setDoc, 
  updateDoc, 
  deleteDoc 
} from 'firebase/firestore';
import { db } from '../lib/firebase';
import { Question, QuestionStatus } from '../types';
import { DEFAULT_QUESTIONS } from './seedService';
import { handleFirestoreError, OperationType } from '../lib/firestore-errors';

export interface QuestionFilters {
  examId?: string;
  status?: QuestionStatus | 'all';
  specialtyId?: string;
  year?: number;
  search?: string;
  difficulty?: string;
}

// Client cache for questions
const localQuestionsMap = new Map<string, Question>();

// Seed default questions
DEFAULT_QUESTIONS.forEach(q => localQuestionsMap.set(q.id, q));

export const questionService = {
  async getQuestions(filters?: QuestionFilters): Promise<Question[]> {
    const path = 'questions';
    let list: Question[] = [];

    try {
      const snap = await getDocs(collection(db, path));
      if (!snap.empty) {
        list = snap.docs.map(d => ({ ...d.data(), id: d.id } as Question));
      }
    } catch (e) {
      console.warn('Firestore getQuestions fallback:', e);
    }

    // Merge in-memory / locally stored questions
    for (const cached of localQuestionsMap.values()) {
      if (!list.some(q => q.id === cached.id)) {
        list.push(cached);
      } else {
        const idx = list.findIndex(q => q.id === cached.id);
        list[idx] = { ...list[idx], ...cached };
      }
    }

    if (list.length === 0) {
      list = [...DEFAULT_QUESTIONS];
    }

    // Apply filters
    if (filters?.examId && filters.examId !== 'all') {
      list = list.filter(q => q.examId === filters.examId);
    }

    if (filters?.status && filters.status !== 'all') {
      list = list.filter(q => q.status === filters.status);
    }

    if (filters?.specialtyId && filters.specialtyId !== 'all') {
      list = list.filter(q => q.specialtyId === filters.specialtyId);
    }

    if (filters?.year) {
      list = list.filter(q => q.year === Number(filters.year));
    }

    if (filters?.difficulty && filters.difficulty !== 'all') {
      list = list.filter(q => q.difficulty === filters.difficulty);
    }

    if (filters?.search && filters.search.trim().length > 0) {
      const term = filters.search.toLowerCase().trim();
      list = list.filter(
        q =>
          q.statement.toLowerCase().includes(term) ||
          (q.explanation && q.explanation.toLowerCase().includes(term)) ||
          (q.source && q.source.toLowerCase().includes(term)) ||
          (q.specialtyName && q.specialtyName.toLowerCase().includes(term))
      );
    }

    // Sort by question number or date
    return list.sort((a, b) => (a.questionNumber || 0) - (b.questionNumber || 0));
  },

  async getQuestionById(id: string): Promise<Question | null> {
    if (localQuestionsMap.has(id)) {
      return localQuestionsMap.get(id)!;
    }

    const path = `questions/${id}`;
    try {
      const snap = await getDoc(doc(db, 'questions', id));
      if (snap.exists()) {
        const q = { ...snap.data(), id: snap.id } as Question;
        localQuestionsMap.set(id, q);
        return q;
      }
    } catch {}

    return DEFAULT_QUESTIONS.find(q => q.id === id) || null;
  },

  async createQuestion(question: Partial<Question>): Promise<Question> {
    const id = question.id || `q-${Date.now()}-${Math.floor(Math.random() * 1000)}`;
    const newQuestion: Question = {
      id,
      examId: question.examId || 'revalida-br',
      specialtyId: question.specialtyId || 'clinica-medica',
      specialtyName: question.specialtyName || 'Clínica Médica',
      year: question.year || new Date().getFullYear(),
      questionNumber: question.questionNumber || 1,
      statement: question.statement || '',
      options: question.options || [
        { id: 'A', text: '' },
        { id: 'B', text: '' },
        { id: 'C', text: '' },
        { id: 'D', text: '' },
      ],
      correctAnswer: question.correctAnswer || 'A',
      explanation: question.explanation || '',
      source: question.source || '',
      sourcePage: question.sourcePage,
      difficulty: question.difficulty || 'medium',
      status: question.status || 'pending_review',
      tags: question.tags || [],
      isPossibleDuplicate: question.isPossibleDuplicate,
      duplicateReason: question.duplicateReason,
      validationErrors: question.validationErrors,
      createdBy: question.createdBy,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    localQuestionsMap.set(id, newQuestion);

    const path = `questions/${id}`;
    try {
      await setDoc(doc(db, 'questions', id), newQuestion);
    } catch (error) {
      console.warn('Firestore createQuestion fallback:', error);
    }
    return newQuestion;
  },

  async updateQuestion(id: string, updates: Partial<Question>): Promise<void> {
    const existing = localQuestionsMap.get(id);
    if (existing) {
      localQuestionsMap.set(id, { ...existing, ...updates, updatedAt: new Date().toISOString() });
    }

    const path = `questions/${id}`;
    try {
      await updateDoc(doc(db, 'questions', id), {
        ...updates,
        updatedAt: new Date().toISOString(),
      });
    } catch (error) {
      console.warn('Firestore updateQuestion fallback:', error);
    }
  },

  async updateStatus(id: string, status: QuestionStatus): Promise<void> {
    return this.updateQuestion(id, { status });
  },

  async deleteQuestion(id: string): Promise<void> {
    localQuestionsMap.delete(id);

    const path = `questions/${id}`;
    try {
      await deleteDoc(doc(db, 'questions', id));
    } catch (error) {
      console.warn('Firestore deleteQuestion fallback:', error);
    }
  },
};
