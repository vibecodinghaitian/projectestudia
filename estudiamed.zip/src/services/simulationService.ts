import { 
  collection, 
  doc, 
  getDocs, 
  getDoc, 
  setDoc, 
  updateDoc, 
  query, 
  where 
} from 'firebase/firestore';
import { db } from '../lib/firebase';
import { Simulation, SimulationResult } from '../types';
import { handleFirestoreError, OperationType } from '../lib/firestore-errors';

export const simulationService = {
  async getSimulationsForUser(userId: string): Promise<Simulation[]> {
    const path = 'simulations';
    try {
      const q = query(collection(db, path), where('userId', '==', userId));
      const snap = await getDocs(q);
      return snap.docs.map(d => ({ ...d.data(), id: d.id } as Simulation));
    } catch {
      return [];
    }
  },

  async createSimulation(data: {
    userId: string;
    examId: string;
    title: string;
    year?: number;
    mode: 'exam' | 'practice' | 'custom';
    questionIds: string[];
    timeLimitMinutes?: number;
  }): Promise<Simulation> {
    const id = `sim-${Date.now()}`;
    const sim: Simulation = {
      id,
      userId: data.userId,
      examId: data.examId,
      title: data.title,
      year: data.year,
      mode: data.mode,
      questionIds: data.questionIds,
      status: 'in_progress',
      totalQuestions: data.questionIds.length,
      timeLimitMinutes: data.timeLimitMinutes || 180,
      startedAt: new Date().toISOString(),
      createdAt: new Date().toISOString(),
    };

    const path = `simulations/${id}`;
    try {
      await setDoc(doc(db, 'simulations', id), sim);
    } catch (error) {
      handleFirestoreError(error, OperationType.CREATE, path);
    }
    return sim;
  },

  async getSimulationResultsForUser(userId: string, examId?: string): Promise<SimulationResult[]> {
    const path = 'simulationResults';
    try {
      const q = query(collection(db, path), where('userId', '==', userId));
      const snap = await getDocs(q);
      let list = snap.docs.map(d => ({ ...d.data(), id: d.id } as SimulationResult));
      if (examId && examId !== 'all') {
        list = list.filter(r => r.examId === examId);
      }
      return list;
    } catch {
      return [];
    }
  },

  async saveSimulationResult(result: Partial<SimulationResult> & { id: string; userId: string; simulationId: string; examId: string }): Promise<SimulationResult> {
    const path = `simulationResults/${result.id}`;
    const fullResult: SimulationResult = {
      id: result.id,
      simulationId: result.simulationId,
      userId: result.userId,
      examId: result.examId,
      score: result.score || 0,
      totalQuestions: result.totalQuestions || 0,
      correctAnswers: result.correctAnswers || 0,
      incorrectAnswers: result.incorrectAnswers || 0,
      unanswered: result.unanswered || 0,
      timeSpentSeconds: result.timeSpentSeconds || 0,
      answers: result.answers || {},
      specialtyBreakdown: result.specialtyBreakdown || {},
      completedAt: new Date().toISOString(),
      createdAt: new Date().toISOString(),
    };

    try {
      await setDoc(doc(db, 'simulationResults', result.id), fullResult);
      // mark simulation completed
      await updateDoc(doc(db, 'simulations', result.simulationId), {
        status: 'completed',
        completedAt: new Date().toISOString(),
      });
    } catch (error) {
      handleFirestoreError(error, OperationType.CREATE, path);
    }
    return fullResult;
  },
};
