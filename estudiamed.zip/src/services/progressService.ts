import { 
  doc, 
  getDoc, 
  setDoc 
} from 'firebase/firestore';
import { db } from '../lib/firebase';
import { StudentProgress } from '../types';
import { handleFirestoreError, OperationType } from '../lib/firestore-errors';

export const progressService = {
  async getStudentProgress(userId: string, examId: string): Promise<StudentProgress | null> {
    const id = `${userId}_${examId}`;
    const path = `studentProgress/${id}`;
    try {
      const snap = await getDoc(doc(db, 'studentProgress', id));
      if (!snap.exists()) {
        return {
          id,
          userId,
          examId,
          totalQuestionsAnswered: 0,
          totalCorrect: 0,
          accuracyPercentage: 0,
          weakSpecialties: [],
          strongSpecialties: [],
          updatedAt: new Date().toISOString(),
        };
      }
      return snap.data() as StudentProgress;
    } catch {
      return {
        id,
        userId,
        examId,
        totalQuestionsAnswered: 0,
        totalCorrect: 0,
        accuracyPercentage: 0,
        weakSpecialties: [],
        strongSpecialties: [],
        updatedAt: new Date().toISOString(),
      };
    }
  },

  async updateStudentProgress(progress: StudentProgress): Promise<void> {
    const path = `studentProgress/${progress.id}`;
    try {
      await setDoc(doc(db, 'studentProgress', progress.id), {
        ...progress,
        updatedAt: new Date().toISOString(),
      });
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, path);
    }
  },
};
