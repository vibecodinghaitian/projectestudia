import { 
  signInWithEmailAndPassword, 
  createUserWithEmailAndPassword, 
  signInWithPopup, 
  signOut, 
  sendPasswordResetEmail,
  User as FirebaseUser 
} from 'firebase/auth';
import { 
  doc, 
  getDoc, 
  setDoc, 
  updateDoc 
} from 'firebase/firestore';
import { auth, db, googleProvider } from '../lib/firebase';
import { UserProfile, UserRole } from '../types';
import { handleFirestoreError, OperationType } from '../lib/firestore-errors';

const BOOTSTRAP_ADMIN_EMAILS = [
  'wanky7713@gmail.com',
  'admin@estudiamed.com',
];

export const authService = {
  async getUserProfile(uid: string): Promise<UserProfile | null> {
    const path = `users/${uid}`;
    try {
      const userDoc = await getDoc(doc(db, 'users', uid));
      if (!userDoc.exists()) {
        return null;
      }
      return userDoc.data() as UserProfile;
    } catch (error) {
      console.warn('Could not fetch user profile doc, falling back to basic auth info:', error);
      return null;
    }
  },

  async checkIfAdmin(uid: string, email?: string | null): Promise<boolean> {
    if (email && BOOTSTRAP_ADMIN_EMAILS.includes(email.toLowerCase())) {
      return true;
    }
    try {
      const adminDoc = await getDoc(doc(db, 'admins', uid));
      return adminDoc.exists();
    } catch {
      return email ? BOOTSTRAP_ADMIN_EMAILS.includes(email.toLowerCase()) : false;
    }
  },

  async syncUserProfile(fbUser: FirebaseUser, forcedRole?: UserRole): Promise<UserProfile> {
    const isDesignatedAdmin = Boolean(
      (fbUser.email && BOOTSTRAP_ADMIN_EMAILS.includes(fbUser.email.toLowerCase())) ||
      forcedRole === 'admin'
    );
    const role: UserRole = isDesignatedAdmin ? 'admin' : (forcedRole || 'student');

    const profile: UserProfile = {
      uid: fbUser.uid,
      name: fbUser.displayName || fbUser.email?.split('@')[0] || 'Médico(a) Estudante',
      email: fbUser.email || '',
      role,
      targetExamId: 'revalida-br',
      avatarUrl: fbUser.photoURL || undefined,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    try {
      const userRef = doc(db, 'users', fbUser.uid);
      const existing = await getDoc(userRef);
      if (!existing.exists()) {
        await setDoc(userRef, profile);
        if (role === 'admin') {
          try {
            await setDoc(doc(db, 'admins', fbUser.uid), {
              uid: fbUser.uid,
              email: fbUser.email || '',
              createdAt: new Date().toISOString(),
            });
          } catch {
            // silent admin doc create attempt
          }
        }
      } else {
        const data = existing.data() as UserProfile;
        return data;
      }
    } catch (err) {
      console.warn('Profile sync fallback (offline/sandbox):', err);
    }

    return profile;
  },

  async loginWithEmail(email: string, pass: string): Promise<UserProfile> {
    const cred = await signInWithEmailAndPassword(auth, email, pass);
    return this.syncUserProfile(cred.user);
  },

  async registerWithEmail(email: string, pass: string, name: string): Promise<UserProfile> {
    const cred = await createUserWithEmailAndPassword(auth, email, pass);
    const profile: UserProfile = {
      uid: cred.user.uid,
      name,
      email,
      role: BOOTSTRAP_ADMIN_EMAILS.includes(email.toLowerCase()) ? 'admin' : 'student',
      targetExamId: 'revalida-br',
      createdAt: new Date().toISOString(),
    };
    try {
      await setDoc(doc(db, 'users', cred.user.uid), profile);
    } catch (error) {
      console.warn('Could not write new profile to firestore directly:', error);
    }
    return profile;
  },

  async loginWithGoogle(): Promise<UserProfile> {
    const cred = await signInWithPopup(auth, googleProvider);
    return this.syncUserProfile(cred.user);
  },

  async logout(): Promise<void> {
    await signOut(auth);
  },

  async resetPassword(email: string): Promise<void> {
    await sendPasswordResetEmail(auth, email);
  },

  async updateTargetExam(uid: string, examId: string): Promise<void> {
    const path = `users/${uid}`;
    try {
      await updateDoc(doc(db, 'users', uid), {
        targetExamId: examId,
        updatedAt: new Date().toISOString(),
      });
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, path);
    }
  },
};
