import { 
  collection, 
  doc, 
  getDocs, 
  getDoc, 
  setDoc, 
  updateDoc, 
  deleteDoc, 
  query, 
  orderBy 
} from 'firebase/firestore';
import { db } from '../lib/firebase';
import { QuestionImport, ImportStatus, Question } from '../types';
import { DEFAULT_IMPORTS } from './seedService';
import { handleFirestoreError, OperationType } from '../lib/firestore-errors';

// Client-side in-memory cache for imported jobs and their extracted questions
const localImportsStore = new Map<string, QuestionImport>();
const localQuestionsStore = new Map<string, Question[]>();

export const importService = {
  /**
   * Uploads PDF file to backend private storage and initiates the import record
   */
  async uploadExamPdf(params: {
    file: File;
    examId: string;
    year: number;
    userId: string;
  }): Promise<QuestionImport> {
    const { file, examId, year, userId } = params;

    // Convert file to Base64
    const base64Data = await new Promise<string>((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => {
        const result = reader.result as string;
        // Strip data:application/pdf;base64, prefix
        const base64 = result.split(',')[1] || result;
        resolve(base64);
      };
      reader.onerror = error => reject(error);
      reader.readAsDataURL(file);
    });

    try {
      const response = await fetch('/api/imports/upload', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          examId,
          year,
          fileName: file.name,
          fileSize: file.size,
          fileBase64: base64Data,
          userId,
        }),
      });

      if (!response.ok) {
        const err = await response.json();
        throw new Error(err.error || 'Falha no envio do PDF para o servidor.');
      }

      const data = await response.json();
      const record: QuestionImport = data.importRecord;

      // Save to local cache
      localImportsStore.set(record.id, record);

      // Also persist record to Firestore if possible
      try {
        await setDoc(doc(db, 'questionImports', record.id), record);
      } catch (e) {
        console.warn('Firestore fallback for import record:', e);
      }

      return record;
    } catch (apiError: any) {
      console.warn('Backend API upload fallback:', apiError);
      // Client-side fallback if server endpoint is unreachable
      const fallbackRecord: QuestionImport = {
        id: `import-${examId}-${year}-${Date.now()}`,
        fileName: file.name,
        fileSize: file.size,
        storagePath: `exam-pdfs/${examId}/${year}/${file.name}`,
        examId,
        year,
        status: 'uploaded',
        totalQuestions: 0,
        processedQuestions: 0,
        approvedQuestions: 0,
        rejectedQuestions: 0,
        pendingReviewQuestions: 0,
        possibleDuplicatesCount: 0,
        stage: 'Aguardando Início',
        progressPercent: 0,
        stageDescription: 'Arquivo carregado. Pronto para iniciar processamento.',
        errors: [],
        createdBy: userId,
        createdAt: new Date().toISOString(),
      };
      localImportsStore.set(fallbackRecord.id, fallbackRecord);
      return fallbackRecord;
    }
  },

  /**
   * Triggers the Gemini AI processing pipeline on the server
   */
  async processExamPdf(params: {
    importId: string;
    examId?: string;
    year?: number;
    fileName?: string;
    forceReprocess?: boolean;
  }): Promise<QuestionImport> {
    try {
      const response = await fetch('/api/imports/process', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(params),
      });

      if (!response.ok) {
        const err = await response.json();
        throw new Error(err.error || 'Erro ao processar PDF com Gemini AI.');
      }

      const updatedJob: QuestionImport = await response.json();
      localImportsStore.set(updatedJob.id, updatedJob);

      // Sync with Firestore
      try {
        await updateDoc(doc(db, 'questionImports', updatedJob.id), updatedJob as any);
      } catch {}

      return updatedJob;
    } catch (err: any) {
      console.error('Error in processExamPdf:', err);
      throw err;
    }
  },

  /**
   * Fetches real-time progress and logs for an import job
   */
  async getImportProgress(importId: string): Promise<QuestionImport | null> {
    try {
      const response = await fetch(`/api/imports/${importId}/status`);
      if (response.ok) {
        const data = await response.json();
        localImportsStore.set(importId, data);
        return data;
      }
    } catch {}

    return localImportsStore.get(importId) || null;
  },

  /**
   * Fetches extracted questions associated with an import
   */
  async getImportQuestions(
    importId: string,
    filterOptions?: { status?: string; filter?: string }
  ): Promise<Question[]> {
    try {
      const queryParams = new URLSearchParams();
      if (filterOptions?.status) queryParams.set('status', filterOptions.status);
      if (filterOptions?.filter) queryParams.set('filter', filterOptions.filter);

      const response = await fetch(`/api/imports/${importId}/questions?${queryParams.toString()}`);
      if (response.ok) {
        const data = await response.json();
        const questions: Question[] = data.questions || [];
        localQuestionsStore.set(importId, questions);
        return questions;
      }
    } catch {}

    return localQuestionsStore.get(importId) || [];
  },

  /**
   * Review/edit/approve a specific question
   */
  async reviewQuestion(questionId: string, updates: Partial<Question>): Promise<Question> {
    try {
      const response = await fetch(`/api/questions/${questionId}/review`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(updates),
      });

      if (!response.ok) {
        const err = await response.json();
        throw new Error(err.error || 'Erro ao revisar questão.');
      }

      const data = await response.json();
      return data.question;
    } catch (err: any) {
      console.error('Error reviewing question:', err);
      throw err;
    }
  },

  /**
   * Execute bulk action on an import's questions
   */
  async bulkAction(
    importId: string,
    action: 'approve_valid' | 'reject_all' | 'approve_all'
  ): Promise<{ success: boolean; affectedCount: number; importRecord: QuestionImport | null }> {
    try {
      const response = await fetch(`/api/imports/${importId}/bulk-action`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action }),
      });

      if (!response.ok) {
        const err = await response.json();
        throw new Error(err.error || 'Erro ao executar ação em massa.');
      }

      const data = await response.json();
      if (data.importRecord) {
        localImportsStore.set(importId, data.importRecord);
      }
      return data;
    } catch (err: any) {
      console.error('Error in bulkAction:', err);
      throw err;
    }
  },

  /**
   * Generates a sample INEP REVALIDA import for testing
   */
  async createSampleRevalidaImport(): Promise<QuestionImport> {
    const response = await fetch('/api/imports/sample-revalida', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
    });

    if (!response.ok) {
      const err = await response.json();
      throw new Error(err.error || 'Erro ao gerar amostra do REVALIDA.');
    }

    const data = await response.json();
    localImportsStore.set(data.id, data);
    return data;
  },

  /**
   * List all import records
   */
  async getImports(examId?: string): Promise<QuestionImport[]> {
    const path = 'questionImports';
    let list: QuestionImport[] = [];

    try {
      const snap = await getDocs(collection(db, path));
      if (!snap.empty) {
        list = snap.docs.map(d => ({ ...d.data(), id: d.id } as QuestionImport));
      }
    } catch {}

    // Merge with local/server cached jobs
    for (const cached of localImportsStore.values()) {
      if (!list.some(i => i.id === cached.id)) {
        list.unshift(cached);
      } else {
        const idx = list.findIndex(i => i.id === cached.id);
        list[idx] = { ...list[idx], ...cached };
      }
    }

    if (list.length === 0) {
      list = [...DEFAULT_IMPORTS];
    }

    if (examId && examId !== 'all') {
      list = list.filter(i => i.examId === examId);
    }

    return list.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  },

  async getImportById(id: string): Promise<QuestionImport | null> {
    if (localImportsStore.has(id)) {
      return localImportsStore.get(id)!;
    }

    const path = `questionImports/${id}`;
    try {
      const snap = await getDoc(doc(db, 'questionImports', id));
      if (snap.exists()) {
        const item = { ...snap.data(), id: snap.id } as QuestionImport;
        localImportsStore.set(id, item);
        return item;
      }
    } catch {}

    const fallback = DEFAULT_IMPORTS.find(i => i.id === id) || null;
    return fallback;
  },

  async updateImportStatus(id: string, status: ImportStatus, updates?: Partial<QuestionImport>): Promise<void> {
    const existing = localImportsStore.get(id);
    if (existing) {
      localImportsStore.set(id, { ...existing, status, ...updates });
    }

    const path = `questionImports/${id}`;
    try {
      await updateDoc(doc(db, 'questionImports', id), {
        status,
        ...updates,
        ...(status === 'completed' || status === 'reviewed' ? { completedAt: new Date().toISOString() } : {}),
      });
    } catch (error) {
      console.warn('Firestore update import status fallback:', error);
    }
  },

  async deleteImport(id: string): Promise<void> {
    localImportsStore.delete(id);
    localQuestionsStore.delete(id);

    const path = `questionImports/${id}`;
    try {
      await deleteDoc(doc(db, 'questionImports', id));
    } catch (error) {
      console.warn('Firestore delete import fallback:', error);
    }
  },
};
